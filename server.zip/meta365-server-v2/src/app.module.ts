import { MiddlewareConsumer, Module, NestModule } from "@nestjs/common";
import { AppController } from "./app.controller";
import { AppService } from "./app.service";
import { ConfigServiceModule } from "./commons/module-config/index.config";
import { ReqResLoggerMiddleware } from "./middleware/log-req-res";
import { AuthenticationModule } from "./modules/authentication/authentication.module";
import { ConfigModule } from "@nestjs/config";
import { ArticleModule } from "../src/modules/article/article.module";
import { ProvinceModule } from "./modules/province/province.module";
import { ProjectModule } from "./modules/project/project.module";
import { LinkModule } from "./modules/link/link.module";
import { AssetModule } from "./modules/asset/asset.module";
import { AgentModule } from "./modules/agent/agent.module";
import { SettingsModule } from "./modules/settings/settings.module";
import { AdminModule } from "../src/modules/admin/admin.module";
import { MailerModule } from "./modules/mailer/mailer.module";
import { ProjectCategoryModule } from "./modules/projectCategory/project-category.module";
// import { APP_GUARD, Reflector } from "@nestjs/core";
// import { JwtAuthGuard } from "./commons/authentication/jwt-auth.guard";
import { ProjectContactModule } from "./modules/project-contact/project-contact.module";

@Module({
  imports: [
    ConfigServiceModule,
    AuthenticationModule,
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    ArticleModule,
    ProvinceModule,
    ProjectModule,
    LinkModule,
    AssetModule,
    AgentModule,
    SettingsModule,
    AdminModule,
    ProjectCategoryModule,
    MailerModule,
    ProjectContactModule,
  ],
  controllers: [AppController],
  providers: [
    // {
    //   provide: APP_GUARD,
    //   useFactory: ref => new JwtAuthGuard(ref),
    //   inject: [Reflector],
    // },
    AppService,
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer
      .apply(ReqResLoggerMiddleware)
      .exclude("api/appdata")
      .forRoutes("*");
  }
}
