import {
  Injectable,
  CanActivate,
  ExecutionContext,
  HttpException,
  HttpStatus,
  Inject,
} from "@nestjs/common";
import { Observable } from "rxjs";

// @Injectable()
export class ValidUser implements CanActivate {
  // constructor(
  //   @Inject(UsersService) private readonly userService: UsersService
  // )
  // { }
  canActivate(
    context: ExecutionContext
  ): boolean | Promise<boolean> | Observable<boolean> {
    const request = context.switchToHttp().getRequest();
    // const user = this.userService.getById(request.user.userId)
    // console.log(user)
    return validateRequest(request);
  }
}

function validateRequest(
  request: any
): boolean | Promise<boolean> | Observable<boolean> {
  return true;
  // return new Promise((resolve, reject) => {
  //   const user = this.userService.getById(request.user.userId)

  //   if (!user.is_verified_phone) {
  //     reject(new HttpException('error.authentication.phone_needs_to_be_verified', HttpStatus.BAD_REQUEST));
  //   }
  //   if (!user.is_active) {
  //     reject(new HttpException('error.authentication.account_is_deactivated_by_yourself', HttpStatus.BAD_REQUEST));
  //   }
  //   if (user.is_blocked) {
  //     reject(new HttpException('error.authentication.account_is_block_by_admin', HttpStatus.BAD_REQUEST));
  //   }
  //   resolve(true)
  // })
}
