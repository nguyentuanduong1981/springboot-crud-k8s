import {
  CanActivate,
  ExecutionContext,
  HttpException,
  HttpStatus,
} from "@nestjs/common";
import { Observable } from "rxjs";

export class Mint implements CanActivate {
  canActivate(
    context: ExecutionContext
  ): boolean | Promise<boolean> | Observable<boolean> {
    const request = context.switchToHttp().getRequest();
    return validateRequest(request);
  }
}

function validateRequest(
  request: any
): boolean | Promise<boolean> | Observable<boolean> {
  return new Promise((resolve, reject) => {
    if (request.query["mint-key"] !== process.env.MINT_KEY) {
      reject(new HttpException("error.api.not_found", HttpStatus.NOT_FOUND));
    }
    resolve(true);
  });
}
