import { HttpException, HttpStatus } from "@nestjs/common";
import { isEmpty, replace } from "lodash";
import axios, { Axios } from "axios";
import { hash } from "bcrypt";
import { nanoid } from "nanoid";

export interface Provider {
  /**
   * Redirect the user to the authentication page for the provider.
   *
   * @return
   */
  redirect();

  /**
   * Get the User instance for the authenticated user.
   *
   * @return
   */
  getUser();
}

export abstract class AbstractProvider implements Provider {
  protected request;
  protected clientId;
  protected httpClient: Axios;
  protected clientSecret;
  protected redirectUrl;
  protected parameters = [];
  protected scopes = [];
  protected scopeSeparator = ",";
  protected stateless = false;
  protected usesPKCE = false;
  protected user;
  protected axiosConfigs;

  constructor(request, clientId, clientSecret, redirectUrl, axiosConfigs) {
    this.request = request;
    this.clientId = clientId;
    this.clientSecret = clientSecret;
    this.redirectUrl = redirectUrl;
    this.axiosConfigs = axiosConfigs;
  }

  /**
   * Get the authentication URL for the provider.
   *
   * @param  string  state
   * @return string
   */
  protected abstract getAuthUrl(state);

  /**
   * Get the token URL for the provider.
   *
   * @return string
   */
  protected abstract getTokenUrl();

  /**
   * Get the raw user for the given access token.
   *
   * @param  string  token
   * @return array
   */
  protected abstract getUserByToken(token);

  /**
   * Map the raw user array to a Socialite User instance.
   *
   * @param  array  user
   */
  protected abstract mapUserToObject(user);

  /**
   * Redirect the user of the application to the provider's authentication screen.
   *
   * @return
   */
  public redirect() {
    let state = null;

    if (this.usesState()) {
      this.request["state"] = state = this.getState();
    }

    if (this.getUsesPKCE()) {
      this.request["code_verifier"] = state = this.getCodeVerifier();
    }

    return this.getAuthUrl(state);
  }

  /**
   * Get a instance of the Guzzle HTTP client.
   *
   * @return Axios
   */
  protected getHttpClient(headers = {}): Axios {
    if (isEmpty(this.httpClient)) {
      this.httpClient = axios.create({
        ...this.axiosConfigs,
        ...headers,
      });
    }
    return this.httpClient;
  }

  public async getUser() {
    if (this.user) {
      return this.user;
    }

    if (this.hasInvalidState()) {
      throw new HttpException("invalid state", HttpStatus.CONFLICT);
    }

    const response = await this.getAccessTokenResponse(this.getCode());
    return new Promise((resolve, rejects) => {
      this.getUserByToken(response.access_token)
        .then((response) => {
          this.user = response;
          resolve(response);
        })
        .catch((error) => {
          rejects(error);
        });
    });
  }

  /**
   * Build the authentication URL for the provider from the given base URL.
   *
   * @param  string  url
   * @param  string  state
   * @return string
   */
  protected buildAuthUrlFromBase(url, state) {
    return `${url}?${new URLSearchParams(
      this.getCodeFields(state)
    ).toString()}`;
  }

  /**
   * Get the GET parameters for the code request.
   *
   * @param  string|null  state
   * @return array
   */
  protected abstract getCodeFields(state);

  /**
   * Format the given scopes.
   *
   * @param  array  scopes
   * @param  string  scopeSeparator
   * @return string
   */
  protected formatScopes(scopes, scopeSeparator) {
    return scopes.join(scopeSeparator);
  }

  /**
   * Determine if the current request / session has a mismatching "state".
   *
   * @return bool
   */
  protected hasInvalidState() {
    if (this.isStateless()) {
      return false;
    }
  }

  /**
   * Get the access token response for the given code.
   *
   * @param  string  code
   * @return array
   */
  public async getAccessTokenResponse(code) {
    const response = await this.getHttpClient().post(
      this.getTokenUrl(),
      this.getTokenFields(code),
      {
        headers: {
          Accept: "application/json",
        },
      }
    );
    return response.data;
  }

  /**
   * Determine if the provider is operating as stateless.
   *
   * @return bool
   */
  protected isStateless() {
    return this.stateless;
  }

  /**
   * Get the string used for session state.
   *
   * @return string
   */
  protected getState() {
    return nanoid(40);
  }

  /**
   * Determine if the provider uses PKCE.
   *
   * @return bool
   */
  protected getUsesPKCE() {
    return this.usesPKCE;
  }

  /**
   * Enables PKCE for the provider.
   *
   * @return this
   */
  public enablePKCE() {
    this.usesPKCE = true;

    return this;
  }

  /**
   * Generates a random string of the right length for the PKCE code verifier.
   *
   * @return string
   */
  protected getCodeVerifier() {
    return nanoid(96);
  }

  /**
   * Get the code from the request.
   *
   * @return string
   */
  protected getCode() {
    return this.request["code"];
  }

  /**
   * Get the current scopes.
   *
   * @return array
   */
  public getScopes() {
    return this.scopes;
  }

  /**
   * Set the redirect URL.
   *
   * @param  string  url
   * @return this
   */
  public setRedirectUrl(url) {
    this.redirectUrl = url;

    return this;
  }

  protected usesState() {
    return !this.stateless;
  }

  /**
   * Get the POST fields for the token request.
   *
   * @param  string  code
   * @return array
   */
  protected abstract getTokenFields(code);

  /**
   * Generates the PKCE code challenge based on the PKCE code verifier in the session.
   *
   * @return string
   */
  protected async getCodeChallenge() {
    const hashed = await hash("sha256", this.request["code_verifier"]);

    return replace(
      replace(Buffer.from(hashed).toString("base64"), "+/", "-_"),
      "=",
      ""
    );
  }

  /**
   * Returns the hash method used to calculate the PKCE code challenge.
   *
   * @return string
   */
  protected getCodeChallengeMethod() {
    return "S256";
  }
}
