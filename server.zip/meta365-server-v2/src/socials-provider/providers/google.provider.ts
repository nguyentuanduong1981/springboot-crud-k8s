import { download } from "src/utilities/helpers";
import { AbstractProvider, Provider } from "../abstract.provider";
import { v4 as uuidv4 } from "uuid";

export class GoogleProvider extends AbstractProvider implements Provider {
  /**
   * The separating character for the requested scopes.
   *
   * @var string
   */
  protected scopeSeparator = " ";

  /**
   * The scopes being requested.
   *
   * @var array
   */
  protected scopes = ["openid", "profile", "email"];

  /**
   * {@inheritdoc}
   */
  protected getAuthUrl(state) {
    return this.buildAuthUrlFromBase(
      "https://accounts.google.com/o/oauth2/auth",
      state
    );
  }

  /**
   * {@inheritdoc}
   */
  protected getTokenUrl() {
    return "https://www.googleapis.com/oauth2/v4/token";
  }

  /**
   * {@inheritdoc}
   */
  protected async getUserByToken(token) {
    const response = await this.getHttpClient({
      "content-type": "application/x-www-form-urlencoded",
    }).get("https://www.googleapis.com/oauth2/v3/userinfo", {
      headers: {
        Accept: "applicaon/json",
        Authorization: `Bearer ${token}`,
      },
    });

    return this.mapUserToObject(response.data);
  }
  /**
   * {@inheritdoc}
   */
  protected async mapUserToObject(user) {
    const avatar = `avatar/${uuidv4()}.jpeg`;
    await download(user.picture, `static/images/${avatar}`);
    const { sub: id, name, email, email_verified } = user;
    return {
      avatar,
      id,
      name,
      email,
      verifiedEmailAt: email_verified ? new Date().toISOString() : null,
    };
  }

  /**
   * Get the GET parameters for the code request.
   *
   * @param  string|null  state
   * @return array
   */
  protected getCodeFields(state = null) {
    let fields = {
      client_id: this.clientId,
      redirect_uri: this.redirectUrl,
      scope: this.formatScopes(this.getScopes(), this.scopeSeparator),
      response_type: "code",
    };

    if (this.usesState()) {
      fields["state"] = state;
    }

    if (this.getUsesPKCE()) {
      fields["code_challenge"] = this.getCodeChallenge();
      fields["code_challenge_method"] = this.getCodeChallengeMethod();
    }

    return { ...fields, ...this.parameters };
  }

  /**
   * Get the POST fields for the token request.
   *
   * @param  string  code
   * @return array
   */
  getTokenFields(code) {
    const fields = {
      grant_type: "authorization_code",
      client_id: this.clientId,
      client_secret: this.clientSecret,
      code,
      redirect_uri: this.redirectUrl,
    };

    if (this.usesPKCE) {
      fields["code_verifier"] = this.request["code_verifier"];
    }

    return fields;
  }
}
