import { AbstractProvider, Provider } from "../abstract.provider";
import { v4 as uuidv4 } from "uuid";
import { download } from "src/utilities/helpers";

export class FacebookProvider extends AbstractProvider implements Provider {
  /**
   * The base Facebook Graph URL.
   *
   * @var string
   */
  protected graphUrl = "https://graph.facebook.com";

  /**
   * The Graph API version for the request.
   *
   * @var string
   */
  protected version = "v14.0";

  /**
   * The user fields being requested.
   *
   * @var array
   */
  protected fields = [
    "name",
    "email",
    "gender",
    "verified",
    "link",
    "birthday",
  ];

  /**
   * The scopes being requested.
   *
   * @var array
   */
  protected scopes = ["email"];

  /**
   * Display the dialog in a popup view.
   *
   * @var bool
   */
  protected popup = false;

  /**
   * Re-request a declined permission.
   *
   * @var bool
   */
  protected reRequest = false;

  /**
   * The access token that was last used to retrieve a user.
   *
   * @var string|null
   */
  protected lastToken;

  /**
   * {@inheritdoc}
   */
  protected getAuthUrl(state) {
    return this.buildAuthUrlFromBase(
      `https://www.facebook.com/${this.version}/dialog/oauth`,
      state
    );
  }

  /**
   * {@inheritdoc}
   */
  protected getTokenUrl() {
    return `${this.graphUrl}/${this.version}/oauth/access_token`;
  }

  /**
   * {@inheritdoc}
   */
  public async getAccessTokenResponse(code) {
    const response = await this.getHttpClient().post(
      this.getTokenUrl(),
      this.getTokenFields(code),
      {
        headers: {
          Accept: "application/json",
        },
      }
    );

    return response.data;
  }

  /**
   * {@inheritdoc}
   */
  protected getUserByToken(token) {
    return new Promise((resolve, rejects) => {
      this.lastToken = token;

      const params = {
        access_token: token,
        fields: this.fields.join(","),
      };

      // if (!isEmpty(this.clientSecret)) {
      //   params['appsecret_proof'] = CryptoJS.HmacSHA256(token, this.clientSecret)
      // }

      return this.getHttpClient()
        .get(`${this.graphUrl}/${this.version}/me`, {
          params,
          headers: {
            Accept: "application/json",
          },
        })
        .then(async (response) => {
          const user = await this.mapUserToObject(response.data);
          resolve(user);
        })
        .catch((error) => {
          rejects(error);
        });
    });
  }

  /**
   * {@inheritdoc}
   */
  protected async mapUserToObject(user) {
    const url = `${this.graphUrl}/${this.version}/${user["id"]}/picture?access_token=${this.lastToken}&width=320&height=330`;
    const avatar = `avatar/${uuidv4()}.jpeg`;
    await download(url, `static/images/${avatar}`);
    user.avatar = avatar;
    user.verifiedEmailAt = new Date().toISOString();
    return user;
  }

  /**
   * Get the GET parameters for the code request.
   *
   * @param  string|null  state
   * @return array
   */
  protected getCodeFields(state = null) {
    let fields = {
      client_id: this.clientId,
      redirect_uri: this.redirectUrl,
      scope: this.formatScopes(this.getScopes(), this.scopeSeparator),
      response_type: "code",
    };

    if (this.usesState()) {
      fields["state"] = state;
    }

    if (this.getUsesPKCE()) {
      fields["code_challenge"] = this.getCodeChallenge();
      fields["code_challenge_method"] = this.getCodeChallengeMethod();
    }

    return { ...fields, ...this.parameters };
  }

  /**
   * Set the user fields to request from Facebook.
   *
   * @param  array  fields
   * @return this
   */
  public setFields(fields: any[]) {
    this.fields = fields;

    return this;
  }

  /**
   * Set the dialog to be displayed as a popup.
   *
   * @return this
   */
  public asPopup() {
    this.popup = true;

    return this;
  }

  /**
   * Re-request permissions which were previously declined.
   *
   * @return this
   */
  public setReRequest() {
    this.reRequest = true;

    return this;
  }

  /**
   * Get the last access token used.
   *
   * @return string|null
   */
  public setLastToken() {
    return this.lastToken;
  }

  /**
   * Specify which graph version should be used.
   *
   * @param  string  version
   * @return this
   */
  public usingGraphVersion(version) {
    this.version = version;

    return this;
  }

  /**
   * Get the POST fields for the token request.
   *
   * @param  string  code
   * @return array
   */
  protected getTokenFields(code) {
    const fields = {
      grant_type: "authorization_code",
      client_id: this.clientId,
      client_secret: this.clientSecret,
      code,
      redirect_uri: this.redirectUrl,
    };

    if (this.usesPKCE) {
      fields["code_verifier"] = this.request["code_verifier"];
    }

    return fields;
  }
}
