import { AbstractProvider, Provider } from "../abstract.provider";

export class ZaloProvider extends AbstractProvider implements Provider {
  /**
   * Unique Provider Identifier.
   */
  public IDENTIFIER = "ZALO";

  /**
   * {@inheritdoc}
   */
  protected scopes = [""];

  /**
   * {@inheritdoc}
   */
  protected getAuthUrl(state) {
    return this.buildAuthUrlFromBase(
      "https://oauth.zaloapp.com/v3/auth",
      state
    );
  }

  /**
   * {@inheritdoc}
   */
  protected getCodeFields(state = null) {
    const fields = {
      app_id: this.clientId,
      redirect_uri: this.redirectUrl,
      state,
    };

    return { ...fields, ...this.parameters };
  }

  /**
   * {@inheritdoc}
   */
  public async getAccessTokenResponse(code) {
    const response = await this.getHttpClient().get(this.getTokenUrl(), {
      headers: { Accept: "application/json" },
      params: this.getTokenFields(code),
    });

    return response.data;
  }

  /**
   * {@inheritdoc}
   */
  protected getTokenUrl() {
    return "https://oauth.zaloapp.com/v3/access_token";
  }

  /**
   * {@inheritdoc}
   */
  protected getUserByToken(token) {
    const response = this.getHttpClient().get(
      `https://graph.zalo.me/v2.0/me?access_token=${token}&fields=id,birthday,name,gender,picture`
    );

    return response;
  }

  /**
   * {@inheritdoc}
   */
  protected mapUserToObject(user) {
    return user;
  }

  /**
   * {@inheritdoc}
   */
  protected getTokenFields(code) {
    return {
      app_id: this.clientId,
      app_secret: this.clientSecret,
      code,
      redirect_uri: this.redirectUrl,
    };
  }
}
