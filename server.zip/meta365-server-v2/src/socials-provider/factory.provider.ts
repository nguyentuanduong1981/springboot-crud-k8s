import { GoogleProvider } from "./providers/google.provider";
import { ZaloProvider } from "./providers/zalo.provider";
import { FacebookProvider } from "./providers/facebook.provider";

const storeMap = {
  facebook: FacebookProvider,
  google: GoogleProvider,
  zalo: ZaloProvider,
};
export class SocialProviderFactory {
  protected config;
  protected instances;
  protected request;
  constructor(request, config) {
    this.config = config;
    this.request = request;
    this.instances = {};
  }

  getConfig(provider) {
    return this.config[provider];
  }

  getProvider(provider) {
    let ProviderClass = storeMap[provider];
    if (!ProviderClass) {
      throw new Error("Invalid provider: " + provider);
    }

    let storeInstance = this.instances[provider];
    if (!storeInstance) {
      storeInstance = new ProviderClass(
        this.request,
        this.getConfig(provider).client_id,
        this.getConfig(provider).client_secret,
        this.getConfig(provider).redirect
      );
      this.instances[provider] = storeInstance;
    }

    return storeInstance;
  }
}
