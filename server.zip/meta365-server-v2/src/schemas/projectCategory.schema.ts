import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";

export type ProjectCategoryDocument = ProjectCategory & Document;

@Schema()
export class ProjectCategory {
  @Prop()
  name: string;

  @Prop()
  slug: string;

  @Prop({
    default: Date.now(),
  })
  createdAt: Date;

  @Prop({
    default: Date.now(),
  })
  updatedAt: Date;
}

export const ProjectCategorySchema =
  SchemaFactory.createForClass(ProjectCategory);
