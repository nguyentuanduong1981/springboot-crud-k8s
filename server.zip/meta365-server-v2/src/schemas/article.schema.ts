import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from "mongoose";
import * as mongoose from "mongoose";
import { User } from "./user.schema";
import { ArticleStatus } from "src/utilities/constants";

export type ArticleDocument = Article & Document;

@Schema()
export class Article {
  @Prop({
    required: true,
    unique: true,
  })
  title: string;

  @Prop({
    required: true,
  })
  content: string;

  @Prop({
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  })
  author: User;

  @Prop({
    default: ArticleStatus.PRIVATE,
    enum: ArticleStatus,
  })
  status: ArticleStatus;

  @Prop({
    default: true,
  })
  isActive: boolean;

  @Prop({
    default: "",
  })
  thumbnail: string;

  @Prop({
    default: Date.now(),
  })
  createdAt: Date;

  @Prop({
    default: Date.now(),
  })
  updatedAt: Date;
}

export const ArticleSchema = SchemaFactory.createForClass(Article);
