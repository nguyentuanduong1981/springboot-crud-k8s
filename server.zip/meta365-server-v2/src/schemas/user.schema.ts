import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document, ObjectId } from "mongoose";
import { Schema as MongooseSchema } from "mongoose";
import { Link } from "./link.schema";
import { Transform, Type } from "class-transformer";
import { Agent } from "./agent.schema";
import { FavoriteType, Gender, UserType } from "src/utilities/constants";
import errors from "src/commons/errors/errors.validator";
import { Project } from "./project.schema";

export type UserDocument = User & Document;

export interface Social {
  key: string;
  value: string;
}

export interface Favorite {
  favoriteType: FavoriteType;
  id: any;
}
@Schema()
export class User {
  @Transform(({ value }) => value.toString())
  _id: ObjectId;

  @Prop({
    trim: true,
    sparse: true,
    index: {
      unique: true,
      partialFilterExpression: { username: { $type: "string" } },
    },
    default: `user${Math.floor(Math.random() * 100000000)}`,
  })
  username: string;

  @Prop({
    required: false,
    name: "full_name",
  })
  fullName: string;

  @Prop({
    // select: false,
    trim: true,
    minlength: 8,
  })
  password: string;

  @Prop({
    unique: true,
    required: false,
    trim: true,
    sparse: true,
    index: {
      unique: true,
      partialFilterExpression: { email: { $type: "string" } },
    },
    default: null,
  })
  email: string;

  @Prop({
    required: false,
  })
  description: string;

  @Prop({
    required: false,
  })
  facebookId: string;

  @Prop({
    required: false,
  })
  googleId: string;

  @Prop({
    required: false,
  })
  zaloId: string;

  @Prop({
    required: false,
  })
  avatar: string;

  @Prop({
    required: false,
  })
  cover: string;

  @Prop({
    enum: Gender,
    default: Gender.PREFER_NOT_TO_SAY,
  })
  gender: Gender;

  @Prop({
    required: false,
  })
  country: string;

  @Prop({
    required: false,
    trim: true,
    sparse: true,
    index: {
      unique: true,
      partialFilterExpression: { phoneNumber: { $type: "string" } },
    },
    default: null,
    name: "phone_number",
  })
  phoneNumber: string;

  @Prop({
    default: Math.floor(Math.random() * 10000000),
  })
  nonce: string;

  @Prop()
  chainId: number;

  @Prop({
    required: false,
    trim: true,
    sparse: true,
    index: {
      unique: true,
      partialFilterExpression: { publicAddress: { $type: "string" } },
    },
    default: null,
    lowercase: true,
  })
  publicAddress: string;

  @Prop({
    default: "",
    required: false,
    name: "referral_address",
  })
  referralAddress: string;

  @Prop({
    default: null,
    type: Date,
    comment: "xac minh dien thoai",
  })
  verifiedPhoneAt: Date;

  @Prop({
    default: null,
    type: Date,
    comment: "xac minh email",
  })
  verifiedEmailAt: Date;

  @Prop({
    default: true,
  })
  isActive: boolean;

  @Prop({
    default: false,
  })
  isBlocked: boolean;

  @Prop({
    default: new Date(),
  })
  createdAt: Date;

  @Prop({
    _id: false,
    default: [],
    type: [
      {
        key: {
          type: String,
        },
        value: {
          type: String,
        },
      },
    ],
    required: false,
  })
  socials: Social[];

  @Prop({
    required: false,
    enum: ["Project"],
    type: String,
  })
  favoriteTypeRef: String;

  @Prop({
    _id: false,
    default: [],
    type: [
      {
        favoriteType: {
          type: String,
        },
        id: {
          required: true,
          refPath: "favoriteTypeRef",
          type: MongooseSchema.Types.ObjectId,
        },
      },
    ],
    required: false,
  })
  favorites: Favorite[];

  @Prop({
    default: UserType.NORMAL,
    enum: UserType,
  })
  userType: UserType;

  @Prop({
    required: false,
    type: MongooseSchema.Types.ObjectId,
    ref: "Agent",
  })
  agent: Agent;

  @Prop({
    required: false,
    type: MongooseSchema.Types.ObjectId,
    ref: "Agent",
  })
  ownerOfAgent: Agent;

  @Prop()
  actions: Array<string>;

  @Prop({
    type: [{ type: MongooseSchema.Types.ObjectId, ref: "Link" }],
    required: false,
  })
  // @Type(() => Link)
  links: Link[];
}

const UserSchema = SchemaFactory.createForClass(User);
// UserSchema.virtual('Project', {
//   ref: 'Link',
//   localField: '_id',
//   foreignField: 'project'
// });

export { UserSchema };
