import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from "mongoose";
import * as mongoose from "mongoose";
import { Project } from "./project.schema";
import { User } from "./user.schema";

export type LandDocument = Land & Document;

@Schema()
export class Land {
  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Project",
  })
  projectId: Project;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  })
  userId: User;

  @Prop({ default: "" })
  direction: string;

  @Prop({ default: "" })
  landCode: string;

  @Prop({ default: "" })
  landBlockCode: string;

  @Prop({ default: 0 })
  squares: number;

  @Prop()
  ratio: string;

  @Prop()
  location: string;

  @Prop()
  images: [];

  @Prop()
  thumbnail: string;

  @Prop()
  ownershipCerDate: Date;

  @Prop()
  startDate: Date;

  @Prop({ default: "" })
  ownershipCerProvider: string;

  @Prop({ default: "" })
  landUseTerm: string;

  @Prop({ default: "" })
  landUseType: string;

  @Prop({ default: "" })
  landUsePurpose: string;

  @Prop({ default: "" })
  landUseOriginal: string;

  @Prop({ default: "" })
  legal: string;

  @Prop({ default: "" })
  price: string;

  @Prop({ default: "" })
  author: string;

  @Prop({ default: "" })
  media: string;

  @Prop({ default: "" })
  delegate: string;

  @Prop({ default: "" })
  numOfNft: string;

  @Prop({ default: 0 })
  type: number;

  @Prop({ default: 0 })
  status: number;
}

export const LandSchema = SchemaFactory.createForClass(Land);
