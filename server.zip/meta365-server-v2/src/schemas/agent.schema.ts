import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Type } from "class-transformer";
import { Document, Schema as MongooseSchema } from "mongoose";
import { AgentType, Status, AgencyRole } from "src/utilities/constants";
import { Project } from "./project.schema";
import { Social, User } from "./user.schema";

export type AgentDocument = Agent & Document;

@Schema()
export class Agent {
  @Prop({
    required: true,
    name: "name",
  })
  name: string;

  @Prop({
    unique: true,
    required: true,
    name: "name",
  })
  shortName: string;

  @Prop({
    name: "logo",
  })
  logo: string;

  @Prop({
    required: true,
    name: "address",
  })
  address: string;

  @Prop({
    unique: true,
    required: true,
    name: "Tax Code",
  })
  taxCode: string;

  @Prop({
    unique: true,
    required: true,
  })
  email: string;

  @Prop({
    required: true,
    unique: true,
    name: "phone_number",
  })
  phoneNumber: number;

  @Prop({
    default: "",
  })
  termOfUse: string;

  @Prop({
    type: String,
    enum: AgentType,
    default: AgentType.AGENCY,
  })
  agentType: AgentType;

  @Prop({
    type: String,
    enum: Status,
    default: Status.PENDING,
  })
  status: Status;

  @Prop({
    _id: false,
    default: [],
    type: [
      {
        key: {
          type: String,
        },
        value: {
          type: String,
        },
      },
    ],
    required: true,
  })
  socials: Social[];

  @Prop({
    default: false,
  })
  isActive: boolean;

  @Prop({
    default: false,
  })
  isBlocked: boolean;

  @Prop({
    default: new Date(),
  })
  createdAt: Date;

  @Prop({
    type: [{ type: MongooseSchema.Types.ObjectId, ref: "Project" }],
    required: false,
  })
  @Type(() => Project)
  projects: Project[];

  @Prop({
    type: [
      {
        info: {
          type: MongooseSchema.Types.ObjectId,
          ref: "User",
        },
        role: {
          type: String,
          enum: AgencyRole,
          default: AgencyRole.MEMBER,
        },
      },
    ],
    required: false,
  })
  // @Type(() => Link)
  members: {
    info: User;
    role: AgencyRole;
  }[];

  @Prop({
    required: false,
    type: MongooseSchema.Types.ObjectId,
    ref: "User",
  })
  owner: User;
}

export const AgentSchema = SchemaFactory.createForClass(Agent);
