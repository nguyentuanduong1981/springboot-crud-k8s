import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Transform, Type } from "class-transformer";
import { Schema as MongooseSchema } from "mongoose";
import { Document, ObjectId } from "mongoose";
import { ProjectPhases, ProjectStatus } from "src/utilities/constants";
import { Agent } from "./agent.schema";
import { Link } from "./link.schema";
import { Social, User } from "./user.schema";
export type ProjectDocument = Project & Document;

export interface Seo {
  keywords: string[];
  title: string;
  description: string;
}

//**get theo id */
@Schema()
export class Project {
  @Transform(({ value }) => value.toString())
  _id: ObjectId;

  @Prop({
    required: true,
    index: true,
  })
  name: string;

  @Prop()
  description: string;

  @Prop({
    default: "",
    required: false,
  })
  totalArea: string;

  @Prop({
    default: {
      province: 0,
      district: 0,
      village: 0,
    },
    type: {
      province: {
        type: Number,
      },
      district: {
        type: Number,
      },
      village: {
        type: Number,
      },
    },
    required: true,
  })
  location: Object;

  @Prop({
    default: {
      latitude: 0,
      longitude: 0,
    },
    type: {
      latitude: {
        type: String,
      },
      longitude: {
        type: String,
      },
    },
    required: true,
  })
  coordinates: Object;

  @Prop({
    default: "",
  })
  detailLocation: string;

  @Prop({
    required: false,
  })
  totalInvestment: number;

  @Prop()
  type: string;

  @Prop({
    required: false,
  })
  commencementDate: Date;

  @Prop({
    required: false,
  })
  finishedDate: Date;

  @Prop({
    required: true,
  })
  investor: string;

  @Prop({
    required: false,
  })
  developmentUnit: string;

  @Prop({
    required: false,
  })
  constructionContractor: string;

  @Prop({
    required: false,
  })
  projectScale: string;

  @Prop({
    required: false,
  })
  designConsultingUnit: string;

  @Prop({
    default: "",
  })
  logo: string;

  @Prop({
    default: "",
  })
  ground: string;

  @Prop({
    default: [],
  })
  images: string[];

  @Prop({
    default: "",
  })
  media: string;

  @Prop({
    default: "",
    required: false,
  })
  termOfUse: string;

  @Prop({
    default: "",
    required: false,
  })
  legal: string;

  @Prop({
    default: true,
  })
  isActive: boolean;

  @Prop({
    default: Date.now,
  })
  createdAt: Date;

  @Prop({
    enum: ProjectStatus,
    default: ProjectStatus.PUBLIC,
  })
  status: ProjectStatus;

  @Prop({
    _id: false,
    default: [],
    type: [
      {
        key: {
          type: String,
        },
        value: {
          type: String,
        },
      },
    ],
    required: false,
  })
  socials: Social[];

  @Prop({
    _id: false,
    type: {
      keywords: {
        type: Array,
      },
      title: {
        type: String,
      },
      description: {
        type: String,
      },
    },
    required: false,
  })
  seo: Seo;

  @Prop({
    enum: ProjectPhases,
    default: ProjectPhases.OPEN_FOR_SALE,
  })
  phase: ProjectPhases;

  @Prop({
    type: [{ type: MongooseSchema.Types.ObjectId, ref: "Link" }],
    required: false,
  })
  @Type(() => Link)
  links: Link[];

  @Prop({
    required: false,
    type: MongooseSchema.Types.ObjectId,
    ref: "Agent",
  })
  owner: Agent;
}

const ProjectSchema = SchemaFactory.createForClass(Project);

export { ProjectSchema };
