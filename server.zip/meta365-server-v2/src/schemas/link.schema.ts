import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Transform, Type } from "class-transformer";
import { Schema as MongooseSchema } from "mongoose";
import { Document, ObjectId } from "mongoose";
import { Project } from "./project.schema";
import { User } from "./user.schema";

export type LinkDocument = Link & Document;

@Schema()
export class Link {
  @Transform(({ value }) => value.toString())
  _id: ObjectId;

  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: "User",
    select: ["_id", "avatar"],
  })
  @Type(() => User)
  user: User;

  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: "Project",
    required: false,
  })
  @Type(() => Project)
  project: Project;

  @Prop({
    required: true,
  })
  qr: string;

  @Prop({
    default: new Date(),
  })
  createdAt: Date;
}

export const LinkSchema = SchemaFactory.createForClass(Link);
