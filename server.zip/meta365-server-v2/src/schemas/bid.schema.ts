import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from "mongoose";

export type BidDocument = Bid & Document;

@Schema()
export class Bid {
  @Prop()
  marketplace: string;

  @Prop({
    required: true,
  })
  walletAddress: string;

  @Prop({
    required: true,
  })
  price: number;
}

export const BidSchema = SchemaFactory.createForClass(Bid);
