import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from "mongoose";
import * as mongoose from "mongoose";
import { Project } from "./project.schema";
import { Land } from "./land.schema";
import { User } from "./user.schema";
import { Timestamp } from "rxjs";

export type TransactionDocument = Transaction & Document;

@Schema()
export class Transaction {
  @Prop({
    required: true,
  })
  name: string;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Land",
  })
  landId: Land;

  @Prop({
    required: true,
  })
  landName: string;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "Project",
  })
  projectId: Project;

  @Prop({
    default: "",
  })
  projectName: string;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  })
  from: User;

  @Prop({
    required: true,
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  })
  to: User;

  @Prop({
    required: true,
  })
  value: string;

  @Prop({
    required: true,
  })
  start: Date;

  @Prop({
    required: true,
  })
  duration: number;

  @Prop()
  error: string;

  @Prop()
  status: string;

  @Prop()
  tokenId: string;

  @Prop()
  floor: string;
}

export const TransactionSchema = SchemaFactory.createForClass(Transaction);
