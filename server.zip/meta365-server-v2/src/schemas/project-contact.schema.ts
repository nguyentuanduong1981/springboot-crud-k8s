import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Project } from "./project.schema";
import { Schema as MongooseSchema } from "mongoose";
import { ContactStatus } from "src/utilities/constants";

export type ProjectContactDocument = ProjectContact & Document;

@Schema()
export class ProjectContact {
  @Prop({
    required: true,
    type: MongooseSchema.Types.ObjectId,
    ref: "Project",
  })
  project: Project;

  @Prop({
    required: true,
    name: "full_name",
  })
  fullName: string;

  @Prop({
    required: true,
    trim: true,
    sparse: true,
    name: "phone_number",
  })
  phoneNumber: string;

  @Prop({
    required: false,
  })
  country: string;

  @Prop({
    required: true,
  })
  content: string;

  @Prop({
    enum: ContactStatus,
    default: ContactStatus.PENDING,
  })
  status: ContactStatus;
}

export const ProjectContactSchema =
  SchemaFactory.createForClass(ProjectContact);
