import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from "mongoose";
import * as mongoose from "mongoose";
import { Project } from "./project.schema";
import { Land } from "./land.schema";
import { User } from "./user.schema";
import { Timestamp } from "rxjs";

export type NotificationDocument = Notification & Document;

@Schema()
export class Notification {
  @Prop({
    required: true,
  })
  receivedId: string;

  @Prop({
    required: true,
  })
  receivedType: string;

  @Prop({
    default: false,
  })
  isRead: boolean;

  @Prop({
    required: true,
  })
  title: string;

  @Prop({
    required: true,
  })
  content: string;

  @Prop()
  metaData: string;

  @Prop()
  notifyResourceType: string;

  @Prop()
  notifyResourceId: string;

  @Prop()
  notifyType: string;

  @Prop()
  createdDate: Date;

  @Prop()
  status: string;
}

export const NotificationSchema = SchemaFactory.createForClass(Notification);
