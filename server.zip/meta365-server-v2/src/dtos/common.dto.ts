import { IsString, IsNumber, IsOptional, IsArray } from "class-validator";
import { ApiProperty } from "@nestjs/swagger";
import { Type } from "class-transformer";

export class findAll {
  [x: string]: any | number;

  @IsOptional()
  @ApiProperty({
    type: Number,
    required: false,
  })
  @IsOptional()
  @IsNumber()
  @Type(() => Number)
  limit: number;

  @IsOptional()
  @ApiProperty({
    type: Number,
    required: false,
  })
  @IsNumber()
  @Type(() => Number)
  page: number;
}

export class DeleteDto {
  @ApiProperty()
  @IsArray()
  id: number[];
}

export class AssetDto {
  [x: string]: String;
}
