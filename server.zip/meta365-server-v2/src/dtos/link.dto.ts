import { ApiProperty } from "@nestjs/swagger";
import { IsString } from "class-validator";

export class CreateLinkDto {
  @ApiProperty({
    example: "project_id",
    name: "project_id",
    description: "Project Id",
    type: String,
  })
  @IsString()
  project_id: string;

  // @ApiProperty({
  //   name: 'qr',
  //   description: 'QR code',
  //   example: 'data:image/png:base64,.....',
  //   type: String
  // })
  // @IsString()
  // qr: string;
}
