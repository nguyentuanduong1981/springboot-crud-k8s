import { ApiConsumes, ApiProperty } from "@nestjs/swagger";
import {
  ArrayMinSize,
  IsArray,
  IsBoolean,
  IsEmail,
  IsEnum,
  IsOptional,
  IsString,
  Matches,
} from "class-validator";
import { Types } from "mongoose";
import { Social } from "src/schemas/user.schema";
import { AgentType, GenerateLinkList } from "src/utilities/constants";
import { IsSocialLink, IsTrue } from "src/validators/index.validator";
import { array } from "yargs";

export class GenerateLinkForMemberDto {
  @ApiProperty({
    example: "62beccc3138a81a79d322f4d",
    name: "project",
    type: String,
  })
  @IsString()
  project: string;

  @ApiProperty({
    name: "list",
    default: GenerateLinkList.ALL,
    example: GenerateLinkList.ALL,
    enum: GenerateLinkList,
  })
  @IsEnum(GenerateLinkList)
  list: GenerateLinkList;

  @ApiProperty({
    name: "members",
    type: Array,
    example: ["62beccc3138a81a79d322f4d"],
  })
  @IsOptional()
  @IsArray()
  members?: Types.ObjectId[];
}

export class BecomeAnAgentDto {
  @ApiProperty({ type: "string", format: "binary" })
  @IsOptional()
  logo?: any;

  @ApiProperty({ type: "string", format: "binary" })
  @IsOptional()
  cover?: any;

  @ApiProperty({
    example: "name",
    name: "name",
    type: String,
  })
  @IsString()
  name: string;

  @ApiProperty({
    example: "shortName",
    name: "shortName",
    type: String,
  })
  @IsString()
  shortName: string;

  @ApiProperty({
    example: false,
    name: "accept",
    type: Boolean,
  })
  @IsBoolean()
  @IsTrue()
  accept: boolean;

  @ApiProperty({
    name: "address",
    example: "address",
    type: String,
  })
  @IsString()
  address: string;

  @ApiProperty({
    name: "taxCode",
    example: "taxCode",
    type: String,
  })
  @IsString()
  taxCode: string;

  @ApiProperty({
    name: "email",
    example: "email",
    type: String,
  })
  @IsEmail()
  @IsString()
  email: string;

  @ApiProperty({
    name: "phoneNumber",
    example: "phoneNumber",
    type: String,
  })
  @IsString()
  @Matches(
    /([+84|84|0]+(3+[2-9]|5+[6|8|9]|7+[0|6|7|8|9]|8+[1-9]|9+[1-4|6-9]))+([0-9]{7})\b/,
    {
      message: "notification.error.phoneNumber_is_invalid",
    }
  )
  phoneNumber: string;

  @ApiProperty({
    name: "termOfUse",
    example: "termOfUse",
    type: String,
  })
  @IsString()
  @IsOptional()
  termOfUse?: string;

  @ApiProperty({
    name: "agentType",
    default: AgentType.AGENCY,
    example: AgentType.AGENCY,
    enum: AgentType,
  })
  @IsEnum(AgentType)
  agentType: AgentType;

  @ApiProperty({
    default: [
      {
        key: "",
        value: "",
      },
    ],
  })
  @IsSocialLink()
  @ArrayMinSize(1)
  @IsOptional()
  @IsArray()
  socials?: Social[];
}
