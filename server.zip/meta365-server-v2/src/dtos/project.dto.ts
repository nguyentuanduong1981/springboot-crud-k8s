import {
  IsString,
  IsNumber,
  IsOptional,
  IsBoolean,
  IsArray,
  IsDate,
  IsEnum,
  IsNotEmpty,
  IsObject,
  IsNotEmptyObject,
  IsDateString,
  isEnum,
  ArrayMinSize,
  MaxLength,
} from "class-validator";
import { ApiParam, ApiProperty } from "@nestjs/swagger";
import { ProjectPhases, ProjectStatus } from "src/utilities/constants";
import { Seo } from "src/schemas/project.schema";

export interface Location {
  province: number;
  district: number;
  village: number;
}

export interface Coordinates {
  latitude: number;
  longitude: number;
}

export interface Project {
  name: string;
  description: string;
  totalArea?: string;
  detailLocation: string;
  location: Location;
  coordinates: Coordinates;
  totalInvestment?: string;
  commencementDate?: Date;
  type: string;
  finishedDate?: string;
  investor: string;
  developmentUnit?: string;
  constructionContractor: string;
  projectScale: string;
  designConsultingUnit: string;
  legal: string;
  images: string[];
  author: string;
  ground: string;
  status: ProjectStatus;
  phase: ProjectPhases;
}
/*
  {
    description: 'description',
    example: {
      name: 'name',
      description: 'description',
      totalArea: '10000',
      detailLocation: '',
      location: {
        province: 0,
        district: 0,
        village: 0
      },
      totalInvestment: '',
      commencementDate: new Date(),
      type: 'type',
      finishedDate: new Date(),
      developmentUnit: 'developmentUnit',
      investor: 'investor',
      images: ['/project-image-2.png', '/project-image-2.png'],
      author: 'author',
      media: 'media',
      status: ProjectStatus
    }
  }
*/
export class CreateProjectDto {
  @ApiProperty({
    description: "Logo",
    type: "string",
    format: "binary",
  })
  @IsOptional()
  logo?: any;

  @ApiProperty({
    description: "Attachments",
    type: "array",
    items: {
      type: "file",
      items: {
        type: "string",
        format: "binary",
      },
    },
  })
  images?: any[];

  @ApiProperty({
    example: "name",
    name: "name",
    type: String,
  })
  @IsString()
  name: string;

  @ApiProperty({
    name: "description",
    example: "description",
    type: String,
  })
  @IsString()
  description: string;

  @ApiProperty({
    name: "totalArea",
    example: "totalArea",
    type: String,
    required: false,
  })
  @IsString()
  totalArea?: string;

  @ApiProperty({
    name: "detailLocation",
    example: "detailLocation",
    type: String,
  })
  @IsString()
  detailLocation: string;

  @ApiProperty({
    name: "location",
    example: {
      province: 0,
      district: 0,
      village: 0,
    },
    type: Object,
  })
  @IsObject()
  @IsNotEmptyObject()
  location: Location;

  @ApiProperty({
    name: "coordinates",
    example: {
      latitude: 0,
      longitude: 0,
    },
    type: Object,
  })
  @IsObject()
  @IsNotEmptyObject()
  coordinates: Coordinates;

  @ApiProperty({
    name: "totalInvestment",
    example: 0,
    type: Number,
    required: false,
  })
  @IsNumber()
  @IsOptional()
  totalInvestment?: number;

  @ApiProperty({
    name: "commencementDate",
    example: new Date(),
    type: Date,
    required: false,
  })
  @IsOptional()
  @IsDateString()
  commencementDate?: Date;

  @ApiProperty({
    name: "type",
    example: "type",
    type: String,
  })
  @IsOptional()
  @IsString()
  type: string;

  @ApiProperty({
    name: "finishedDate",
    example: new Date(),
    type: Date,
    required: false,
  })
  @IsOptional()
  @IsDateString()
  finishedDate?: Date;

  @ApiProperty({
    name: "investor",
    example: "investor",
    type: String,
  })
  @IsString()
  investor: string;

  @ApiProperty({
    name: "ground",
    example: "ground",
    type: String,
    required: false,
  })
  @IsOptional()
  @IsString()
  ground?: string;

  @ApiProperty({
    name: "developmentUnit",
    example: "developmentUnit",
    type: String,
    required: false,
  })
  @IsString()
  @IsOptional()
  developmentUnit?: string;

  @ApiProperty({
    name: "constructionContractor",
    example: "constructionContractor",
    type: String,
    required: false,
  })
  @IsString()
  @IsOptional()
  constructionContractor?: string;

  @ApiProperty({
    name: "projectScale",
    example: "projectScale",
    type: String,
    required: false,
  })
  @IsOptional()
  @IsString()
  projectScale?: string;

  @ApiProperty({
    name: "designConsultingUnit",
    example: "designConsultingUnit",
    type: String,
    required: false,
  })
  @IsOptional()
  @IsString()
  designConsultingUnit?: string;

  @ApiProperty({
    name: "legal",
    example: "legal",
    type: String,
    required: false,
  })
  @IsOptional()
  @IsString()
  legal?: string;

  @ApiProperty({
    name: "media",
    example: "https://meta365.ai",
    type: String,
  })
  @IsString()
  media: string;

  @ApiProperty({
    name: "status",
    default: ProjectStatus.PUBLIC,
    example: ProjectStatus.PUBLIC,
    enum: ProjectStatus,
  })
  @IsEnum(ProjectStatus)
  status: ProjectStatus;

  @ApiProperty({
    name: "seo",
    example: {
      keywords: ["meta365"],
      title: "",
      description: "",
    },
    type: Object,
    required: false,
  })
  @IsObject()
  @IsOptional()
  @IsNotEmptyObject()
  seo?: Seo;

  @ApiProperty({
    name: "phase",
    example: ProjectPhases.OPEN_FOR_SALE,
    enum: ProjectPhases,
  })
  @IsEnum(ProjectPhases)
  phase: ProjectPhases;
}

export class UpdateProjectDto {
  @ApiProperty({
    example: "name",
    name: "name",
    type: String,
    required: false,
  })
  @IsOptional()
  @IsString()
  name?: string;

  @ApiProperty({
    name: "description",
    example: "description",
    type: String,
    required: false,
  })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({
    name: "totalArea",
    example: "totalArea",
    type: String,
    required: false,
  })
  @IsString()
  @IsOptional()
  totalArea?: string;

  @ApiProperty({
    name: "detailLocation",
    example: "detailLocation",
    type: String,
    required: false,
  })
  @IsString()
  @IsOptional()
  detailLocation?: string;

  @ApiProperty({
    name: "location",
    example: {
      province: 0,
      district: 0,
      village: 0,
    },
    type: Object,
    required: false,
  })
  @IsObject()
  @IsOptional()
  @IsNotEmptyObject()
  location?: Location;

  @ApiProperty({
    name: "coordinates",
    example: {
      latitude: 0,
      longitude: 0,
    },
    type: Object,
    required: false,
  })
  @IsObject()
  @IsOptional()
  @IsNotEmptyObject()
  coordinates?: Coordinates;

  @ApiProperty({
    name: "totalInvestment",
    example: 0,
    type: Number,
    required: false,
  })
  @IsNumber()
  @IsOptional()
  totalInvestment?: number;

  @ApiProperty({
    name: "commencementDate",
    example: new Date(),
    type: Date,
    required: false,
  })
  @IsOptional()
  @IsDateString()
  commencementDate?: Date;

  @ApiProperty({
    name: "type",
    example: "type",
    type: String,
    required: false,
  })
  @IsString()
  @IsOptional()
  type: string;

  @ApiProperty({
    name: "finishedDate",
    example: new Date(),
    type: Date,
    required: false,
  })
  @IsOptional()
  @IsDateString()
  finishedDate?: Date;

  @ApiProperty({
    name: "removedImage",
    example: ["5aa3a486-b024-4b47-b111-c4a994c7505d.jpg"],
    type: Array,
    required: false,
  })
  @IsOptional()
  @IsArray()
  removedImage?: String;

  @ApiProperty({
    required: false,
    description: "Medias",
    type: "array",
    items: {
      type: "file",
      items: {
        type: "string",
        format: "binary",
      },
    },
  })
  @IsOptional()
  images?: any[];

  @ApiProperty({
    required: false,
    description: "Logo",
    type: "string",
    format: "binary",
  })
  @IsOptional()
  logo?: any;

  @ApiProperty({
    name: "removedLogo",
    example: "1fa79bc0-843d-41ae-86ad-7f63cfbc4d0e.jpg",
    type: String,
    required: false,
  })
  @IsString()
  @IsOptional()
  removedLogo?: string;

  @ApiProperty({
    name: "investor",
    example: "investor",
    type: String,
    required: false,
  })
  @IsOptional()
  @IsString()
  investor?: string;

  @ApiProperty({
    name: "ground",
    example: "ground",
    type: String,
    required: false,
  })
  @IsOptional()
  @IsString()
  ground?: string;

  @ApiProperty({
    name: "developmentUnit",
    example: "developmentUnit",
    type: String,
    required: false,
  })
  @IsString()
  @IsOptional()
  developmentUnit?: string;

  @ApiProperty({
    name: "constructionContractor",
    example: "constructionContractor",
    type: String,
    required: false,
  })
  @IsString()
  @IsOptional()
  constructionContractor?: string;

  @ApiProperty({
    name: "projectScale",
    example: "projectScale",
    type: String,
    required: false,
  })
  @IsOptional()
  @IsString()
  projectScale?: string;

  @ApiProperty({
    name: "designConsultingUnit",
    example: "designConsultingUnit",
    type: String,
    required: false,
  })
  @IsOptional()
  @IsString()
  designConsultingUnit?: string;

  @ApiProperty({
    name: "legal",
    example: "legal",
    type: String,
    required: false,
  })
  @IsOptional()
  @IsString()
  legal?: string;

  @ApiProperty({
    name: "media",
    example: "https://meta365.ai",
    type: String,
    required: false,
  })
  @IsString()
  @IsOptional()
  media?: string;

  @ApiProperty({
    required: false,
    name: "status",
    default: ProjectStatus.PUBLIC,
    example: ProjectStatus.PUBLIC,
    enum: ProjectStatus,
  })
  @IsEnum(ProjectStatus)
  status: ProjectStatus;

  @ApiProperty({
    name: "seo",
    example: {
      keywords: ["meta365"],
      title: "",
      description: "",
    },
    type: Object,
    required: false,
  })
  @IsObject()
  @IsOptional()
  @IsNotEmptyObject()
  seo?: Seo;

  @ApiProperty({
    required: false,
    name: "phase",
    example: ProjectPhases.OPEN_FOR_SALE,
    enum: ProjectPhases,
  })
  @IsEnum(ProjectPhases)
  phase: ProjectPhases;
}

export class DeleteProjectsDto {
  @ApiProperty({
    name: "key",
  })
  @IsArray()
  @IsNotEmpty()
  @ArrayMinSize(1)
  key: string[];
}

export class ProjectCategoryDto {
  @ApiProperty({
    name: "name",
    example: "name",
    type: String,
  })
  @IsString()
  name: string;
}

export class ProjectContactDto {
  @ApiProperty({
    example: "62beccc3138a81a79d322f4d",
    name: "project",
    type: String,
  })
  @IsString()
  project: string;

  @ApiProperty({
    name: "phoneNumber",
    example: "phoneNumber",
    type: String,
  })
  @IsString()
  @IsNotEmpty()
  phoneNumber: string;

  @ApiProperty({
    name: "fullName",
    example: "fullName",
    type: String,
  })
  @IsString()
  fullName: string;

  @ApiProperty({
    name: "content",
    example: "content",
    type: String,
  })
  @IsString()
  content: string;

  @ApiProperty()
  @IsString()
  @IsOptional()
  @MaxLength(6)
  country?: string;
}
