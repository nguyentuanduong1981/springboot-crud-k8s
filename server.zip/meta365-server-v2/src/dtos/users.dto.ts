import {
  IsEmail,
  IsArray,
  IsString,
  IsNotEmpty,
  MinLength,
  Matches,
  IsOptional,
  MaxLength,
  IsNumber,
  Validate,
  IsMongoId,
  isEnum,
  IsEnum,
} from "class-validator";
import { ApiProperty } from "@nestjs/swagger";
import { IsSocialLink, IsUnique } from "src/validators/index.validator";
import { Social } from "src/schemas/user.schema";
import { FavoriteType } from "src/utilities/constants";

export class CreateUserDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  @MinLength(8)
  @Matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d!@#$%&?~]{8,}$/, {
    message:
      "notification.error.password_too_weak_or_contains_characters_that_aren't_allowed",
  })
  password: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  country: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  @Matches(
    /([+84|84|0]+(3+[2-9]|5+[6|8|9]|7+[0|6|7|8|9]|8+[1-9]|9+[1-4|6-9]))+([0-9]{7})\b/,
    {
      message: "notification.error.phoneNumber_is_invalid",
    }
  )
  phoneNumber: string;
}

export class CreateUserWithWalletDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  publicAddress: string;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  chainId: number;
}

export class LoginWithWalletDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  publicAddress: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  signature: string;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  chainId: number;
}

export class LoginDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  phoneNumber: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  // @MinLength(8)
  // @Matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d!@#$%&?~]{8,}$/, {
  //   message:
  //     "error.authentication.password_too_weak_or_contains_characters_that_aren't_allowed",
  // })
  password: string;
}

export class SocialLinkDto {
  @ApiProperty({
    default: [
      {
        key: "",
        value: "",
      },
    ],
  })
  // @ValidateNested({ each: true })
  @IsSocialLink()
  // @ArrayMinSize(1,
  //   {
  //     message: "notification.error.phoneNumber_is_invalid",
  //   }
  // )
  @IsArray()
  links: Social[];
}

export class FavoriteDto {
  @ApiProperty()
  @IsString()
  @IsMongoId()
  id: string;

  @ApiProperty({
    name: "favoriteType",
    example: FavoriteType.PROJECT,
    enum: FavoriteType,
  })
  @IsEnum(FavoriteType)
  favoriteType: FavoriteType;
}

export class UpdateProfileDto {
  @ApiProperty()
  @IsString()
  @IsOptional()
  @MaxLength(32)
  @Matches(/^[^<`!@#$%^&*()_+\-=[\]{};':"|,.<>/?~>]{6,32}$/, {
    message: "notification.error.full_name_invalid",
  })
  fullName?: string;

  @ApiProperty()
  @IsString()
  @IsOptional()
  @Matches(/^[a-zA-Z0-9.]{6,18}$/, {
    message: "notification.error.username_invalid",
  })
  @IsUnique("user")
  username?: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @IsUnique("user")
  @Matches(
    /([+84|84|0]+(3+[2-9]|5+[6|8|9]|7+[0|6|7|8|9]|8+[1-9]|9+[1-4|6-9]))+([0-9]{7})\b/,
    {
      message: "notification.error.phoneNumber_is_invalid",
    }
  )
  phoneNumber?: string;

  @ApiProperty()
  @IsString()
  @IsOptional()
  @MaxLength(6)
  country?: string;

  @ApiProperty()
  @IsEmail(
    {},
    {
      message: "notification.error.form_is_email",
    }
  )
  @IsOptional()
  @IsUnique("user")
  email?: string;

  @ApiProperty()
  @IsString()
  @IsOptional()
  @MaxLength(512)
  description?: string;
}

export class ChangePasswordDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  oldPassword: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  @MinLength(8)
  @Matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d]{8,}$/, {
    message:
      "notification.error.password_too_weak_or_contains_characters_that_aren't_allowed",
  })
  newPassword: string;
}

export class ForgotPasswordDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  username: string;

  @ApiProperty()
  @IsNotEmpty()
  code: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  @MinLength(8)
  @Matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d]{8,}$/, {
    message:
      "notification.error.password_too_weak_or_contains_characters_that_aren't_allowed",
  })
  password: string;
}
