import {
  Controller,
  Get,
  UseGuards,
  Request,
  Body,
  Put,
  UsePipes,
  Param,
  HttpException,
  HttpStatus,
  Post,
  UseInterceptors,
  UploadedFile,
  Delete,
  BadRequestException,
} from "@nestjs/common";
import BaseController from "src/commons/baseController.controller";
import { ValidUser } from "src/guards/valid-user.guard";
import { JwtAuthGuard } from "../../commons/authentication/jwt-auth.guard";
import { UserService } from "./user.service";
import {
  ApiBearerAuth,
  ApiBody,
  ApiConsumes,
  ApiParam,
  ApiTags,
} from "@nestjs/swagger";
import { omit, upperFirst } from "lodash";
import errors from "src/commons/errors/errors.validator";
import validationRequestPipe from "src/commons/pipes/request.pipe";
import { TrimPipe } from "src/commons/pipes/trim.pipe";
import {
  ChangePasswordDto,
  FavoriteDto,
  SocialLinkDto,
  UpdateProfileDto,
} from "src/dtos/users.dto";
import { fileInterceptors } from "src/utilities/helpers";
import { UserType } from "src/utilities/constants";

@Controller("")
@ApiTags("user")
export class UsersController extends BaseController {
  constructor(private readonly userService: UserService) {
    super();
  }

  private sanitizeUser(user, ignoreFields = []) {
    if (!user) {
      throw new HttpException(errors.USER_NOT_FOUND, HttpStatus.NOT_FOUND);
    }
    const sanitized = user.toObject();
    return omit(sanitized, ["password", ...ignoreFields]);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, ValidUser)
  @Get("user/profile")
  async getProfile(@Request() request) {
    const user = await this.userService.findUserById(request.user.userId);
    return this.response(this.sanitizeUser(user));
  }

  @ApiParam({
    name: "username",
    required: true,
    example: "user#1234",
  })
  @Get("user/:username")
  async getUserByUsername(@Param() param) {
    const user = await this.userService.getUserByUsername(param.username);
    if (!user) {
      throw new HttpException(errors.USER_NOT_FOUND, HttpStatus.NOT_FOUND);
    }
    return this.response(this.sanitizeUser(user));
  }

  @ApiBearerAuth()
  @UsePipes(validationRequestPipe)
  @UseGuards(JwtAuthGuard, ValidUser)
  @Put("user/profile/social-link")
  async updateProfileSocial(@Body() body: SocialLinkDto, @Request() request) {
    const user = await this.userService.updateProfile(request.user.userId, {
      socials: body.links,
    });
    return this.response({ updated: true, user: this.sanitizeUser(user) });
  }

  @ApiBearerAuth()
  @UsePipes(validationRequestPipe)
  @UseGuards(JwtAuthGuard, ValidUser)
  @Put("user/favorite")
  async addFavorite(@Body() body: FavoriteDto, @Request() request) {
    const userId = request.user.userId;
    const user = await this.userService.findUserById(userId);
    if (user.favorites.length >= 10) {
      throw new BadRequestException(errors.YOU_HAVE_FAVORED_THE_MAXIMUM);
    }
    const response = await this.userService.handleUpdateTransaction(userId, {
      $addToSet: { favorites: {
        ...body,
        favoriteTypeRef: upperFirst(body.favoriteType),
      } },
    });
    return this.response({ updated: true, user: this.sanitizeUser(response) });
  }

  @ApiBearerAuth()
  @UsePipes(validationRequestPipe)
  @UseGuards(JwtAuthGuard, ValidUser)
  @Delete("user/favorite")
  async removeFavorite(@Body() body: FavoriteDto, @Request() request) {
    const user = await this.userService.handleUpdateTransaction(
      request.user.userId,
      {
        $pull: {
          favorites: body,
        },
      }
    );
    return this.response({ updated: true, user: this.sanitizeUser(user) });
  }

  @ApiBearerAuth()
  @UsePipes(new TrimPipe(["description"]))
  @UsePipes(validationRequestPipe)
  @UseGuards(JwtAuthGuard, ValidUser)
  @Put("user/profile")
  async updateProfile(@Body() body: UpdateProfileDto, @Request() request) {
    const user = await this.userService.updateProfile(
      request.user.userId,
      body
    );
    return this.response({ updated: true, user: this.sanitizeUser(user) });
  }

  @ApiBearerAuth()
  @UsePipes(validationRequestPipe)
  @UseGuards(JwtAuthGuard, ValidUser)
  @Put("user/change-password")
  async changePassword(@Body() body: ChangePasswordDto, @Request() request) {
    await this.userService.changePassword(request.user.userId, body);
    return this.response(
      { updated: true },
      200,
      "notification.updated_password_successfully"
    );
  }

  @ApiConsumes("multipart/form-data")
  @ApiBody({
    schema: {
      type: "object",
      properties: {
        file: {
          type: "string",
          format: "binary",
        },
      },
    },
  })
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @Post("user/update-avatar")
  @UseInterceptors(
    fileInterceptors(
      "avatar",
      ["jpeg", "png", "jpg"],
      errors.AVATAR_NOT_ALLOWS_FILE_TYPES
    )
  )
  async uploadAvatar(@Request() request, @UploadedFile() file) {
    if (request.errorType) {
      throw new HttpException(request.errorType, HttpStatus.BAD_REQUEST);
    }
    if (!file) {
      throw new HttpException(
        errors.ASSET_CAN_NOT_OPEN,
        HttpStatus.BAD_REQUEST
      );
    }
    const user = await this.userService.updateUserMedia(
      request.user.userId,
      "avatar",
      {
        avatar: `avatar/${file.filename}`,
      }
    );
    return this.response({
      updated: true,
      link: `${process.env.APP_URL}/asset/avatar/${file.filename}`,
      user: this.sanitizeUser(user),
    });
  }

  @ApiConsumes("multipart/form-data")
  @ApiBody({
    schema: {
      type: "object",
      properties: {
        file: {
          type: "string",
          format: "binary",
        },
      },
    },
  })
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @Post("user/update-cover")
  @UseInterceptors(
    fileInterceptors(
      "cover",
      ["jpeg", "png", "jpg"],
      errors.AVATAR_NOT_ALLOWS_FILE_TYPES
    )
  )
  async uploadCover(@Request() request, @UploadedFile() file) {
    if (request.errorType) {
      throw new HttpException(request.errorType, HttpStatus.BAD_REQUEST);
    }
    if (!file) {
      throw new HttpException(
        errors.ASSET_CAN_NOT_OPEN,
        HttpStatus.BAD_REQUEST
      );
    }
    const user = await this.userService.updateUserMedia(
      request.user.userId,
      "cover",
      {
        cover: `cover/${file.filename}`,
      }
    );
    return this.response({
      updated: true,
      link: `${process.env.APP_URL}/asset/cover/${file.filename}`,
      user: this.sanitizeUser(user),
    });
  }

  @ApiBearerAuth()
  @UsePipes(validationRequestPipe)
  @UseGuards(JwtAuthGuard, ValidUser)
  @Post("user/become-a-broker")
  async becomeToAgent(@Body() body, @Request() request) {
    const user = await this.userService.updateProfile(request.user.userId, {
      userType: UserType.BROKER,
    });
    return this.response({ updated: true, user: this.sanitizeUser(user) });
  }
}
