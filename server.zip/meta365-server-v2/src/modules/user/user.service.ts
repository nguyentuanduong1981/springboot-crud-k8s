import {
  HttpException,
  HttpStatus,
  Inject,
  Injectable,
  Scope,
} from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model, ObjectId, Types } from "mongoose";
import { User, UserDocument, UserSchema } from "../../schemas/user.schema";
import {
  ChangePasswordDto,
  CreateUserDto,
  CreateUserWithWalletDto,
} from "../../dtos/users.dto";
import { customAlphabet } from "nanoid";
import * as bcrypt from "bcrypt";
import { removeImage } from "../../utilities/helpers";
import errors from "src/commons/errors/errors.validator";
import { MailerService } from "../mailer/mailer.service";
import { getProjectPopulateConfig } from "../project/project.service";
import { REQUEST } from "@nestjs/core";
import { Request } from "express";

export function getUserPopulateConfig(config = {}) {
  return {
    _id: 1,
    avatar: 1,
    cover: 1,
    socials: 1,
    phoneNumber: 1,
    username: 1,
    fullName: 1,
    publicAddress: 1,
    ...config,
  };
}

// @Injectable()
@Injectable()
export class UserService {
  constructor(
    @InjectModel(User.name) private userModel: Model<UserDocument> // private readonly mailerService: MailerService
  ) {}

  getModel() {
    return this.userModel;
  }

  async findUserById(id: string): Promise<User | undefined> {
    return await this.userModel
      .findById(id)
      .populate([
        {
          path: "agent",
          select: {
            logo: 1,
            cover: 1,
            name: 1,
            shortName: 1,
            _id: 1,
          },
        },
        {
          path: "ownerOfAgent",
          select: {
            logo: 1,
            cover: 1,
            name: 1,
            shortName: 1,
            _id: 1,
          },
        },
        {
          path: "favorites",
          select: {
            favoriteType: 1,
            id: 1,
            populate: {
              path: "project",
              select: {
                links: 0,
              },
            },
          },
        },
      ])
      .exec();
  }

  async findUser(object): Promise<User | undefined> {
    return await this.userModel.findOne(object).exec();
  }

  async findUserBySocialId(id: string): Promise<User | undefined> {
    return await this.userModel
      .findOne({
        $or: [
          {
            facebookId: id,
          },
          {
            zaloId: id,
          },
          {
            googleId: id,
          },
        ],
      })
      .exec();
  }

  async findUserByPublicAddress(
    publicAddress: string
  ): Promise<User | undefined> {
    return await this.userModel.findOne({ publicAddress }).exec();
  }

  async create(aUser): Promise<User | undefined> {
    const user = await this.userModel.create(aUser);
    return user;
  }

  async createByWallet(aUser): Promise<User | undefined> {
    return await this.userModel.create(aUser);
  }

  async getUserByInfo(username: string): Promise<User | undefined> {
    return await this.userModel.findOne({
      $or: [
        {
          username: username,
          phoneNumber: username,
        },
      ],
    });
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return await this.userModel.findOne({ email }).exec();
  }

  async createNewUserNonce(publicAddress): Promise<User | undefined> {
    return await new Promise((resolve, reject) => {
      this.userModel.findOneAndUpdate(
        {
          publicAddress: publicAddress,
        },
        {
          nonce: Math.floor(Math.random() * 10000),
        },
        (error, result) => {
          if (error) {
            reject(error);
          } else {
            resolve(result);
          }
        }
      );
    });
  }

  getRandomUser(length: number = 6): string {
    const nanoid = customAlphabet(
      "1234567890qwertyuiopasdfghjklzxcvbnm",
      length * 3
    );
    return `user#${nanoid(length)}`;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return await this.userModel
      .findOne({ username })
      .populate([
        {
          path: "links",
          populate: {
            path: "project",
            select: {
              links: 0,
            },
          },
          options: {
            // limit: 4,
          },
          select: {
            user: 0,
          },
        },
        {
          path: "agent",
          select: {
            logo: 1,
            cover: 1,
            name: 1,
            shortName: 1,
            _id: 1,
          },
        },
        {
          path: "ownerOfAgent",
          select: {
            logo: 1,
            cover: 1,
            name: 1,
            shortName: 1,
            _id: 1,
          },
        },
        {
          path: "favorites",
          select: {
            favoriteType: 1,
            populate: {
              path: "project",
              select: {
                links: 0,
              },
            },
          },
        },
      ])
      .exec();
  }

  async getUserByPhone(phoneNumber: string): Promise<User | undefined> {
    return await this.userModel.findOne({ phoneNumber });
  }

  async updateProfile(userId: string, data) {
    const user = await this.findUserById(userId);
    let error = [];
    Object.keys(data).forEach((value) => {
      if (data[value] === user[value]) {
        error.push({
          field: value,
          message: errors.NEW_DATA_IS_SAME_OLD_DATA,
        });
      }
    });
    if (error.length) {
      throw new HttpException(
        {
          statusCode: HttpStatus.UNPROCESSABLE_ENTITY,
          message: error,
        },
        HttpStatus.UNPROCESSABLE_ENTITY
      );
    }
    if (data.username) {
      if (!user.username.includes("#")) {
        throw new HttpException(
          errors.CHANGE_USERNAME_ONCE,
          HttpStatus.BAD_REQUEST
        );
      }
    }
    return await this.handleUpdateTransaction(userId, data);
  }

  async handleUpdateTransaction(userId: string, data) {
    const session = await this.userModel.db.startSession();
    session.startTransaction();
    try {
      const updatedUser = await this.userModel.findByIdAndUpdate(
        new Types.ObjectId(userId),
        data,
        { new: true }
      );
      await session.commitTransaction();
      return updatedUser;
    } catch (e) {
      await session.abortTransaction();
      throw new HttpException(e.message, HttpStatus.BAD_REQUEST);
    } finally {
      session.endSession();
    }
  }

  async updateUserMedia(userId: string, type, data) {
    if (!["avatar", "cover"].includes(type))
      throw new HttpException(
        errors.USER_MEDIA_NOT_FOUND,
        HttpStatus.BAD_REQUEST
      );
    try {
      const oldUser = await this.findUserById(userId);
      const newUser = await this.userModel.findByIdAndUpdate(
        new Types.ObjectId(userId),
        data,
        { new: true }
      );
      await removeImage(oldUser[type]);
      return newUser;
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }

  async comparePassword(comparePassword: string, password: string) {
    return bcrypt.compare(comparePassword, password);
  }

  async changePassword(userId: string, data: ChangePasswordDto) {
    const user = await this.findUserById(userId);
    if (!user.password) {
      throw new HttpException(
        errors.LOGIN_WITH_SOCIAL_NETWORK_OR_WALLET_CANNOT_CHANGE_PASSWORD,
        HttpStatus.BAD_REQUEST
      );
    }
    const validPassword = await this.comparePassword(
      data.oldPassword,
      user.password
    );
    if (!validPassword) {
      throw new HttpException(
        errors.CURRENT_PASSWORD_DOES_NOT_MATCH_THE_PASSWORD_YOU_PROVIDER,
        HttpStatus.BAD_REQUEST
      );
    }
    if (data.oldPassword === data.newPassword) {
      throw new HttpException(
        errors.NEW_PASSWORD_CANNOT_BE_SAME_AS_YOUR_CURRENT_PASSWORD,
        HttpStatus.BAD_REQUEST
      );
    }
    const password = await bcrypt.hash(data.newPassword, 10);
    return await this.userModel.findByIdAndUpdate(
      userId,
      { password },
      { new: true }
    );
  }
}
