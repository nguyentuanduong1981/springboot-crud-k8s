import { Module } from "@nestjs/common";
import { UserService } from "./user.service";
import { MongooseModule } from "@nestjs/mongoose";
import { User, UserSchema } from "../../schemas/user.schema";
import { UsersController } from "./user.controller";
import UserSeeder from "seeders/user.seeder";
import { MailerModule } from "../mailer/mailer.module";
import { IsUniqueConstraint } from "src/validators/unique.validator";
import { Project, ProjectSchema } from "src/schemas/project.schema";

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: User.name,
        schema: UserSchema,
      },
    ]),
    MailerModule,
  ],
  controllers: [UsersController],
  providers: [UserSeeder, UserService, IsUniqueConstraint],
  exports: [UserService],
})
export class UserModule {}
