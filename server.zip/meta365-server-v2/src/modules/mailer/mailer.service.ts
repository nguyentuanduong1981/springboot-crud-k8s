import { Injectable } from "@nestjs/common";
import { MailerService as Mailer } from "@nestjs-modules/mailer";
import { welcome } from "../../../templates/mails/config/welcome";
import { resetPassword } from "../../../templates/mails/config/reset-password";

@Injectable()
export class MailerService {
  constructor(private readonly mailerService: Mailer) {}
  public welcome(to, subject, context): Promise<any> {
    return this.mailerService
      .sendMail({
        to,
        from: "duoinhungconmuak@gmail.com",
        subject,
        template: "reset-password", // The `.pug` or `.hbs` extension is appended automatically.
        context: {
          ...resetPassword,
          ...context,
        },
      })
      .then((success) => {
        console.log(success);
      })
      .catch((err) => {
        console.log(err);
      });
  }
}
