import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { UserService } from "../user/user.service";
import {
  CreateUserDto,
  CreateUserWithWalletDto,
  ForgotPasswordDto,
  LoginWithWalletDto,
} from "../../dtos/users.dto";
import * as bcrypt from "bcrypt";
import { JwtService } from "@nestjs/jwt";
import errors from "src/commons/errors/errors.validator";
import { bufferToHex } from "ethereumjs-util";
import { recoverPersonalSignature } from "eth-sig-util";
import { ConfigService } from "@nestjs/config";
import { omit } from "lodash";
import { Types } from "mongoose";
import { SocialProviderFactory } from "src/socials-provider/factory.provider";
import { Gender } from "src/utilities/constants";

@Injectable()
export class AuthenticationService {
  constructor(
    private readonly userService: UserService,
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService
  ) {}

  sanitizeUser(user, ignoreFields = []) {
    const sanitized = user.toObject();
    return omit(sanitized, ["password", ...ignoreFields]);
  }

  async getPublicAddressAvailability(publicAddress: string) {
    const user = await this.userService.findUserByPublicAddress(publicAddress);
    if (!user) return user;
    return this.sanitizeUser(user);
  }

  public async register(registrationData) {
    const user = await this.userService.getUserByPhone(
      registrationData.phoneNumber
    );
    if (user) {
      throw new HttpException(
        errors.PHONE_NUMBER_HAVE_BEEN_TAKEN,
        HttpStatus.BAD_REQUEST
      );
    }
    const hashedPassword = await bcrypt.hash(registrationData.password, 10);
    try {
      const createdUser = await this.userService.create({
        ...registrationData,
        username: this.userService.getRandomUser(6),
        password: hashedPassword,
      });
      return this.sanitizeUser(createdUser);
    } catch (error) {
      console.log(error);
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }

  public async registerWithWallet(registrationData: CreateUserWithWalletDto) {
    try {
      const user = await this.userService.findUserByPublicAddress(
        registrationData.publicAddress
      );
      if (user) {
        throw new HttpException(
          errors.PUBLIC_ADDRESS_HAVE_BEEN_TAKEN,
          HttpStatus.BAD_REQUEST
        );
      }
      const createdUser = await this.userService.createByWallet({
        ...registrationData,
        username: this.userService.getRandomUser(6),
      });
      return this.sanitizeUser(createdUser);
    } catch (error) {
      console.log(error);
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }

  public async newPassword(forgotPasswordData: ForgotPasswordDto) {
    // try {
    //   return await this.userService.newPassword(forgotPasswordData);
    // } catch (error) {
    //   throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    // }
  }

  async login(user: any) {
    const payload = {
      phoneNumber: user.phoneNumber,
      sub: user._id,
      phone: user.phone,
      role: user.role,
      username: user.username,
    };
    return {
      access_token: this.jwtService.sign(payload),
    };
  }

  async loginWithWallet(user: any) {
    const payload = {
      publicAddress: user.publicAddress,
      nonce: user.nonce,
      sub: user._id,
      role: user.role,
    };
    return {
      access_token: this.jwtService.sign(payload),
    };
  }

  // public getCookieWithJwtAccessToken(userId: number, isSecondFactorAuthenticated = false) {
  //   const payload: TokenPayload = { userId, isSecondFactorAuthenticated };
  //   const token = this.jwtService.sign(payload, {
  //     secret: this.configService.get('JWT_ACCESS_TOKEN_SECRET'),
  //     expiresIn: `${this.configService.get('JWT_ACCESS_TOKEN_EXPIRATION_TIME')}s`
  //   });
  //   return `Authentication=${token}; HttpOnly; Path=/; Max-Age=${this.configService.get('JWT_ACCESS_TOKEN_EXPIRATION_TIME')}`;
  // }

  // public getCookieWithJwtRefreshToken(userId: number) {
  //   const payload: TokenPayload = { userId };
  //   const token = this.jwtService.sign(payload, {
  //     secret: this.configService.get('JWT_REFRESH_TOKEN_SECRET'),
  //     expiresIn: `${this.configService.get('JWT_REFRESH_TOKEN_EXPIRATION_TIME')}s`
  //   });
  //   const cookie = `Refresh=${token}; HttpOnly; Path=/; Max-Age=${this.configService.get('JWT_REFRESH_TOKEN_EXPIRATION_TIME')}`;
  //   return {
  //     cookie,
  //     token
  //   }
  // }

  public getCookiesForLogOut() {
    return [
      "Authentication=; HttpOnly; Path=/; Max-Age=0",
      "Refresh=; HttpOnly; Path=/; Max-Age=0",
    ];
  }

  public async getAuthenticatedUser(
    phoneNumber: string,
    plainTextPassword: string
  ) {
    const user = await this.userService.getUserByPhone(phoneNumber);
    if (!user) {
      throw new HttpException(
        errors.ACCOUNT_DOES_NOT_EXIST,
        HttpStatus.UNAUTHORIZED
      );
    }
    if (!user.password) {
      throw new HttpException(
        errors.ACCOUNT_CAN_NOT_LOGIN,
        HttpStatus.BAD_REQUEST
      );
    }
    await this.verifyPassword(plainTextPassword, user.password);
    if (!user.isActive) {
      throw new HttpException(errors.ACCOUNT_INACTIVE, HttpStatus.BAD_REQUEST);
    }
    if (user.isBlocked) {
      throw new HttpException(errors.ACCOUNT_BLOCKED, HttpStatus.BAD_REQUEST);
    }
    return this.sanitizeUser(user);
  }

  private async verifyPassword(
    plainTextPassword: string,
    hashedPassword: string
  ) {
    const isPasswordMatching = await bcrypt.compare(
      plainTextPassword,
      hashedPassword
    );
    if (!isPasswordMatching) {
      throw new HttpException(
        errors.CREDENTIALS_IS_WRONG,
        HttpStatus.BAD_REQUEST
      );
    }
  }

  public async getAuthenticatedUserByPublicAddress(
    credentials: LoginWithWalletDto
  ) {
    const { publicAddress, signature } = credentials;
    const user = await this.userService.findUserByPublicAddress(publicAddress);
    const msg = `I am signing my one-time nonce: ${user.nonce}`;

    // We now are in possession of msg, publicAddress and signature. We
    // will use a helper from eth-sig-util to extract the address from the signature
    const msgBufferHex = bufferToHex(Buffer.from(msg, "utf8"));
    const address = recoverPersonalSignature({
      data: msgBufferHex,
      sig: signature,
    });

    // The signature verification is successful if the address found with
    // sigUtil.recoverPersonalSignature matches the initial publicAddress
    if (address.toLowerCase() !== publicAddress.toLowerCase()) {
      throw new HttpException(
        errors.SIGNATURE_VERIFICATION_FAILED,
        HttpStatus.UNAUTHORIZED
      );
    }

    if (!user.isActive) {
      throw new HttpException(errors.ACCOUNT_INACTIVE, HttpStatus.BAD_REQUEST);
    }
    if (user.isBlocked) {
      throw new HttpException(errors.ACCOUNT_BLOCKED, HttpStatus.BAD_REQUEST);
    }
    await this.userService.createNewUserNonce(publicAddress);
    return this.sanitizeUser(user);
  }

  // public async getUserFromAuthenticationToken(token: string) {
  //   const payload: TokenPayload = this.jwtService.verify(token, {
  //     secret: this.configService.get('JWT_ACCESS_TOKEN_SECRET')
  //   });
  //   if (payload.userId) {
  //     return this.userService.getById(payload.userId);
  //   }
  // }

  async socialAuthentication(provider, request) {
    const config = {
      zalo: {
        client_id: this.configService.get("ZALO_CLIENT_ID"),
        client_secret: this.configService.get("ZALO_CLIENT_SECRET"),
        redirect: this.configService.get("ZALO_REDIRECT_URI"),
      },
      facebook: {
        client_id: this.configService.get("FACEBOOK_CLIENT_ID"),
        client_secret: this.configService.get("FACEBOOK_CLIENT_SECRET"),
        redirect: this.configService.get("FACEBOOK_REDIRECT_URI"),
      },
      google: {
        client_id: this.configService.get("GOOGLE_CLIENT_ID"),
        client_secret: this.configService.get("GOOGLE_CLIENT_SECRET"),
        redirect: this.configService.get("GOOGLE_REDIRECT_URI"),
      },
    };
    const factory = new SocialProviderFactory(request, config);
    return new Promise((resolve, rejects) =>
      factory
        .getProvider(provider)
        .getUser()
        .then(async (res) => {
          let promises = [];
          promises.push(this.userService.findUserBySocialId(res.id));
          promises.push(this.userService.getUserByEmail(res.email));
          Promise.all(promises).then(async (users) => {
            let user = users[0];
            console.log(users[0], users[1]);
            if (!users[0]) {
              if (users[1] && users[1]._id) {
                return rejects(errors.EMAIL_HAVE_BEEN_TAKEN);
              } else {
                const data = {
                  username: this.userService.getRandomUser(6),
                  email: res.email,
                  gender: res.gender || Gender.PREFER_NOT_TO_SAY,
                  fullName: res.name,
                  avatar: res.avatar,
                  verifiedEmailAt: res.verifiedEmailAt || null,
                };
                data[`${provider}Id`] = res.id;
                user = await this.userService.create(data);
              }
            }
            const login = await this.login(user);
            resolve(login);
          });
        })
        .catch((error) => {
          console.log(error);
          rejects(error.response.data || error);
        })
    );
  }
}
