import {
  Controller,
  Get,
  Post,
  Body,
  HttpCode,
  UseGuards,
  Req,
  Query,
  Param,
  HttpException,
  HttpStatus,
  UsePipes,
  Ip,
} from "@nestjs/common";
import { AuthenticationService } from "./authentication.service";
import {
  CreateUserDto,
  CreateUserWithWalletDto,
  ForgotPasswordDto,
  LoginDto,
  LoginWithWalletDto,
} from "../../dtos/users.dto";
import { LocalAuthenticationGuard } from "../../commons/authentication/authentication.guard";
import RequestWithUser from "../../interfaces/requestWithUser.interface";
import BaseController from "src/commons/baseController.controller";
import {
  ApiBadRequestResponse,
  ApiOkResponse,
  ApiOperation,
  ApiParam,
  ApiUnprocessableEntityResponse,
  ApiResponse,
  ApiTags,
} from "@nestjs/swagger";
import errors from "../../../src/commons/errors/errors.validator";
import validationRequestPipe from "src/commons/pipes/request.pipe";

@Controller("authentication")
@ApiTags("user-authentication")
export default class extends BaseController {
  constructor(private readonly authenticationService: AuthenticationService) {
    super();
  }

  @Post("/register")
  @HttpCode(200)
  @ApiOperation({
    summary: "Tạo tài khoản",
    description: "Tạo tạo tài khoản thường",
  })
  @ApiOkResponse({
    status: 200,
    description: "Tạo tài khoản thành công",
    schema: {
      type: "object",
      example: {
        access_token:
          "$2a$10$uvXprA8vRlz3DsIjtUCBFesYv2wqJflV0kTWdxKXUhUCJl3m2SY42",
      },
    },
  })
  @ApiUnprocessableEntityResponse({
    status: 422,
    description: "Thông tin nhập vào không hợp lệ",
    schema: {
      type: "object",
      example: {
        statusCode: 422,
        message: [],
      },
    },
  })
  @ApiBadRequestResponse({
    status: 400,
    description: errors.PHONE_NUMBER_HAVE_BEEN_TAKEN,
    schema: {
      type: "object",
      example: {
        statusCode: 400,
        message: "notification.error.register_by_phone_number_already_exist",
      },
    },
  })
  @UsePipes(validationRequestPipe)
  async create(@Body() createUserDto: CreateUserDto, @Ip() _ip) {
    return this.response(
      await this.authenticationService.register(createUserDto)
    );
  }

  @HttpCode(200)
  @ApiOperation({
    summary: "Tạo tài khoản",
    description: "Tạo tạo tài khoản bằng ví metamask",
  })
  @ApiOkResponse({
    status: 200,
    description: "Tạo tài khoản thành công",
    schema: {
      type: "object",
      example: {
        access_token:
          "$2a$10$uvXprA8vRlz3DsIjtUCBFesYv2wqJflV0kTWdxKXUhUCJl3m2SY42",
      },
    },
  })
  @ApiUnprocessableEntityResponse({
    status: 422,
    description: "Thông tin nhập vào không hợp lệ",
    schema: {
      type: "object",
      example: {
        statusCode: 422,
        message: [],
      },
    },
  })
  @ApiBadRequestResponse({
    status: 400,
    description: errors.PUBLIC_ADDRESS_HAVE_BEEN_TAKEN,
    schema: {
      type: "object",
      example: {
        statusCode: 400,
        message:
          "notification.error.account.register_by_public_address_already_exist",
      },
    },
  })
  @UsePipes(validationRequestPipe)
  @Post("/register-with-wallet")
  async createWithWallet(@Body() createUserDto: CreateUserWithWalletDto) {
    return this.response(
      await this.authenticationService.registerWithWallet(createUserDto)
    );
  }

  @Get("public-address-availability")
  async publicAddressAvailability(@Query() query) {
    const response =
      await this.authenticationService.getPublicAddressAvailability(
        query.publicAddress
      );
    return this.response(response);
  }

  @HttpCode(200)
  @UseGuards(LocalAuthenticationGuard)
  @Post("login")
  @HttpCode(200)
  @ApiOperation({
    summary: "Đăng nhập tài khoản",
    description: "Đăng nhập tài khoản thường",
  })
  @ApiOkResponse({
    status: 200,
    description: "Đăng nhập tài khoản thành công",
    schema: {
      type: "object",
      example: {
        access_token:
          "$2a$10$uvXprA8vRlz3DsIjtUCBFesYv2wqJflV0kTWdxKXUhUCJl3m2SY42",
      },
    },
  })
  @ApiUnprocessableEntityResponse({
    status: 422,
    description: "Thông tin nhập vào không hợp lệ",
    schema: {
      type: "object",
      example: {
        statusCode: 422,
        message: [],
      },
    },
  })
  @ApiBadRequestResponse({
    status: 400,
    description: errors.ACCOUNT_DOES_NOT_EXIST,
    schema: {
      type: "object",
      example: {
        statusCode: 400,
        message: "notification.error.account.account_DOES_NOT_EXIST",
      },
    },
  })
  @UsePipes(validationRequestPipe)
  async logIn(
    @Body() _login: LoginDto,
    @Req() request: RequestWithUser,
    @Ip() _ip
  ) {
    console.log(_ip);
    const response = await this.authenticationService.login(request.user);
    return this.response(response);
  }

  @HttpCode(200)
  @Post("login-with-wallet")
  @UsePipes(validationRequestPipe)
  async logInWithWallet(@Body() _login: LoginWithWalletDto) {
    const user =
      await this.authenticationService.getAuthenticatedUserByPublicAddress(
        _login
      );
    const response = await this.authenticationService.loginWithWallet(user);
    return this.response(response);
  }

  @ApiParam({
    name: "provider",
    required: true,
    example: "google",
  })
  @Post("social/:provider")
  async socialLogin(@Body() _login, @Param() param) {
    try {
      const response = await this.authenticationService.socialAuthentication(
        param.provider,
        _login
      );
      return this.response(response);
    } catch (error) {
      throw new HttpException(error, HttpStatus.BAD_REQUEST);
    }
  }

  // @Post('/new-password')
  // async forGotPassword(@Body() forgotPasswordData: ForgotPasswordDto) {
  //   return this.response(await this.authenticationService.newPassword(forgotPasswordData));
  // }
}
