import { Strategy } from "passport-local";
import { PassportStrategy } from "@nestjs/passport";
import { Injectable } from "@nestjs/common";
import { AuthenticationService } from "./authentication.service";
import { User } from "../../schemas/user.schema";

@Injectable()
export class LocalStrategy extends PassportStrategy(Strategy) {
  constructor(private authenticationService: AuthenticationService) {
    super({
      usernameField: "phoneNumber",
      passwordField: "password",
    });
  }
  async validate(phoneNumber: string, password: string): Promise<User> {
    return this.authenticationService.getAuthenticatedUser(
      phoneNumber,
      password
    );
  }
}
