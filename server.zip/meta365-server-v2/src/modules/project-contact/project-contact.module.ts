import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import {
  ProjectContact,
  ProjectContactSchema,
} from "src/schemas/project-contact.schema";
import ProjectContactController from "./project-contact.controller";
import { ProjectContactService } from "./project-contact.service";

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: ProjectContact.name, schema: ProjectContactSchema },
    ]),
  ],
  controllers: [ProjectContactController],
  providers: [ProjectContactService],
  exports: [ProjectContactService],
})
export class ProjectContactModule {}
