import { Controller, Post, UsePipes, Request, Body } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import BaseController from "src/commons/baseController.controller";
import validationRequestPipe from "src/commons/pipes/request.pipe";
import { ProjectContactDto } from "src/dtos/project.dto";
import { ProjectContactService } from "./project-contact.service";

@Controller("project-contact")
@ApiTags("project-contact")
export default class extends BaseController {
  constructor(private projectContactService: ProjectContactService) {
    super();
  }

  @UsePipes(validationRequestPipe)
  @Post("")
  async create(@Body() body: ProjectContactDto) {
    return this.response(await this.projectContactService.create(body));
  }
}
