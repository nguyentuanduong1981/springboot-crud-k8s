import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import {
  ProjectContact,
  ProjectContactDocument,
} from "src/schemas/project-contact.schema";

@Injectable()
export class ProjectContactService {
  constructor(
    @InjectModel(ProjectContact.name)
    private projectContactModel: Model<ProjectContactDocument>
  ) {}

  getModel() {
    return this.projectContactModel;
  }

  async create(contactForm) {
    return await this.projectContactModel.create(contactForm);
  }
}
