import { Test, TestingModule } from "@nestjs/testing";
import { ProjectContactService } from "./project-contact.service";

describe("ProjectContactService", () => {
  let service: ProjectContactService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ProjectContactService],
    }).compile();

    service = module.get<ProjectContactService>(ProjectContactService);
  });

  it("should be defined", () => {
    expect(service).toBeDefined();
  });
});
