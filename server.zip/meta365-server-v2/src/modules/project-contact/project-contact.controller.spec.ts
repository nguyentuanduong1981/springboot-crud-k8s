import { Test, TestingModule } from "@nestjs/testing";
import { ProjectContactController } from "./project-contact.controller";

describe("ProjectContactController", () => {
  let controller: ProjectContactController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ProjectContactController],
    }).compile();

    controller = module.get<ProjectContactController>(ProjectContactController);
  });

  it("should be defined", () => {
    expect(controller).toBeDefined();
  });
});
