import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { isValidObjectId, Model, Types } from "mongoose";
import { Link, LinkDocument } from "src/schemas/link.schema";
import {
  getProjectPopulateConfig,
  ProjectService,
} from "../project/project.service";
import { ConfigService } from "@nestjs/config";
import { getUserPopulateConfig, UserService } from "../user/user.service";
import errors from "src/commons/errors/errors.validator";
import { createQR } from "src/utilities/helpers";
import { Pagination } from "src/commons/paginate";
import {
  ProjectPhases,
  ProjectStatus,
  UserType,
} from "src/utilities/constants";

@Injectable()
export class LinkService {
  constructor(
    @InjectModel(Link.name) private linkModel: Model<LinkDocument>,
    private userService: UserService,
    private projectService: ProjectService,
    private configService: ConfigService
  ) {}

  getModel() {
    return this.linkModel;
  }

  async getLinkById(id: string): Promise<Link> {
    return await this.linkModel
      .findOne({
        $or: [
          { _id: id },
          {
            project: {
              _id: id,
            },
          },
        ],
      })
      .populate([
        {
          path: "user",
          select: getUserPopulateConfig({
            socials: 1,
          }),
        },
        {
          path: "project",
          select: {
            links: 0,
          },
        },
      ])
      .exec()
      .catch((err) => {
        throw new HttpException(err.message, HttpStatus.BAD_REQUEST);
      });
  }

  parseFilter(query) {
    const { project, user } = query;
    let filter: any = {};

    if (user && isValidObjectId(user)) {
      filter["user"] = user;
    }
    if (project && isValidObjectId(project)) {
      filter["project"] = project;
    }
    return filter;
  }

  async getAllLink(query) {
    const limit = query.limit || 12;
    const offset = ((query.page > 0 ? query.page : 1) - 1) * limit;
    let total = 0;
    const filter = this.parseFilter(query);

    const links = await this.linkModel
      .find(filter)
      .sort({
        createdAt: -1,
        _id: -1,
      })
      .limit(limit)
      .skip(offset)
      .populate([
        {
          path: "user",
          select: getUserPopulateConfig({
            socials: 1,
          }),
          match: {
            fullName: { $regex: `${query.name || ""}`, $options: "i" },
          },
        },
        {
          path: "project",
          select: {
            links: 0,
          },
        },
      ])
      .skip(offset)
      .limit(limit)
      .exec()
      .then(async (links) => {
        total = await this.linkModel.countDocuments();
        return {
          results: links,
          total,
        };
      })
      .catch((err) => {
        throw new HttpException(err.message, HttpStatus.BAD_REQUEST);
      });
    return new Pagination<LinkDocument>(links);
  }

  async checkLinkExisted(project, user) {
    if (
      !project ||
      !user ||
      !isValidObjectId(project) ||
      !isValidObjectId(user)
    )
      return null;
    return await this.linkModel
      .findOne({
        user,
        project,
      })
      .populate([
        {
          path: "user",
          select: getUserPopulateConfig({
            socials: 1,
          }),
        },
        {
          path: "project",
          select: {
            links: 0,
          },
        },
      ])
      .exec();
  }

  validateProject(project) {
    if (!project) {
      throw new HttpException(
        errors.PROJECT_DOES_NOT_EXIST,
        HttpStatus.NOT_FOUND
      );
    }
    if (
      project.status === ProjectStatus.LOCK ||
      [ProjectPhases.NOT_SOLD_YET, ProjectPhases.SOLD_OUT].includes(
        project.phase
      )
    ) {
      throw new HttpException(
        errors.PROJECT_CAN_NOT_BE_REGISTERED_FOR_SALE,
        HttpStatus.BAD_REQUEST
      );
    }
  }

  async createLink(
    project,
    user,
    fetch: Boolean = true
  ): Promise<LinkDocument> {
    if (fetch) {
      user = await this.userService.findUserById(user.userId);
      project = await this.projectService.getProjectById(project);
    }

    if (user.userType === UserType.NORMAL && !user.owner) {
      throw new HttpException(
        errors.YOU_MUST_BE_A_BROKER,
        HttpStatus.BAD_REQUEST
      );
    }
    this.validateProject(project);
    const isExisted = await this.checkLinkExisted(project._id, user._id);

    if (!!isExisted) {
      return isExisted;
      // throw new HttpException(errors.LINK_HAVE_BEEN_TAKEN, HttpStatus.BAD_REQUEST);
    }
    return await this.handleCreateLink(project, user);
  }

  async handleCreateLink(project, user) {
    const _id = new Types.ObjectId();
    const path = `images/qr/${_id}.png`;
    await createQR(
      `${this.configService.get<string>("APP_URL")}/link/${_id}`,
      path
    );

    const session = await this.linkModel.db.startSession();
    session.startTransaction();

    try {
      const linkCreate = await this.linkModel.create({
        _id,
        qr: path,
        user,
        project,
      });

      project.links.push(linkCreate);
      user.links.push(linkCreate);

      await Promise.all([project.save(), user.save()]);
      await session.commitTransaction();

      return linkCreate.populate([
        {
          path: "user",
          select: getUserPopulateConfig({
            socials: 1,
          }),
        },
        {
          path: "project",
          select: {
            links: 0,
          },
        },
      ]);
    } catch (e) {
      await session.abortTransaction();
      throw new HttpException(e.message, HttpStatus.BAD_REQUEST);
    } finally {
      session.endSession();
    }
  }

  async deleteLink(link, userId): Promise<any> {
    const session = await this.linkModel.db.startSession();
    const isExisted = await this.getLinkById(link);
    if (!isExisted || isExisted.user._id.toString() !== userId) {
      throw new HttpException(
        errors.LINK_DOES_NOT_EXIST,
        HttpStatus.BAD_REQUEST
      );
    }
    session.startTransaction();
    try {
      await this.linkModel.findByIdAndDelete(link);
      await session.commitTransaction();
      return;
    } catch (e) {
      await session.abortTransaction();
      throw new HttpException(e.message, HttpStatus.BAD_REQUEST);
    } finally {
      session.endSession();
    }
  }
}
