import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { Link, LinkSchema } from "src/schemas/link.schema";
import { ProjectModule } from "../project/project.module";
import { UserModule } from "../user/user.module";
import LinkController from "./link.controller";
import { LinkService } from "./link.service";

@Module({
  imports: [
    MongooseModule.forFeature([{ name: Link.name, schema: LinkSchema }]),
    UserModule,
    ProjectModule,
  ],
  controllers: [LinkController],
  providers: [LinkService],
  exports: [LinkService],
})
export class LinkModule {}
