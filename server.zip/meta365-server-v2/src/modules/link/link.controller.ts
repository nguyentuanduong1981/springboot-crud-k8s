import {
  Body,
  Controller,
  Post,
  UseGuards,
  Request,
  Get,
  Param,
  Query,
  Delete,
} from "@nestjs/common";
import { ApiBearerAuth, ApiParam, ApiQuery, ApiTags } from "@nestjs/swagger";
import { JwtAuthGuard } from "src/commons/authentication/jwt-auth.guard";
import BaseController from "src/commons/baseController.controller";
import errors from "src/commons/errors/errors.validator";
import { ObjectIdPipe } from "src/commons/pipes/validate-objectid.pipe";
import { CreateLinkDto } from "src/dtos/link.dto";
import { ValidUser } from "src/guards/valid-user.guard";
import { ResponsePaginationCommon } from "src/interfaces/responseHttp.interface";
import { LinkService } from "./link.service";

@Controller("link")
@ApiTags("link")
export default class extends BaseController {
  constructor(private linkService: LinkService) {
    super();
  }

  @ApiQuery({
    name: "user",
    example: "62981cbc7d83b6f9ba222a11",
    required: false,
  })
  @ApiQuery({
    name: "project",
    example: "62a40a2d4ace7b45e21a9f5c",
    required: false,
  })
  @Get("")
  async getAllProject(@Query() query): Promise<ResponsePaginationCommon> {
    return this.responsePagination(await this.linkService.getAllLink(query));
  }

  @ApiQuery({
    name: "project",
    example: "62a40a2d4ace7b45e21a9f5c",
    required: false,
  })
  @ApiQuery({
    name: "name",
    example: "e",
    required: false,
  })
  @Get("/user")
  async getAllUserByProjectId(
    @Query() query
  ): Promise<ResponsePaginationCommon> {
    return this.responsePagination(await this.linkService.getAllLink(query));
  }

  @ApiParam({
    name: "id",
    required: true,
    example: "62beccc3138a81a79d322f4d",
  })
  @Get("/my-link/:id")
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, ValidUser)
  async getMyLink(
    @Param("id", new ObjectIdPipe(errors.LINK_DOES_NOT_EXIST)) id,
    @Request() request
  ) {
    return this.response(
      await this.linkService.checkLinkExisted(id, request.user.userId)
    );
  }

  @ApiParam({
    name: "id",
    required: true,
    example: "62beccc3138a81a79d322f4d",
  })
  @Get("/:id")
  async getLinkById(
    @Param("id", new ObjectIdPipe(errors.LINK_DOES_NOT_EXIST)) id,
    @Query() query
  ) {
    return this.response(await this.linkService.getLinkById(id));
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, ValidUser)
  @Post("/")
  async createLink(@Body() data: CreateLinkDto, @Request() request) {
    return this.response(
      await this.linkService.createLink(data.project_id, request.user)
    );
  }

  @ApiParam({
    name: "id",
    required: true,
    example: "62beccc3138a81a79d322f4d",
  })
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, ValidUser)
  @Delete("/:id")
  async deleteLink(
    @Param("id", new ObjectIdPipe(errors.LINK_DOES_NOT_EXIST)) id,
    @Request() request
  ) {
    return this.response(
      await this.linkService.deleteLink(id, request.user.userId)
    );
  }
}
