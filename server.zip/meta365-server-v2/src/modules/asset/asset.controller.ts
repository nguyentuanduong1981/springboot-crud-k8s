import {
  Controller,
  Get,
  HttpStatus,
  Injectable,
  Param,
  Response,
  HttpException,
  Query,
  StreamableFile,
} from "@nestjs/common";
import { ApiParam, ApiProperty, ApiTags } from "@nestjs/swagger";
import { join } from "path";
import BaseController from "src/commons/baseController.controller";
import * as fs from "fs";
import errors from "src/commons/errors/errors.validator";
import { mediaTypeToFolder } from "src/utilities/helpers";

@Controller({
  path: "asset",
})
@ApiTags("asset")
@Injectable()
export default class extends BaseController {
  constructor() {
    super();
  }

  fileExtensionsToContentType(path) {
    const contentType = {
      png: "image/*",
      jpg: "image/*",
      jpeg: "image/*",
      mp4: "video/mp4",
      mp3: "audio/mp3",
    };
    const fileExtensions = path.split(".").pop() || "pdf";
    return contentType[fileExtensions];
  }

  // @UseGuards(JwtAuthGuard)
  // @ApiBearerAuth()
  // @Post('upload/document')
  // @UseInterceptors(
  //   FileInterceptor(
  //     'file',
  //     {
  //       storage: diskStorage({
  //         destination: "./static/documents",
  //         filename: (_req, file, callback) => {
  //           callback(null, generateFilename(file))
  //         }
  //       }),
  //       fileFilter: (req, file, callback) => {
  //         if (!file.originalname.match(/\.(jpg|jpeg|png|mp3|mp4|md|txt|pdf|pptx|ppt|xlsx|doc|docx|xls)$/)) {
  //           req.errorType = 'Không thể tải lên định dạng tệp này'
  //           return callback(null, false)
  //         }
  //         callback(null, true)
  //       }
  //     }
  //   )
  // )
  // async upload(@Request() req, @UploadedFile() file) {
  //   if (req.errorType) {
  //     throw new HttpException(req.errorType, HttpStatus.BAD_REQUEST);
  //   }
  //   if (!file) {
  //     throw new HttpException('Không thể mở tài liệu', HttpStatus.BAD_REQUEST);
  //   }
  //   return this.response({
  //     link: file.filename
  //   })
  // }

  // @UseGuards(JwtAuthGuard)
  // @ApiBearerAuth()
  // @Delete('/document/:link')
  // async deleteDocument (@Param('link') link) {
  //   return await fs.unlink(`static/documents/${link}`, (err) => {
  //     if (err) {
  //      console.error(err);
  //      throw new HttpException('Không thể xóa tệp', HttpStatus.BAD_REQUEST);
  //     }
  //   })
  // }
  // @ApiConsumes('multipart/form-data')
  // @ApiBody({
  //   schema: {
  //     type: 'object',
  //     properties: {
  //       file: {
  //         type: 'string',
  //         format: 'binary',
  //       },
  //     },
  //   },
  // })
  // @UseGuards(JwtAuthGuard)
  // @ApiBearerAuth()
  // @Post('upload/image')
  // @UseInterceptors(
  //   FileInterceptor(
  //     'file',
  //     {
  //       storage: diskStorage({
  //         destination: "./static/images/avatar",
  //         filename: (_req, file, callback) => {
  //           callback(null, generateFilename(file))
  //         }
  //       }),
  //       fileFilter: (req, file, callback) => {
  //         if (!file.originalname.match(/\.(jpg|jpeg|png|)$/)) {
  //           req.errorType = 'Không thể tải lên định dạng tệp này'
  //           return callback(null, false)
  //         }
  //         callback(null, true)
  //       }
  //     }
  //   )
  // )
  // async uploadImage(@Request() req, @UploadedFile() file) {
  //   if (req.errorType) {
  //     throw new HttpException(req.errorType, HttpStatus.BAD_REQUEST);
  //   }
  //   if (!file) {
  //     throw new HttpException('Không thể mở tài liệu', HttpStatus.BAD_REQUEST);
  //   }
  //   return this.response({
  //     link: `${process.env.APP_URL}/api/v1/avatar/${file.filename}`
  //   })
  // }

  @Get("/:type/:id")
  @ApiParam({
    name: "id",
    required: true,
    description: "id of id",
  })
  @ApiParam({
    name: "type",
    required: true,
    description: "type id",
  })
  getAsset(@Param() params, @Query() query, @Response() res): any {
    let type = params.type;
    let folder = mediaTypeToFolder(type);

    if (!folder) {
      throw new HttpException(
        errors.ASSET_DOES_NOT_EXIST,
        HttpStatus.NOT_FOUND
      );
    }

    const path = join(process.cwd(), `static/${folder}/${type}/${params.id}`);
    if (!fs.existsSync(path) || !fs.lstatSync(path).isFile()) {
      throw new HttpException(
        errors.ASSET_DOES_NOT_EXIST,
        HttpStatus.NOT_FOUND
      );
    }
    try {
      if (["avatar", "qr", "image", "cover", "project"].includes(type)) {
        res.sendFile(path);
        return;
      }
      var stat = fs.statSync(path);
      res.set({
        "Content-Length": `${stat.size}`,
        "Content-Type": `${this.fileExtensionsToContentType(path)}`,
        "Content-Disposition": `attachment; filename="${params.id}"`,
        // 'Cache-Control': 'no-cache, no-store, must-revalidate',
        // 'Pragma': 'no-cache',
        // 'Expires': 0,
      });
      const file = fs.readFileSync(path);
      res.end(file);
    } catch (error) {
      console.log(error);
      throw new HttpException(
        errors.ASSET_CAN_NOT_OPEN,
        HttpStatus.BAD_REQUEST
      );
    }
  }

  // @Get('/documents')
  // getImages():Observable<string[]> {
  //   const results:Array<string> = new Array<string>();

  //   const files = fs.readdirSync(join(process.cwd(), 'static/spaceships/images'))
  //   for(let i = 0; i < files.length; i++) {
  //     results.push(`${process.env.APP_URL}/asset/image/${files[i].replace(/\.[^.]*$/, '')}`)
  //   }
  //   return of(results)
  // }
}
