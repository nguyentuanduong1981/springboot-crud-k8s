import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Request,
  UseGuards,
} from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { JwtAuthGuard } from "src/commons/authentication/jwt-auth.guard";
import BaseController from "src/commons/baseController.controller";
import { ArticleService } from "./article.service";

@Controller("article")
@ApiTags("article")
export class ArticleController extends BaseController {
  constructor(private articleService: ArticleService) {
    super();
  }

  @Get("")
  async getAllArticle() {
    return this.response(await this.articleService.getAllArticle());
  }

  @Get("/:id")
  async getArticleById(@Param() param) {
    return this.response(await this.articleService.getArticleById(param.id));
  }

  @UseGuards(JwtAuthGuard)
  @Post("/create")
  async createArticle(@Request() req) {
    return this.response(
      await this.articleService.createArticle(req.body, req.user.userId)
    );
  }

  @UseGuards(JwtAuthGuard)
  @Put("/update/:id")
  async updateArticle(@Param() param, @Body() contentUpdate: any) {
    return this.response(
      await this.articleService.updateArticle(param.id, contentUpdate)
    );
  }

  @UseGuards(JwtAuthGuard)
  @Delete("/delete/:id")
  async deleteArticle(@Param() param) {
    return this.response(await this.articleService.deleteArticle(param.id));
  }
}
