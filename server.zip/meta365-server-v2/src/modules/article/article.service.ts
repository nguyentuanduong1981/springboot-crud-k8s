import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Article, ArticleDocument } from "src/schemas/article.schema";
import { Model } from "mongoose";
import errors from "src/commons/errors/errors.validator";

@Injectable()
export class ArticleService {
  constructor(
    @InjectModel(Article.name) private articleModel: Model<ArticleDocument>
  ) {}

  // async findArticleByTitle(title: string): Promise<Article> {
  //   return this.articleModel.find()
  // }

  async getAllArticle(): Promise<Article[]> {
    return this.articleModel
      .find({})
      .populate({ path: "author", select: ["phoneNumber", "username"] })
      .catch((err) => {
        throw new HttpException(err.message, HttpStatus.NOT_FOUND);
      });
  }

  async getArticleById(idArticle: string): Promise<Article> {
    return this.articleModel
      .findById(idArticle)
      .populate({ path: "author", select: ["phoneNumber", "username"] })
      .then((article) => {
        if (article) {
          return article;
        }
        throw new HttpException(
          errors.ARTICLE_DOES_NOT_EXIST,
          HttpStatus.BAD_REQUEST
        );
      })
      .catch((err) => {
        throw new HttpException(err.message, HttpStatus.BAD_REQUEST);
      });
  }

  async createArticle(aArticle: any, idUser: string): Promise<Article> {
    const article = new this.articleModel({
      ...aArticle,
      author: idUser,
    });
    return await article
      .save()
      .then((data) => {
        return data;
      })
      .catch((err) => {
        throw new HttpException(err.message, HttpStatus.BAD_REQUEST);
      });
  }

  async updateArticle(idArticle: string, contentUpdate: any): Promise<Article> {
    return await this.articleModel
      .findOneAndUpdate(
        { _id: idArticle },
        {
          ...contentUpdate,
          updatedAt: Date.now().toString(),
        },
        { new: true }
      )
      .then((data) => {
        if (data) {
          return data;
        }
        throw new HttpException(
          errors.ARTICLE_DOES_NOT_EXIST,
          HttpStatus.BAD_REQUEST
        );
      })
      .catch((err) => {
        throw new HttpException(err.message, HttpStatus.BAD_REQUEST);
      });
  }

  async deleteArticle(idArticle: string): Promise<any> {
    return this.articleModel
      .findByIdAndDelete({ _id: idArticle })
      .then((data) => {
        return data._id;
      })
      .catch((err) => {
        throw new HttpException(err.message, HttpStatus.BAD_REQUEST);
      });
  }
}
