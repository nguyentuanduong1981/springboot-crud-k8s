import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import {
  ProjectCategory,
  ProjectCategoryDocument,
} from "src/schemas/projectCategory.schema";
import { Model } from "mongoose";
import { stringToSlug } from "src/utilities/helpers";

@Injectable()
export class ProjectCategoryService {
  constructor(
    @InjectModel(ProjectCategory.name)
    private projectCategoryModel: Model<ProjectCategoryDocument>
  ) {}

  async getAllProjectCategory(): Promise<ProjectCategory[]> {
    const allCategory = await this.projectCategoryModel.find().exec();
    return allCategory;
  }

  async createProjectCategory(category: any): Promise<ProjectCategory> {
    const { name } = category;

    const slug = stringToSlug(name);

    const categoryCreate = {
      name,
      slug,
    };

    return await this.projectCategoryModel.create(categoryCreate);
  }
}
