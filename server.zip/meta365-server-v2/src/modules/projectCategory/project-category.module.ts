import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import {
  ProjectCategory,
  ProjectCategorySchema,
} from "src/schemas/projectCategory.schema";
import { ProjectCategoryController } from "./project-category.controller";
import { ProjectCategoryService } from "./project-category.service";

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: ProjectCategory.name, schema: ProjectCategorySchema },
    ]),
  ],
  controllers: [ProjectCategoryController],
  providers: [ProjectCategoryService],
})
export class ProjectCategoryModule {}
