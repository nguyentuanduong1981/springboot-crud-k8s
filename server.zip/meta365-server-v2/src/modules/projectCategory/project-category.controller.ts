import { Body, Controller, Get, Post, UseGuards } from "@nestjs/common";
import { ApiBearerAuth } from "@nestjs/swagger";
import { JwtAuthGuard } from "src/commons/authentication/jwt-auth.guard";
import BaseController from "src/commons/baseController.controller";
import { ProjectCategoryDto } from "src/dtos/project.dto";
import { ValidUser } from "src/guards/valid-user.guard";
import { ProjectCategoryService } from "./project-category.service";

@Controller("project-category")
export class ProjectCategoryController extends BaseController {
  constructor(private projectCategoryService: ProjectCategoryService) {
    super();
  }

  @Get("")
  async getAllProjectCategory() {
    return this.response(
      await this.projectCategoryService.getAllProjectCategory()
    );
  }

  @UseGuards(JwtAuthGuard, ValidUser)
  @ApiBearerAuth()
  @Post("/create")
  async createCategory(@Body() body: ProjectCategoryDto) {
    return this.response(
      await this.projectCategoryService.createProjectCategory(body)
    );
  }
}
