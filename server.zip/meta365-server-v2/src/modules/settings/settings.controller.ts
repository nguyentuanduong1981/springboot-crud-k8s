import { Controller } from "@nestjs/common";

@Controller("settings")
export class SettingsController {}
