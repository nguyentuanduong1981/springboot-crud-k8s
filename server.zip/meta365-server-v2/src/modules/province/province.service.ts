import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Province, ProvinceDocument } from "src/schemas/province.schema";
import { Model } from "mongoose";
import errors from "src/commons/errors/errors.validator";

@Injectable()
export class ProvinceService {
  constructor(
    @InjectModel(Province.name) private provinceModel: Model<ProvinceDocument>
  ) {}

  async findProvinceByCode(code: string): Promise<any> {
    return await this.provinceModel
      .find({ code: { $regex: `^${code}` } })
      .sort({
        parentCode: 1,
      })
      .exec()
      .then((data) => {
        if (Object.keys(data).length) {
          return data.reduce((prev, curr) => {
            prev.wards.push(curr);
            return prev;
          });
        }

        throw new HttpException(
          errors.CODE_OF_PROVINCE_WRONG,
          HttpStatus.BAD_REQUEST
        );
      })
      .catch((err) => {
        throw new HttpException(err.message, HttpStatus.BAD_REQUEST);
      });
  }

  async getAllProvince(): Promise<Province[]> {
    return await this.provinceModel
      .find({})
      .where("parentCode")
      .equals(null)
      .catch((err) => {
        throw new HttpException(err.message, HttpStatus.BAD_REQUEST);
      });
  }

  async getProvinceByCode(code: string): Promise<Province[]> {
    return this.findProvinceByCode(code);
  }
}
