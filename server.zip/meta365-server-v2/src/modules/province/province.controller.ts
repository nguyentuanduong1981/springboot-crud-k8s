import { Body, Controller, Get, Param, Post, UseGuards } from "@nestjs/common";
import { ApiParam, ApiTags } from "@nestjs/swagger";
import { JwtAuthGuard } from "src/commons/authentication/jwt-auth.guard";
import BaseController from "src/commons/baseController.controller";
import { ProvinceService } from "./province.service";

@Controller("province")
@ApiTags("province")
export class ProvinceController extends BaseController {
  constructor(private provinceService: ProvinceService) {
    super();
  }

  @Get("")
  async getAllProvince() {
    return this.response(await this.provinceService.getAllProvince());
  }

  @ApiParam({
    name: "code",
    required: true,
    example: "101",
  })
  @Get("/:code")
  async getProvinceByCode(@Param() param) {
    return this.response(
      await this.provinceService.getProvinceByCode(param.code)
    );
  }
}
