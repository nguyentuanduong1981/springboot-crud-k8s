import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Query,
  Request,
  UploadedFiles,
  UseGuards,
  UseInterceptors,
  UsePipes,
} from "@nestjs/common";
import {
  ApiBearerAuth,
  ApiConsumes,
  ApiParam,
  ApiQuery,
  ApiTags,
} from "@nestjs/swagger";
import { DeleteProjectsDto, UpdateProjectDto } from "src/dtos/project.dto";
import { JwtAuthGuard } from "src/commons/authentication/jwt-auth.guard";
import BaseController from "src/commons/baseController.controller";
import { CreateProjectDto } from "src/dtos/project.dto";
import { ValidUser } from "src/guards/valid-user.guard";
import { ResponsePaginationCommon } from "src/interfaces/responseHttp.interface";
import { ProjectPhases, ProjectStatus } from "src/utilities/constants";
import { fileFieldsInterceptor } from "src/utilities/helpers";
import { ProjectService } from "./project.service";
import errors from "src/commons/errors/errors.validator";
import { ObjectIdPipe } from "src/commons/pipes/validate-objectid.pipe";
import { NumberPipe } from "src/commons/pipes/number.pipe";

@Controller("project")
@ApiTags("project")
export default class extends BaseController {
  constructor(private projectService: ProjectService) {
    super();
  }

  @ApiQuery({
    name: "status",
    example: ProjectStatus.PUBLIC,
    enum: ProjectStatus,
    required: false,
  })
  @ApiQuery({
    name: "phase",
    example: ProjectPhases.OPEN_FOR_SALE,
    enum: ProjectPhases,
    required: false,
  })
  @ApiQuery({
    name: "totalInvestment",
    type: Array,
    description: "Require 2 item for min and max of total investment",
    example: [0, 1],
    required: false,
  })
  @ApiQuery({
    name: "type",
    type: String,
    example: "type",
    required: false,
  })
  @ApiQuery({
    name: "name",
    example: "Name of Project",
    required: false,
  })
  @ApiQuery({
    name: "location",
    type: Number,
    example: 10101,
    required: false,
  })
  @Get("")
  async getAllProject(@Query() query): Promise<ResponsePaginationCommon> {
    return this.responsePagination(
      await this.projectService.getAllProject(query)
    );
  }

  @UsePipes(new NumberPipe([]))
  @Get("/handpicked")
  async handPickedProject(@Query() query): Promise<any> {
    return this.response(await this.projectService.handPickedProject(query));
  }

  @ApiParam({
    name: "id",
    required: true,
    example: "62beccc3138a81a79d322f4d",
  })
  @Get("/:id")
  async getProjectById(
    @Param("id", new ObjectIdPipe(errors.PROJECT_DOES_NOT_EXIST)) id,
    @Query() query
  ) {
    return this.response(await this.projectService.getProjectById(id));
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, ValidUser)
  @Post("create")
  @ApiConsumes("multipart/form-data")
  @UseInterceptors(
    fileFieldsInterceptor(
      [
        { name: "logo", maxCount: 1 },
        { name: "images", maxCount: 10 },
      ],
      "project",
      ["jpeg", "png", "jpg"]
    )
  )
  async createProject(
    @Body() body: CreateProjectDto,
    @Request() request,
    @UploadedFiles()
    files: {
      logo?: Express.Multer.File[];
      images?: Express.Multer.File[];
    }
  ) {
    const project = {
      ...body,
      images: files.images,
      logo: files.logo,
    };
    return this.response(await this.projectService.createProject(project));
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, ValidUser)
  @Delete("remove")
  async removeListProject(@Body() body: DeleteProjectsDto) {
    return this.response(await this.projectService.deleteProjects(body.key));
  }

  @ApiParam({
    name: "id",
    required: true,
    example: "62beccc3138a81a79d322f4d",
  })
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, ValidUser)
  @Post("update/:id")
  @ApiConsumes("multipart/form-data")
  @UseInterceptors(
    fileFieldsInterceptor(
      [
        { name: "logo", maxCount: 1 },
        { name: "images", maxCount: 10 },
      ],
      "project",
      ["jpeg", "png", "jpg"]
    )
  )
  async updateProject(
    @Param("id", new ObjectIdPipe(errors.PROJECT_DOES_NOT_EXIST)) id,
    @Body() body: UpdateProjectDto,
    @UploadedFiles()
    files: {
      logo?: Express.Multer.File;
      images?: Express.Multer.File[];
    }
  ) {
    const project = {
      ...body,
      images: files.images,
      logo: files.logo,
    };

    return this.response(await this.projectService.updateProject(id, project));
  }

  @ApiParam({
    name: "id",
    required: true,
    example: "62beccc3138a81a79d322f4d",
  })
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, ValidUser)
  @Delete("/:id")
  async deleteProject(
    @Param("id", new ObjectIdPipe(errors.PROJECT_DOES_NOT_EXIST)) id,
    @Request() request
  ) {
    return this.response(
      await this.projectService.deleteProject(id, request.user.userId)
    );
  }
}
