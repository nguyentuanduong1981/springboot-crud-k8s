import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Project, ProjectDocument } from "src/schemas/project.schema";
import { Model, Types } from "mongoose";
import errors from "src/commons/errors/errors.validator";
import { Pagination } from "src/commons/paginate/pagination";
import { getUserPopulateConfig } from "../user/user.service";
import { removeImage } from "src/utilities/helpers";
import { UpdateProjectDto } from "src/dtos/project.dto";

export function getProjectPopulateConfig(config = {}) {
  return {
    _id: 1,
    investor: 1,
    images: 1,
    name: 1,
    description: 1,
    media: 1,
    ...config,
  };
}
@Injectable()
export class ProjectService {
  constructor(
    @InjectModel(Project.name) private projectModel: Model<ProjectDocument>
  ) {}

  convertToString(text: string) {
    return text.replace(/^'+/, "").replace(/'+$/, "");
  }

  getModel() {
    return this.projectModel;
  }

  async getAllProject(query): Promise<Pagination<ProjectDocument>> {
    const limit = query.limit || 12;
    const offset = ((query.page > 0 ? query.page : 1) - 1) * limit;
    let total = 0;
    const filter = this.parseFilter(query);
    let sort = {
      createdAt: -1,
    };

    if (query.sort) {
      const mapSort = query.sort.split(":");
      sort[mapSort[0]] = mapSort[1] || "asc";
    }

    const projects = await this.projectModel
      .find(filter)
      .where()
      .skip(offset)
      .limit(limit)
      .sort(sort)
      .exec()
      .then(async (projects) => {
        total = await this.projectModel.countDocuments();
        return {
          results: projects,
          total,
        };
      })
      .catch((err) => {
        throw new HttpException(err.message, HttpStatus.BAD_REQUEST);
      });
    return new Pagination<ProjectDocument>(projects);
  }

  async handPickedProject(query): Promise<ProjectDocument | any> {
    const limit = query.limit || 12;
    const project = await this.projectModel
      .aggregate([
        {
          $sample: {
            size: limit,
          },
        },
      ])
      .exec();
    return project;
  }

  parseFilter(query) {
    const { name, status, totalInvestment, location, phase } = query;
    let filter: any = {};
    if (name) {
      filter.$text = {
        $search: name || "",
      };
    } else {
      filter.name = { $regex: "", $options: "i" };
    }
    if (status) {
      filter.status = status;
    }
    if (phase) {
      filter.phase = phase;
    }
    if (totalInvestment && totalInvestment.length) {
      const min = Math.min(totalInvestment[0], totalInvestment[1]) || 0;
      const max =
        Math.max(totalInvestment[0], totalInvestment[1]) || 1000000000;
      filter.totalInvestment = { $gte: min, $lte: max };
    }
    if (location) {
      filter.$or = [
        {
          "location.province": location,
        },
        {
          "location.district": location,
        },
        {
          "location.village": location,
        },
      ];
    }
    return filter;
  }

  async getProjectById(id: string): Promise<any> {
    return await this.projectModel
      .findById(id)
      .populate({
        path: "links",
        select: {
          project: 1,
        },
        options: {
          limit: 12,
          skip: 0,
          sort: {
            createdAt: -1,
            _id: -1,
          },
        },
        populate: {
          path: "user",
          select: getUserPopulateConfig(),
        },
      })
      .exec()
      .catch((err) => {
        throw new HttpException(err.message, HttpStatus.BAD_REQUEST);
      });
  }

  mapDataToSave(data: any) {
    const { logo, images } = data;

    const logoPath = logo ? `project/${logo[0].filename}` : "";
    const imagesPath = images
      ? Array.from(images).map((image) => {
          return `project/${image["filename"]}`;
        })
      : [];

    const dataSave = {
      ...data,
      images: imagesPath,
      logo: logoPath,
    };

    if (data.location && typeof data.location === "string") {
      dataSave["location"] = JSON.parse(data.location);
    }

    if (data.seo && typeof data.seo === "string") {
      dataSave["seo"] = JSON.parse(data.seo);
    }

    if (data.coordinates && typeof data.location === "string") {
      dataSave["coordinates"] = JSON.parse(data.coordinates);
    }

    if (data.totalInvestment) {
      dataSave["totalInvestment"] = Number(
        data.totalInvestment !== NaN ? data.totalInvestment : 0
      );
    }

    if (data.commencementDate) {
      dataSave["commencementDate"] = new Date(data.commencementDate);
    }

    if (data.commencementDate) {
      dataSave["finishedDate"] = new Date(data.finishedDate);
    }

    dataSave.owner = dataSave.owner || null;

    return dataSave;
  }

  async createProject(project): Promise<any> {
    const projectCreate = this.mapDataToSave(project);
    return await this.projectModel.create(projectCreate);
  }

  async deleteProjects(keys: string[]) {
    try {
      return await this.projectModel.deleteMany({ _id: keys }).exec();
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }

  async deleteProject(project, _userId): Promise<any> {
    const session = await this.projectModel.db.startSession();
    const isExisted = await this.getProjectById(project);
    if (!isExisted) {
      throw new HttpException(
        errors.PROJECT_DOES_NOT_EXIST,
        HttpStatus.BAD_REQUEST
      );
    }
    session.startTransaction();
    try {
      await this.projectModel.findByIdAndDelete(project);
      await session.commitTransaction();
      return;
    } catch (e) {
      await session.abortTransaction();
      throw new HttpException(e.message, HttpStatus.BAD_REQUEST);
    } finally {
      session.endSession();
    }
  }

  async updateProject(id: string, data: UpdateProjectDto) {
    const currentProject = await this.getProjectById(id);

    let { removedImage, removedLogo } = data;
    let { images, logo } = currentProject;

    logo = data.logo || logo;

    let dataUpdate = {
      ...JSON.parse(JSON.stringify(currentProject)),
      ...data,
    };

    dataUpdate = this.mapDataToSave(dataUpdate);

    //check images were deleted
    if (removedImage) {
      const removed = removedImage.split(",");
      const promises = [];
      removed.map((image: string) => {
        promises.push(removeImage(image));
      });
      await Promise.all(promises);
      images = images.filter((image) => !removed.includes(image));
    }
    images.push(...dataUpdate.images);
    dataUpdate.images = images;

    if (removedLogo) {
      await removeImage(removedLogo);
    }

    delete data.removedLogo;
    delete data.removedImage;

    const updated = await this.projectModel
      .findByIdAndUpdate(id, dataUpdate, { new: true })
      .exec();

    return updated;
  }
}
