import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { Project, ProjectSchema } from "src/schemas/project.schema";
import ProjectController from "./project.controller";
import { ProjectService } from "./project.service";
import ProjectSeeder from "seeders/project.seeder";

@Module({
  imports: [
    MongooseModule.forFeature([{ name: Project.name, schema: ProjectSchema }]),
  ],
  providers: [ProjectService, ProjectSeeder],
  controllers: [ProjectController],
  exports: [ProjectService],
})
export class ProjectModule {}
