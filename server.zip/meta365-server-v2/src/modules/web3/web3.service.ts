import { Injectable } from "@nestjs/common";
import Web3 from "web3";
import fs from "fs";
import { join } from "path";
const file = fs.readFileSync(
  join(process.cwd(), "contracts/abi/glc.json"),
  "utf-8"
);
const GLC = JSON.parse(file);

@Injectable()
export class Web3Service {
  public web3: Web3 = new Web3(
    new Web3.providers.HttpProvider("https://bsc-dataseed.binance.org/")
  );
  public contract = new this.web3.eth.Contract(
    GLC,
    "0x54c1e965433633b8dd80db7440f1f70813eb2622"
  );

  async getOwnerNFT(address) {
    const totalBoxOfAddress = await this.contract.methods
      .balanceOf(address)
      .call();
    let nft = [];
    for (let i = 0; i < totalBoxOfAddress; i++) {
      nft.push(this.contract.methods.tokenOfOwnerByIndex(address, i).call());
    }
    return await Promise.all(nft);
  }
}
