import { Controller } from "@nestjs/common";

@Controller("web3")
export class Web3Controller {}
