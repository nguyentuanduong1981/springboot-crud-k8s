import {
  ConsoleLogger,
  HttpException,
  HttpStatus,
  Injectable,
} from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Admin, AdminDocument } from "src/schemas/admin.schema";
import { Model } from "mongoose";
import { AuthenticationService } from "../authentication/authentication.service";
import errors from "src/commons/errors/errors.validator";
import * as bcrypt from "bcrypt";
import { JwtService } from "@nestjs/jwt";

@Injectable()
export class AdminService {
  constructor(
    @InjectModel(Admin.name) private adminModel: Model<AdminDocument>,
    private jwtService: JwtService
  ) {}

  async getAdminByUsername(username): Promise<any> {
    const adminFound = await this.adminModel
      .findOne({ username: username })
      .exec();
    if (!adminFound) {
      throw new HttpException(
        errors.ACCOUNT_DOES_NOT_EXIST,
        HttpStatus.BAD_REQUEST
      );
    }
    return {
      username: adminFound.username,
      role: adminFound.role,
    };
  }

  async getAuthenticatedAdmin(account): Promise<any> {
    const { username, password } = account;
    const checkUsername = await this.adminModel
      .findOne({ username: username })
      .exec();
    if (!checkUsername) {
      throw new HttpException(
        errors.ACCOUNT_DOES_NOT_EXIST,
        HttpStatus.BAD_REQUEST
      );
    }
    await this.verifyPassword(password, checkUsername.password);

    const payload = {
      username: username,
      role: checkUsername.role,
    };

    return {
      access_token: this.jwtService.sign(payload),
      currentUser: payload,
    };
  }

  async verifyPassword(plainTextPassword: string, hashedPassword: string) {
    const isPasswordMatching = await bcrypt.compare(
      plainTextPassword,
      hashedPassword
    );
    if (!isPasswordMatching) {
      throw new HttpException(
        errors.CREDENTIALS_IS_WRONG,
        HttpStatus.BAD_REQUEST
      );
    }
  }
}
