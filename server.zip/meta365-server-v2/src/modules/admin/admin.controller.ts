import {
  Body,
  Controller,
  Get,
  HttpCode,
  Post,
  Req,
  Request,
  UseGuards,
} from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { JwtAuthGuard } from "src/commons/authentication/jwt-auth.guard";
import BaseController from "src/commons/baseController.controller";
import { AdminLoginDto } from "src/dtos/admin.dto";
import { AdminService } from "./admin.service";

@ApiTags("admin")
@Controller("admin")
export class AdminController extends BaseController {
  constructor(private adminService: AdminService) {
    super();
  }

  @Post("/login")
  async adminLogin(@Body() adminLoginDto: AdminLoginDto) {
    return this.response(
      await this.adminService.getAuthenticatedAdmin(adminLoginDto)
    );
  }

  @Get("/profile")
  @UseGuards(JwtAuthGuard)
  async getCurrentUser(@Request() request) {
    return this.response(
      await this.adminService.getAdminByUsername(request.user.username)
    );
  }
}
