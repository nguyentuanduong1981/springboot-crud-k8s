import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Agent, AgentDocument } from "src/schemas/agent.schema";
import { Model, Types } from "mongoose";
import errors from "src/commons/errors/errors.validator";
import { Pagination } from "src/commons/paginate/pagination";
import { getUserPopulateConfig, UserService } from "../user/user.service";
import {
  AgencyRole,
  UserType,
  GenerateLinkList,
} from "src/utilities/constants";
import * as bcrypt from "bcrypt";
import { LinkService } from "../link/link.service";
import { ProjectService } from "../project/project.service";
import { createQR } from "src/utilities/helpers";
import { ConfigService } from "@nestjs/config";

@Injectable()
export class AgentService {
  constructor(
    @InjectModel(Agent.name) private agentModel: Model<AgentDocument>,
    private userService: UserService,
    private linkService: LinkService,
    private projectService: ProjectService,
    private configService: ConfigService
  ) {}

  getModel() {
    return this.agentModel;
  }

  async getAllAgent(query): Promise<Pagination<AgentDocument>> {
    const limit = query.limit || 12;
    const offset = ((query.page > 0 ? query.page : 1) - 1) * limit;
    let total = 0;
    const filter = this.parseFilter(query);

    const agents = await this.agentModel
      .find(filter)
      .where()
      .skip(offset)
      .limit(limit)
      .exec()
      .then(async (agents) => {
        total = await this.agentModel.countDocuments();
        return {
          results: agents,
          total,
        };
      })
      .catch((err) => {
        throw new HttpException(err.message, HttpStatus.BAD_REQUEST);
      });
    return new Pagination<AgentDocument>(agents);
  }

  parseFilter(query) {
    const { name, status, totalInvestment, location } = query;
    let filter: any = {
      name: { $regex: `${name || ""}`, $options: "i" },
    };
    if (status) {
      filter.status = status;
    }
    if (totalInvestment && totalInvestment.length) {
      const min = Math.min(totalInvestment[0], totalInvestment[1]) || 0;
      const max =
        Math.max(totalInvestment[0], totalInvestment[1]) || 1000000000;
      filter.totalInvestment = { $gte: min, $lte: max };
    }
    if (location) {
      filter.$or = [
        {
          "location.province": location,
        },
        {
          "location.district": location,
        },
        {
          "location.village": location,
        },
      ];
    }
    return filter;
  }

  async getAgentById(id: string): Promise<any> {
    return await this.agentModel
      .findById(id)
      .populate([
        {
          path: "owner",
          select: getUserPopulateConfig(),
        },
        {
          path: "members.info",
          select: getUserPopulateConfig({
            email: 1,
          }),
        },
      ])
      .exec()
      .catch((err) => {
        throw new HttpException(err.message, HttpStatus.BAD_REQUEST);
      });
  }

  async createAgent(data, userId): Promise<Agent> {
    const owner = await this.userService.findUserById(userId);
    const session = await this.agentModel.db.startSession();
    session.startTransaction();
    try {
      const agent = await this.agentModel.create({
        ...data,
        owner,
        members: [
          {
            info: owner,
            role: AgencyRole.SUPER_ADMIN,
          },
        ],
      });
      // await this.userService.updateProfile({

      // })
      await this.userService.updateProfile(userId, {
        agent,
        userType: UserType.AGENCY,
        ownerOfAgent: agent,
      });
      await session.commitTransaction();
      return agent.populate([
        {
          path: "owner",
          select: getUserPopulateConfig(),
        },
        {
          path: "members",
          select: getUserPopulateConfig(),
        },
      ]);
    } catch (e) {
      await session.abortTransaction();
      throw new HttpException(e.message, HttpStatus.BAD_REQUEST);
    } finally {
      session.endSession();
    }
  }

  async generateLinkForMember(body, userId) {
    let { project, members, list } = body;

    const owner = await this.userService.findUserById(userId);
    const agent = await this.agentModel.findById(owner.agent).exec();
    project = await this.projectService.getModel().findById(project);

    this.linkService.validateProject(project);

    let find = {
      agent: agent._id,
    };

    if (list === GenerateLinkList.LIST) {
      find["_id"] = {
        $in: members,
      };
    }

    const users = await this.userService.getModel().find(find);
    const session = await this.agentModel.db.startSession();
    session.startTransaction();
    try {
      const links = [];
      for (const user of users) {
        let link = await this.linkService.createLink(project, user, false);
        await this.userService
          .getModel()
          .findOneAndUpdate(link.user._id, {
            $push: { links: new Types.ObjectId(link._id) },
          });
        links.push(link);
      }
      await this.projectService
        .getModel()
        .findByIdAndUpdate(
          project._id,
          { $addToSet: { links: { $each: links } } },
          { safe: true, upsert: true, new: true }
        );

      await session.commitTransaction();
      return {
        generated: true,
      };
    } catch (e) {
      await session.abortTransaction();
      throw new HttpException(e.message, HttpStatus.BAD_REQUEST);
    } finally {
      session.endSession();
    }
    return [];
  }

  async addMembers(data: any[], userId) {
    const owner = await this.userService.findUserById(userId);
    const agent = await this.agentModel.findById(owner.agent).exec();
    let members: any[] = data.map(async (member) => {
      const phoneNumber = `+84${member.phoneNumber.slice(1)}`;
      const password = await bcrypt.hash(`${phoneNumber.slice(1)}`, 10);
      return {
        ...member,
        phoneNumber,
        password,
        userType: UserType.BROKER,
        username: this.userService.getRandomUser(6),
        country: owner.country,
        agent: owner.agent,
      };
    });
    const session = await this.agentModel.db.startSession();
    session.startTransaction();
    try {
      members = await Promise.all(members);
      members = await this.userService.getModel().insertMany(members, {
        ordered: false,
        lean: true,
      });
      const agentMembers = members.map((member) => {
        return {
          info: member,
          role: AgencyRole.MEMBER,
        };
      });
      agent.members.push(...agentMembers);
      await agent.save();
      await session.commitTransaction();
      return members.map((member) => ({
        ...member,
        role: AgencyRole.MEMBER,
      }));
    } catch (e) {
      await session.abortTransaction();
      throw new HttpException(e.message, HttpStatus.BAD_REQUEST);
    } finally {
      session.endSession();
    }
  }
}
