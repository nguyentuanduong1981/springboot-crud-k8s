import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { Agent, AgentSchema } from "src/schemas/agent.schema";
import { LinkModule } from "../link/link.module";
import { ProjectModule } from "../project/project.module";
import { UserModule } from "../user/user.module";
import AgentController from "./agent.controller";
import { AgentService } from "./agent.service";

@Module({
  imports: [
    MongooseModule.forFeature([{ name: Agent.name, schema: AgentSchema }]),
    UserModule,
    LinkModule,
    ProjectModule,
  ],
  controllers: [AgentController],
  providers: [AgentService],
  exports: [AgentService],
})
export class AgentModule {}
