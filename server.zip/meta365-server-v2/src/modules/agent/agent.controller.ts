import {
  Body,
  Controller,
  Get,
  Injectable,
  Param,
  Post,
  Query,
  UseGuards,
  UsePipes,
  Request,
  UploadedFile,
  UseInterceptors,
} from "@nestjs/common";
import {
  ApiBearerAuth,
  ApiBody,
  ApiConsumes,
  ApiParam,
  ApiQuery,
  ApiTags,
} from "@nestjs/swagger";
import { JwtAuthGuard } from "src/commons/authentication/jwt-auth.guard";
import BaseController from "src/commons/baseController.controller";
import validationRequestPipe from "src/commons/pipes/request.pipe";
import { BecomeAnAgentDto, GenerateLinkForMemberDto } from "src/dtos/agent.dto";
import { ValidUser } from "src/guards/valid-user.guard";
import { ResponsePaginationCommon } from "src/interfaces/responseHttp.interface";
import { AgentService } from "./agent.service";
import * as XLSX from "xlsx";
import errors from "src/commons/errors/errors.validator";
import { fileInterceptors } from "src/utilities/helpers";
import { ObjectIdPipe } from "src/commons/pipes/validate-objectid.pipe";

@Controller("")
@ApiTags("agent")
@Injectable()
export default class extends BaseController {
  constructor(private agentService: AgentService) {
    super();
  }

  @ApiQuery({
    name: "agentType",
    type: String,
    example: "agency",
    required: false,
  })
  @Get("/agent")
  @ApiQuery({
    name: "name",
    example: "Name of Agent",
    required: false,
  })
  async getAllAgent(@Query() query): Promise<ResponsePaginationCommon> {
    return this.responsePagination(await this.agentService.getAllAgent(query));
  }

  @ApiParam({
    name: "id",
    required: true,
    example: "abc",
  })
  @Get("/agent/:id")
  async getAgentById(
    @Param("id", new ObjectIdPipe(errors.LINK_DOES_NOT_EXIST)) id,
    @Query() query
  ) {
    return this.response(await this.agentService.getAgentById(id));
  }

  @ApiBearerAuth()
  @UsePipes(validationRequestPipe)
  @UseGuards(JwtAuthGuard, ValidUser)
  @Post("become-an-agency")
  async becomeToAgent(@Body() body: BecomeAnAgentDto, @Request() request) {
    return this.response(
      await this.agentService.createAgent(body, request.user.userId)
    );
  }

  @ApiBearerAuth()
  @UsePipes(validationRequestPipe)
  @UseGuards(JwtAuthGuard, ValidUser)
  @Post("generate-link-for-member")
  async generateLinkForMember(
    @Body() body: GenerateLinkForMemberDto,
    @Request() request
  ) {
    return this.response(
      await this.agentService.generateLinkForMember(body, request.user.userId)
    );
  }

  @ApiConsumes("multipart/form-data")
  @ApiBody({
    schema: {
      type: "object",
      properties: {
        file: {
          type: "string",
          format: "binary",
        },
      },
    },
  })
  @UseInterceptors(
    fileInterceptors(
      "agent",
      ["vnd.openxmlformats-officedocument.spreadsheetml.sheet"],
      errors.FILE_NOT_ALLOWS_FILE_TYPES
    )
  )
  @ApiBearerAuth()
  @UsePipes(validationRequestPipe)
  @UseGuards(JwtAuthGuard, ValidUser)
  @Post("/add-member-by-excel")
  uploadFile(
    @Body() body,
    @UploadedFile() file: Express.Multer.File,
    @Request() request
  ) {
    const workbook = XLSX.readFile(file.path);
    const data = XLSX.utils.sheet_to_json(
      workbook.Sheets[workbook.SheetNames[0]],
      {
        // header: 'A'
        header: ["phoneNumber", "fullName", "email"],
      }
    );
    data.shift();
    const members = this.agentService.addMembers(data, request.user.userId);
    return members;
  }
}
