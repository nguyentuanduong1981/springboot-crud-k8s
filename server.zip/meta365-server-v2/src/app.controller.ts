import { Controller, Get } from "@nestjs/common";
import { AppService } from "./app.service";
import BaseController from "./commons/baseController.controller";

@Controller()
export class AppController extends BaseController {
  constructor(private readonly appService: AppService) {
    super();
  }

  @Get("/appdata")
  async getAppData() {
    return this.response(await this.appService.getAppData());
  }
}
