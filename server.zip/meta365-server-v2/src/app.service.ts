import { Injectable } from "@nestjs/common";
import { version, name } from "../package.json";
// import i18n from '../src/i18n/messages.i18n';
// import { SettingsService } from './modules/settings/settings.service';
@Injectable()
export class AppService {
  constructor() {}
  async getAppData(): Promise<object> {
    // const settings = await this.settingService.getAvailableSettings()
    return {
      name,
      version,
      // i18n,
      // settings
    };
  }
}
