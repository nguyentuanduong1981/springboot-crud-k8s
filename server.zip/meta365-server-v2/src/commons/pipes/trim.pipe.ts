import { Injectable, PipeTransform, ArgumentMetadata } from "@nestjs/common";
import { omit, pick } from "lodash";

@Injectable()
export class TrimPipe implements PipeTransform {
  protected omit = [];
  constructor(omit: string[]) {
    this.omit = omit;
  }
  private isObj(obj: any): boolean {
    return typeof obj === "object" && obj !== null;
  }

  private trim(values) {
    Object.keys(values).forEach((key) => {
      if (key !== "password") {
        if (this.isObj(values[key])) {
          values[key] = this.trim(values[key]);
        } else {
          if (typeof values[key] === "string") {
            values[key] = values[key].trim().replace(/\s{2,}/g, " ");
          }
        }
      }
    });
    return values;
  }

  transform(values: any, metadata: ArgumentMetadata) {
    const { type } = metadata;

    if (this.isObj(values) && type === "body") {
      values = {
        ...pick(values, this.omit),
        ...this.trim(omit(values, this.omit)),
      };
    }
    return values;
  }
}
