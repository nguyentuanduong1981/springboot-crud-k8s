import {
  UnprocessableEntityException,
  HttpStatus,
  ValidationPipe,
} from "@nestjs/common";
import { ValidationError } from "class-validator/types/validation/ValidationError";

class ValidationRequestPipe extends ValidationPipe {}

const validationRequestPipe = new ValidationRequestPipe({
  transform: true,
  forbidUnknownValues: true,
  validationError: {
    target: false,
  },
  whitelist: true,
  forbidNonWhitelisted: true,
  errorHttpStatusCode: HttpStatus.UNPROCESSABLE_ENTITY,

  exceptionFactory: (validationErrors: ValidationError[] = []) => {
    const errors = validationErrors.map((error) => {
      return {
        field: error.property,
        message: Object.values(error.constraints)[0],
      };
    });
    return new UnprocessableEntityException(errors);
  },
});

export default validationRequestPipe;
