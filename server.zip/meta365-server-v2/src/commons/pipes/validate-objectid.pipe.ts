import {
  Injectable,
  PipeTransform,
  ArgumentMetadata,
  NotFoundException,
} from "@nestjs/common";
import { Types } from "mongoose";

@Injectable()
export class ObjectIdPipe implements PipeTransform {
  protected errorMessage: String;
  constructor(errorMessage: string) {
    this.errorMessage = errorMessage;
  }

  transform(value: any, _metadata: ArgumentMetadata) {
    // if (!Types.ObjectId.isValid(value)) {
    //   throw new NotFoundException(this.errorMessage)
    // }
    return value;
  }
}
