import { Injectable, PipeTransform, ArgumentMetadata } from "@nestjs/common";
import { omit, pick } from "lodash";

@Injectable()
export class NumberPipe implements PipeTransform {
  protected omit = [];
  constructor(omit: string[]) {
    this.omit = omit;
  }
  private isObj(obj: any): boolean {
    return typeof obj === "object" && obj !== null;
  }

  private pipe(values) {
    Object.keys(values).forEach((key) => {
      if (typeof values[key] === "string") {
        values[key] = Number(values[key]);
      }
    });
    return values;
  }

  transform(values: any, metadata: ArgumentMetadata) {
    const { type } = metadata;

    if (this.isObj(values) && ["body", "query"].includes(type)) {
      values = {
        ...pick(values, this.omit),
        ...this.pipe(omit(values, this.omit)),
      };
    }
    return values;
  }
}
