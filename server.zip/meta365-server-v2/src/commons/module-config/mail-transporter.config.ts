import { ConfigService } from "@nestjs/config";
import * as nodemailer from "nodemailer";
import { Transporter } from "nodemailer";

export default class MailTransporter {
  public config: ConfigService;
  transporter: Transporter;
  constructor(config: ConfigService) {
    this.config = config;
    console.log(config);
    this.transporter = nodemailer.createTransport({
      service: "SendGrid",
      host: this.config.get<string>("MAIL_HOST") || "smtp.sendgrid.net", //smtp.example.com
      port: +this.config.get<string>("MAIL_PORT") || 587,
      secure: false,
      // secure: !!this.config.get<string>('MAIL_SECURE') || true, // upgrade later with STARTTLS
      auth: {
        user: this.config.get<string>("MAIL_USERNAME") || "Meta2022",
        pass:
          this.config.get<string>("MAIL_PASSWORD") ||
          "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",
      },
      logger: true,
      debug: true,
      requireTLS: true,
      tls: {
        minVersion: "TLSv1",
        rejectUnauthorized: false,
      },
      secureConnection: true,
    });
  }

  verify() {
    this.transporter.verify(function (error, success) {
      if (error) {
        console.log(error);
      } else {
        console.log("Server is ready to take our messages");
      }
    });
  }
}
