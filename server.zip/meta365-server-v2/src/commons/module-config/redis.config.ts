import { ConfigService } from "@nestjs/config";
import { Redis as RedisType } from "ioredis";
import Redis from "ioredis";

export default class GomGopRedis {
  public config: ConfigService;
  redis: RedisType;
  constructor(config: ConfigService) {
    this.config = config;
    this.redis = new Redis({
      host: config.get<string>("REDIS_HOST"),
      port: parseInt(config.get<string>("REDIS_PORT")),
    });
  }
}
