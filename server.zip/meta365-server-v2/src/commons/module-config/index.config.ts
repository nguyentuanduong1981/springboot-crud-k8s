import { ConfigModule, ConfigService } from "@nestjs/config";
import { Module } from "@nestjs/common";
import { HttpModule } from "@nestjs/axios";
import { BullModule } from "@nestjs/bull";
import { ScheduleModule } from "@nestjs/schedule";
import { MulterModule } from "@nestjs/platform-express";
import { MongooseModule } from "@nestjs/mongoose";
import { CommandModule } from "nestjs-command";
import { MailerModule } from "@nestjs-modules/mailer";
import { HandlebarsAdapter } from "@nestjs-modules/mailer/dist/adapters/handlebars.adapter";
import handlebars from "handlebars";
import MailTransporter from "./mail-transporter.config";
import { join } from "path";

const mailHelpers = {
  handlebarsIntl: function (value) {
    let context = {
      value: value,
    };

    var intlData = {
      locales: ["en-US", "vi-VN"],
    };

    // use the formatNumber helper from handlebars-intl
    const template = handlebars.compile(
      "{{formatNumber value}} is the final result!"
    );

    const compiled = template(context, {
      data: {
        intl: intlData,
      },
    });

    return compiled;
  },
  otherHelper: function () {},
};

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),

    MongooseModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: async (configService: ConfigService) => ({
        uri: configService.get<string>("MONGODB_URI"),
      }),
      inject: [ConfigService],
    }),

    ScheduleModule.forRoot(),

    BullModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: async (configService: ConfigService) => ({
        redis: {
          host: configService.get<string>("REDIS_HOST"),
          port: parseInt(configService.get<string>("REDIS_PORT")),
        },
      }),
      inject: [ConfigService],
    }),

    MulterModule.registerAsync({
      imports: [ConfigModule],
      useFactory: async (configService: ConfigService) => ({
        dest: configService.get<string>("MULTER_DEST"),
      }),
      inject: [ConfigService],
    }),

    CommandModule,

    HttpModule.registerAsync({
      imports: [ConfigModule],
      useFactory: async (configService: ConfigService) => ({
        timeout: configService.get("HTTP_TIMEOUT"),
        maxRedirects: configService.get("HTTP_MAX_REDIRECTS"),
      }),
      inject: [ConfigService],
    }),

    MailerModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (configService: ConfigService) => {
        return {
          transport: new MailTransporter(configService).transporter.transporter,
          // transport: (new MailTransporter(configService)).transporter,
          defaults: {
            from:
              configService.get<string>("MAIL_FROM") ||
              '"META365" <hotro@meta365.ai',
          },
          preview: {
            dir: join(process.cwd(), "/templates/mails/pages"),
            open: true,
          },
          template: {
            dir: join(process.cwd(), "/templates/mails/pages"),
            adapter: new HandlebarsAdapter(mailHelpers),
            options: {
              strict: true,
            },
          },
          options: {
            partials: {
              dir: join(process.cwd(), "templates/mails/partials"),
              options: {
                strict: true,
              },
            },
          },
        };
      },
      inject: [ConfigService],
    }),
  ],
})
export class ConfigServiceModule {}
