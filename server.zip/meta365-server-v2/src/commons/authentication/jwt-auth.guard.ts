import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { AuthGuard } from "@nestjs/passport";
import { TokenExpiredError } from "jsonwebtoken";

@Injectable()
export class JwtAuthGuard extends AuthGuard("jwt") {
  handleRequest(_err, user, info: Error) {
    if (info instanceof TokenExpiredError || !user) {
      throw new HttpException(
        "error.authentication.token_expired",
        HttpStatus.UNAUTHORIZED
      );
    }
    return user;
  }
}
