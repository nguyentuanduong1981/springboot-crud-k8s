export interface PaginationOptionsInterface {
  [x: string]: any | number;
  page: number;
  limit: number;
}
