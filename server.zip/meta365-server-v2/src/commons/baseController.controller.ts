import { HttpException, HttpStatus } from "@nestjs/common";
// import { UserRoles } from 'src/utilities/constants';
import {
  ResponseCommon,
  ResponsePaginationCommon,
} from "../interfaces/responseHttp.interface";
import { Pagination } from "./paginate";
export default class BaseController {
  constructor() {}
  response(
    data: any,
    code: number = 200,
    message: string = "success",
    error: boolean = false
  ): ResponseCommon {
    return {
      data,
      code,
      message,
      error,
    };
  }

  responsePagination(
    data: Pagination<any>,
    code: number = 200,
    message: string = "success",
    error: boolean = false
  ): ResponsePaginationCommon {
    return {
      data,
      code,
      message,
      error,
    };
  }

  // onlyAdmin (user) {
  //   if (!user.role || user.role !== UserRoles.ADMIN) {
  //     throw new HttpException('Not Found', HttpStatus.NOT_FOUND);
  //   }
  // }

  // exceptUser (user) {
  //   if (!user.role || user.role === UserRoles.USER) {
  //     throw new HttpException('Not Found', HttpStatus.NOT_FOUND);
  //   }
  // }
}
