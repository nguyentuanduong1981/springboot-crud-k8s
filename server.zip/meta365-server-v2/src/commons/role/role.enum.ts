export enum Role {
  User = "user",
  SuperAdmin = "super admin",
}
