import { Catch, ArgumentsHost } from "@nestjs/common";
import { BaseExceptionFilter } from "@nestjs/core";
// import { t } from '../../i18n/index.i18n'

@Catch()
export class AllExceptionsFilter extends BaseExceptionFilter {
  catch(exception: any, host: ArgumentsHost) {
    // exception.response = t(exception.response);
    super.catch(exception, host);
  }
}
