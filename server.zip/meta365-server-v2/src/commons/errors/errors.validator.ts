const errors = {
  PUBLIC_ADDRESS_HAVE_BEEN_TAKEN:
    "notification.error.public_address_have_been_taken",
  PHONE_NUMBER_HAVE_BEEN_TAKEN:
    "notification.error.phoneNumber_have_been_taken",
  SIGNATURE_VERIFICATION_FAILED:
    "notification.error.signature_verification_failed",
  ACCOUNT_INACTIVE: "notification.error.account_inactive",
  ACCOUNT_CAN_NOT_LOGIN: "notification.error.account_can_not_login",
  ACCOUNT_BLOCKED: "notification.error.account_is_blocked",
  ACCOUNT_DOES_NOT_EXIST: "notification.error.account_does_not_exist",
  USER_NOT_FOUND: "notification.error.user_not_found",
  CREDENTIALS_IS_WRONG: "notification.error.credentials_is_wrong",
  ARTICLE_DOES_NOT_EXIST: "notification.error.article_does_not_exist",
  CODE_OF_PROVINCE_WRONG: "notification.error.code_of_province_wrong",
  PROJECT_DOES_NOT_EXIST: "notification.error.project_does_not_exist",
  PROJECT_CAN_NOT_BE_REGISTERED_FOR_SALE:
    "notification.error.project_can_not_be_registered_for_sale",
  RANGE_OF_PRICE_IS_WRONG: "notification.error.range_of_price_is_wrong",
  FORM_OF_DATE_REQUEST_WAS_WRONG:
    "notification.error.form_of_date_request_was_wrong",
  PROJECT_NAME_DOES_NOT_EXIST: "notification.error.project_name_does_not_exist",
  PROJECT_INVESTOR_DOES_NOT_EXIST:
    "notification.error.project_investor_does_not_exist",
  PROJECT_LOCATION_DOES_NOT_EXIST:
    "notification.error.project_location_does_not_exist",
  RANGE_OF_PRICE_NOT_EXISTS: "notification.error.range_of_price_not_exists",
  RANGE_OF_DATE_NOT_EXISTS: "notification.error.range_of_date_not_exists",
  LINK_DOES_NOT_EXIST: "notification.error.link_does_not_exist",
  LINK_HAVE_BEEN_TAKEN: "notification.error.link_have_been_taken",
  ASSET_DOES_NOT_EXIST: "notification.error.asset_does_not_exist",
  ASSET_CAN_NOT_OPEN: "notification.error.asset_can_not_open",
  AVATAR_NOT_ALLOWS_FILE_TYPES:
    "notification.error.avatar_not_allows_file_types",
  MEDIA_NOT_ALLOWS_FILE_TYPES: "notification.error.media_not_allows_file_types",
  FILE_NOT_ALLOWS_FILE_TYPES: "notification.error.file_not_allows_file_types",
  USER_MEDIA_NOT_FOUND: "notification.error.user_media_not_found",
  CHANGE_USERNAME_ONCE: "notification.error.change_username_once",
  EMAIL_HAVE_BEEN_TAKEN: "notification.error.email_have_been_taken",
  NEW_DATA_IS_SAME_OLD_DATA: "notification.error.new_data_is_same_old_data",
  YOU_MUST_BE_A_BROKER: "notification.error.you_must_be_a_broker",
  ID_IS_INVALID: "notification.error.id_is_invalid",
  LOGIN_WITH_SOCIAL_NETWORK_OR_WALLET_CANNOT_CHANGE_PASSWORD:
    "notification.error.login_with_the_social_network_or_wallet_can_not_change_password",
  CURRENT_PASSWORD_DOES_NOT_MATCH_THE_PASSWORD_YOU_PROVIDER:
    "'notification.error.your_current_password_does_not_matches_with_the_password_you_provided",
  NEW_PASSWORD_CANNOT_BE_SAME_AS_YOUR_CURRENT_PASSWORD:
    "notification.error.new_password_cannot_be_same_as_your_current_password",
  YOU_HAVE_FAVORED_THE_MAXIMUM: "notification.you_have_favored_the_maximum",
};

export default errors;
