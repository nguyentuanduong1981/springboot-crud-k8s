enum DatabaseErrorCode {
  ER_DUP_ENTRY = "ER_DUP_ENTRY",
}

export default DatabaseErrorCode;
