import XRegExp from "xregexp";
import { createCanvas, loadImage, CanvasRenderingContext2D } from "canvas";
import { AwesomeQR } from "awesome-qr";
import fs from "fs";
import { join } from "path";
import { v4 as uuidv4 } from "uuid";
import { extname } from "path";
import {
  FileFieldsInterceptor,
  FileInterceptor,
} from "@nestjs/platform-express/multer";
import { diskStorage } from "multer";
import errors from "src/commons/errors/errors.validator";
import axios from "axios";

/**
 * Draws a rounded rectangle using the current state of the canvas.
 * If you omit the last three params, it will draw a rectangle
 * outline with a 5 pixel border radius
 * @param {Number} x The top left x coordinate
 * @param {Number} y The top left y coordinate
 * @param {Number} w The width of the rectangle
 * @param {Number} h The height of the rectangle
 * @param {Object} r All corner radii. Defaults to 0,0,0,0;
 * @param {Boolean} fill Whether to fill the rectangle. Defaults to false.
 * @param {Boolean} stroke Whether to stroke the rectangle. Defaults to true.
 */
const roundRect = function (
  ctx: CanvasRenderingContext2D,
  x,
  y,
  w,
  h,
  r,
  fill = true,
  stroke = false
) {
  const cornerRadius = {
    upperLeft: 0,
    upperRight: 0,
    lowerLeft: 0,
    lowerRight: 0,
  };
  if (typeof stroke == "undefined") {
    stroke = true;
  }
  if (typeof r === "object") {
    for (let side in r) {
      cornerRadius[side] = r[side];
    }
  }

  ctx.beginPath();
  ctx.moveTo(x + cornerRadius.upperLeft, y);
  ctx.lineTo(x + w - cornerRadius.upperRight, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + cornerRadius.upperRight);
  ctx.lineTo(x + w, y + h - cornerRadius.lowerRight);
  ctx.quadraticCurveTo(x + w, y + h, x + w - cornerRadius.lowerRight, y + h);
  ctx.lineTo(x + cornerRadius.lowerLeft, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - cornerRadius.lowerLeft);
  ctx.lineTo(x, y + cornerRadius.upperLeft);
  ctx.quadraticCurveTo(x, y, x + cornerRadius.upperLeft, y);
  ctx.closePath();
  if (stroke) {
    ctx.stroke();
  }
  if (fill) {
    ctx.fill();
  }
};

export function stringToSlug(s: string, delimiter: string = "-") {
  s = String(s);

  return s
    .toString() // Cast to string
    .toLowerCase() // Convert the string to lowercase letters
    .normalize("NFD") // The normalize() method returns the Unicode Normalization Form of a given string.
    .trim() // Remove whitespace from both sides of a string
    .replace(/\s+/g, delimiter) // Replace spaces with -
    .replace(/[^\w\-]+/g, "") // Remove all non-word chars
    .replace(/\-\-+/g, delimiter); // Replace multiple - with single -
}
/**
 * @param {Number} text The text to qr
 * @param {Number} path path file output
 * @param {Object} options config
 * */
export const createQR = async (text, path, options = {}) => {
  const config = {
    text,
    size: 268,
    margin: 0,
    version: 4,
    colorDark: "#000000",
    colorLight: "#FFFFFF",
    autoColor: true,
    whiteMargin: false,
    logoScale: 0.12,
    logoMargin: 8,
    logoCornerRadius: 8,
    dotScale: 0.48,
    correctLevel: 1,
    backgroundColor: "#263c6bcc",
    backgroundDimming: "#263c6bcc",
    backgroundImage: fs.readFileSync(join(process.cwd(), "static/winking.png")),
    components: {
      data: {
        scale: 0.48,
      },
      timing: {
        scale: 0.5,
        protectors: false,
      },
      alignment: {
        scale: 0.48,
        protectors: false,
      },
      cornerAlignment: {
        scale: 0.48,
        protectors: true,
      },
    },
    ...options,
    logoImage: fs.readFileSync(join(process.cwd(), "static/logo.png")),
  };
  const buffer = await new AwesomeQR(config).draw();
  const canvas = createCanvas(300, 300);
  const image = `data:image/png;base64,${buffer.toString("base64")}`;
  const ctx = canvas.getContext("2d");
  ctx.beginPath();
  ctx.strokeStyle = "#263c6bcc";
  ctx.lineWidth = 32;
  ctx.strokeRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  ctx.closePath();
  ctx.drawImage(await loadImage(image), 16, 16, 268, 268);
  const bufferQR = canvas.toDataURL("image/png");
  const dir = join(process.cwd(), "/static/images/qr");
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return fs.writeFile(
    join(process.cwd(), `static/${path}`),
    Buffer.from(bufferQR.replace(/^data:image\/\w+;base64,/, ""), "base64"),
    (err) => {
      if (err) throw err;
    }
  );
};

// export const createQR = async (dataForQRcode, center_image, width, cwidth, config = {
//   errorCorrectionLevel: 'H',
//   margin: 3,
//   color: {
//     dark: '#000000',
//     light: '#ffffff'
//   }
// }) => {
//   const canvas = createCanvas(width, width)
//   QRCode.toCanvas(
//     canvas,
//     dataForQRcode,
//     config
//   )

//   const ctx = canvas.getContext('2d')
//   const image = await loadImage(center_image)
//   // var image = new Image()
//   // image.src = center_image
//   // image.onload = () => {
//     const center = (width - cwidth) / 4
//     ctx.beginPath()
//     ctx.strokeStyle = '#263c6bcc'
//     ctx.lineWidth = 20
//     ctx.strokeRect(0, 0, ctx.canvas.width, ctx.canvas.height)
//     ctx.closePath()
//     ctx.fillStyle = '#263c6bcc'
//     roundRect(ctx, center, center, cwidth + 4, cwidth + 4, { upperLeft: 8, upperRight: 8, lowerLeft: 8, lowerRight: 8 })
//     ctx.drawImage(image, center + 4, center + 4, cwidth - 4, cwidth - 4)
//   // }
//   return canvas.toDataURL('image/png')
// }

export async function removeImage(path: string): Promise<any> {
  if (!path) return;
  return await fs.unlink(`static/images/${path}`, (err) => {
    if (err) {
      return err;
    }
  });
}

export function generateFilename(file) {
  return `${uuidv4()}${extname(file.originalname)}`;
}

export function mediaTypeToFolder(type: string): string {
  let folder = null;
  switch (type) {
    case "qr":
    case "avatar":
    case "cover":
    case "project":
    case "image": {
      folder = "images";
      break;
    }
  }
  return folder;
}

export function fileInterceptors(
  type,
  mime: string[],
  error = errors.MEDIA_NOT_ALLOWS_FILE_TYPES
) {
  const folder = mediaTypeToFolder(type);
  return FileInterceptor("file", {
    storage: diskStorage({
      destination: `./static/${folder || "files"}/${type}`,
      filename: (_req, file, callback) => {
        callback(null, generateFilename(file));
      },
    }),
    fileFilter: (req, file, callback) => {
      const extension = file.mimetype.split("/").slice(-1)[0];
      if (!extension || !mime.includes(extension)) {
        req.errorType = error;
        return callback(null, false);
      }
      callback(null, true);
    },
  });
}

export function download(url, imagePath) {
  const path = fs.createWriteStream(join(process.cwd(), imagePath));
  return axios({
    url,
    method: "GET",
    responseType: "stream",
  }).then(
    (response) =>
      new Promise((resolve, reject) => {
        response.data
          .pipe(path)
          .on("finish", () => resolve(true))
          .on("error", (e) => {
            console.log(e);
            reject(e);
          });
      })
  );
}

export function fileFieldsInterceptor(
  listFile,
  type,
  mime: string[],
  error = errors.MEDIA_NOT_ALLOWS_FILE_TYPES
) {
  const folder = mediaTypeToFolder(type);
  return FileFieldsInterceptor(listFile, {
    storage: diskStorage({
      destination: `./static/${folder || "medias"}/${type}`,
      filename: (_req, file, callback) => {
        callback(null, generateFilename(file));
      },
    }),
    fileFilter: (req, file, callback) => {
      const extension = file.mimetype.split("/").slice(-1)[0];
      if (!extension || !mime.includes(extension)) {
        req.errorType = error;
        return callback(null, false);
      }
      callback(null, true);
    },
  });
}
