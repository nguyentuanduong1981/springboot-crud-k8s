export enum PeriodUnit {
  DAY = "DAY",
  MONTH = "MONTH",
  YEAR = "YEAR",
}

export enum UserType {
  NORMAL = "normal",
  BROKER = "broker",
  AGENCY = "agency",
}

export enum AdminRoles {
  ADMIN = "admin",
  STAFF = "staff",
}

export enum FavoriteType {
  PROJECT = "project",
}

export enum Gender {
  MALE = "male",
  FEMALE = "female",
  NON_BINARY = "non_binary",
  PREFER_NOT_TO_SAY = "prefer_not_not_say",
}

export enum AgentType {
  AGENCY = "agency",
  INVESTOR = "investor",
}

export enum GenerateLinkList {
  ALL = "all",
  LIST = "list",
}

export enum ProjectPhases {
  OPEN_FOR_SALE = "open_for_sale",
  HAND_OVER = "hand_over",
  SOLD_OUT = "sold_out",
  NOT_SOLD_YET = "not_sold_yet",
}

export enum ProjectStatus {
  LOCK = "lock",
  PUBLIC = "public",
  PRIVATE = "private",
}

export enum ArticleStatus {
  PRIVATE = "private",
  PUBLIC = "public",
}
export enum AgencyRole {
  SUPER_ADMIN = "super_admin",
  ADMIN = "admin",
  LEADER = "leader",
  MEMBER = "member",
}

export enum Status {
  PENDING = "pending",
  APPROVED = "approved",
  REJECT = "reject",
}

export enum ContactStatus {
  PENDING = "pending",
  RESOLVED = "resolved",
  REJECTED = "rejected",
}
