import { IsSocialLink } from "./is-social-link.validator";
import { IsTrue } from "./is-true.validator";
import { IsUnique } from "./unique.validator";

export { IsSocialLink, IsTrue, IsUnique };
