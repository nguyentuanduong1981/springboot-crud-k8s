import {
  registerDecorator,
  ValidationArguments,
  ValidationOptions,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from "class-validator";

@ValidatorConstraint({ async: true })
class IsTrueConstraint implements ValidatorConstraintInterface {
  constructor() {}
  validate(value: any, _args: ValidationArguments) {
    return !!value;
  }

  defaultMessage(_validationArguments?: ValidationArguments): string {
    return "notification.error.validator.accepted";
  }
}

export function IsTrue(validationOptions?: ValidationOptions) {
  return (object: Object, propertyName: string) => {
    registerDecorator({
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      constraints: [],
      validator: IsTrueConstraint,
    });
  };
}
