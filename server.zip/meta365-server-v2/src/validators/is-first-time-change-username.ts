import { Injectable } from "@nestjs/common";
import {
  registerDecorator,
  ValidationArguments,
  ValidationOptions,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from "class-validator";
import { UserService } from "src/modules/user/user.service";

@ValidatorConstraint({ async: true })
@Injectable()
class IsFirstTimeChangeUsernameConstraint
  implements ValidatorConstraintInterface
{
  constructor(private readonly userService: UserService) {}
  validate(userName: any, _args: ValidationArguments) {
    return this.userService.getUserByInfo(userName).then((user) => {
      if (user) return false;
      return true;
    });
  }

  defaultMessage(_validationArguments?: ValidationArguments): string {
    return "notification.error.username_have_been_taken";
  }
}

export function IsFirstTimeChangeUsername(
  validationOptions?: ValidationOptions
) {
  return (object: Object, propertyName: string) => {
    registerDecorator({
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      constraints: [],
      validator: IsFirstTimeChangeUsernameConstraint,
    });
  };
}
