import {
  registerDecorator,
  ValidationArguments,
  ValidationOptions,
} from "class-validator";

export function IsSocialLink(validationOptions?: ValidationOptions) {
  return (object: any, propertyName: string) => {
    registerDecorator({
      name: "IsSocialLink",
      target: object.constructor,
      propertyName,
      constraints: [],
      options: validationOptions,
      validator: {
        validate(value: any, _args: ValidationArguments) {
          const pass = value
            .map((item) => item.key)
            .every((item) =>
              [
                "facebook",
                "zalo",
                "twitter",
                "medium",
                "linkedin",
                "telegram",
                "website",
                "youtube",
              ].includes(item)
            );
          if (!pass) return false;
          return true;
        },
        defaultMessage(_validationArguments?: ValidationArguments): string {
          return "notification.error.social_link_is_not_acceptable";
        },
      },
    });
  };
}
