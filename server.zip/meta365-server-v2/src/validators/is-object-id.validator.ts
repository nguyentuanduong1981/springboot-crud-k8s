import {
  registerDecorator,
  ValidationArguments,
  ValidationOptions,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from "class-validator";
import { Types } from "mongoose";
import errors from "src/commons/errors/errors.validator";

@ValidatorConstraint({ async: true })
class IsObjectIdConstraint implements ValidatorConstraintInterface {
  constructor() {}
  validate(value: any, _args: ValidationArguments) {
    return !!Types.ObjectId.isValid(value);
  }

  defaultMessage(_validationArguments?: ValidationArguments): string {
    return _validationArguments.constraints[0] || errors.ID_IS_INVALID;
  }
}

export function IsObjectId(
  errorMessage,
  validationOptions?: ValidationOptions
) {
  return (object: Object, propertyName: string) => {
    registerDecorator({
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      constraints: [errorMessage],
      validator: IsObjectIdConstraint,
    });
  };
}
