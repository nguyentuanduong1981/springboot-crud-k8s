import { Injectable } from "@nestjs/common";
import { getModelToken, InjectModel } from "@nestjs/mongoose";
import {
  registerDecorator,
  ValidationArguments,
  ValidationOptions,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from "class-validator";
import { ProjectService } from "src/modules/project/project.service";
import { UserService } from "src/modules/user/user.service";

@ValidatorConstraint({ async: true })
@Injectable()
export class IsUniqueConstraint implements ValidatorConstraintInterface {
  public schemas = {};
  public key: string;
  constructor(private readonly userService: UserService) {
    this.schemas["user"] = this.userService;
  }

  async validate(value: any, args: ValidationArguments) {
    let filter = {};
    filter[args.property] = value;
    return this.userService
      .getModel()
      .findOne(filter)
      .then((user) => {
        if (user) return false;
        return true;
      });
  }

  defaultMessage({ property }: ValidationArguments) {
    return `notification.error.${property}_have_been_taken`;
  }
}

export function IsUnique(model: string, validationOptions?: ValidationOptions) {
  return (object: Object, propertyName: string) => {
    registerDecorator({
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      constraints: [model],
      validator: IsUniqueConstraint,
    });
  };
}
