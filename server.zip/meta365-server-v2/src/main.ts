import { ConfigService } from "@nestjs/config";
import { HttpAdapterHost, NestFactory } from "@nestjs/core";
import { DocumentBuilder, SwaggerModule } from "@nestjs/swagger";
import { AppModule } from "./app.module";
import compression from "compression";
import { AllExceptionsFilter } from "./commons/errors/exception-filter";
import helmet from "helmet";
import { version, name, description } from "../package.json";
import { useContainer } from "class-validator";
import { Cluster } from "./cluster";

async function bootstrap() {
  const app = await NestFactory.create(AppModule, {
    logger: ["error", "warn", "debug", "log", "verbose"],
  });
  const { httpAdapter } = app.get(HttpAdapterHost);
  app.useGlobalFilters(new AllExceptionsFilter(httpAdapter));
  app.use(helmet());
  app.use(compression());
  app.setGlobalPrefix("api/v1", {
    exclude: ["/asset/:type/:id"],
  });
  // app.use(bodyParser.json({ limit: '50mb' }));
  // app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
  app.enableCors();

  // app.useGlobalPipes(
  //   validationRequestPipe
  // );
  // app.useWebSocketAdapter(new SocketAdapter(app));
  useContainer(app.select(AppModule), { fallbackOnErrors: true });
  const config = new DocumentBuilder()
    .setTitle(name || "Meta365")
    .setDescription(description || "Meta365 API")
    .setVersion(version || "1.0.0")
    .addBearerAuth()
    // .addApiKey({
    //   type: 'apiKey',
    //   in: 'headers',
    //   name: 'ApiVersion'
    // })
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup("docs", app, document);

  const configService: ConfigService = app.get(ConfigService);

  await app.listen(configService.get<string>("APP_PORT"));
  console.info(
    "Server:",
    `http://localhost:${configService.get<string>("APP_PORT")}`
  );
  console.info(
    "Documentation:",
    `http://localhost:${configService.get<string>("APP_PORT")}/docs`
  );
}

Cluster.register(2, bootstrap);
