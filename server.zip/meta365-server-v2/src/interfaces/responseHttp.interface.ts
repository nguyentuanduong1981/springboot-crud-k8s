import { Pagination } from "src/commons/paginate";

export interface ResponseCommon {
  message?: string;
  data?: unknown;
  code?: number;
  error?: boolean;
}

export interface ResponsePaginationCommon {
  message?: string;
  data?: Pagination<any>;
  code?: number;
  error?: boolean;
}
