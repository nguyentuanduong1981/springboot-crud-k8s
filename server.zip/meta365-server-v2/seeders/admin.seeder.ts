import { Command, Positional, Option } from 'nestjs-command';
import { Injectable } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import BaseSeeder from './base.seeder';

@Injectable()
export default class extends BaseSeeder {

  @Command({
    command: 'admin <username>',
    describe: 'create an admin',
  })
  async create(
    @Positional({
      name: 'username',
      describe: 'the username',
      type: 'string'
    })
    username: string,

    @Option({
      name: 'password',
      describe: 'password',
      type: 'string',
      default: '12345678Aa@',
      required: false
    })
    password: string,


  ) {
    const hashedPassword = await bcrypt.hash(password, 10)

    await this._create('admin', {
      username,
      password: hashedPassword
    })
  }
}
