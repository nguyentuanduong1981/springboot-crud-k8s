import { Command, Positional, Option } from 'nestjs-command';
import { Injectable } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import BaseSeeder from './base.seeder';

@Injectable()
export default class extends BaseSeeder {

  @Command({
    command: 'user <phoneNumber>',
    describe: 'create a user',
  })
  async create(
    @Positional({
      name: 'phoneNumber',
      describe: 'the username',
      type: 'string'
    })
    phoneNumber: string,
    @Option({
      name: 'fullname',
      describe: 'name of user (ex: "jedi")',
      type: 'string',
      alias: 'n',
      required: false
    })
    fullname: string,
    @Option({
      name: 'password',
      describe: 'password',
      type: 'string',
      default: '12345678Aa@',
      required: false
    })
    password: string
  ) {
    const hashedPassword = await bcrypt.hash(password, 10)

    await this._create('user', {
      phoneNumber,
      fullname,
      password: hashedPassword        
    })
  }
}
