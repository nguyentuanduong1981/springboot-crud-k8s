import { Injectable } from '@nestjs/common';
import mongoose, { Schema } from 'mongoose';
import { UserSchema } from 'src/schemas/user.schema';
import { ProjectSchema } from 'src/schemas/project.schema';
import { ConfigService } from '@nestjs/config';
import { AdminSchema } from 'src/schemas/admin.schema';

const schemaMap = {
  'user': UserSchema,
  'admin': AdminSchema,
  'project': ProjectSchema
}


@Injectable()
export default class BaseSeeder {
  mongo: typeof mongoose;
  model: typeof mongoose.Model;
  instances: Object
  constructor(private readonly config: ConfigService) {
    this.instances = {}
  }
  getSchema(className: string): Schema {
    let SchemaClass = schemaMap[className]
    if (!SchemaClass) {
      throw new Error('Invalid store class name: ' + className)
    }

    let schemaInstance: Schema = this.instances[className]
    if (!schemaInstance) {
      schemaInstance = SchemaClass
      this.instances[className] = schemaInstance
    }


    return schemaInstance
  }

  /**
   * Connect to mongodb implementation
   * @return {Promise}
   */
  connect = async () => {
    this.mongo = await mongoose.connect(this.config.get('MONGODB_URI'))
  }

  async _create(schema: string, data) {
    try {
      await this.connect()
      const model = this.mongo.model(schema, this.getSchema(schema))

      await model.create(data)
    } catch (error) {
      console.log(error)
    }
  }

  async _createMany(schema: string, data: Array<Object>) {
    try {
      await this.connect()
      const model = this.mongo.model(schema, this.getSchema(schema))
      await model.insertMany(data)
    } catch (error) {
      console.log(error)
    }
  }
}
