import { Command } from 'nestjs-command';
import { Injectable } from '@nestjs/common';
import BaseSeeder from './base.seeder';
import { ProjectSchema } from 'src/schemas/project.schema';
const data = [
  {
    "name": "PHOENIX LEGEND HA LONG",
    "description": "description",
    "location": {
      "province": 0,
      "district": 0,
      "village": 0
    },
    "coordinates": {
      "latitude": 0,
      "longitude": 0
    },

    "totalArea": 123,
    "detailLocation": "Ha Long - Quang Ninh",
    "totalInvestment": 997,
    "developmentUnit": "Hung Vuong",
    "investor": "Hung Vuong",
    "images": ["https://api.meta365.ai/static/phoenixhalong1-1642738966703.jpg"],
    "author": "61ea2cb5d8a55751c0e1682a",
    "media": "https://bds.vr360plus.vn/projects/phoenix-legend-ha-long/",
    "status": "private",
    "phase": "open_for_sale",
    "__v": 0
  },
  {
    "name": "BINH SON OCEAN PARK",
    "description": "description",
    "location": {
      "province": 0,
      "district": 0,
      "village": 0
    },
    "coordinates": {
      "latitude": 0,
      "longitude": 0
    },

    "totalArea": 1000,
    "detailLocation": "Phan Rang Thap Cham - Ninh Thuan",
    "totalInvestment": 1000,
    "developmentUnit": "Hung Vuong",
    "investor": "Cong Ty CP Dau TU Hacom Holdings",
    "images": ["https://api.meta365.ai/static/binh son-1642739745454.png"],
    "author": "61ea2cb5d8a55751c0e1682a",
    "media": "https://bds.vr360plus.vn/projects/binh-son-ocean-park/",
    "status": "public",
    "phase": "open_for_sale",
    "__v": 0
  },
  {
    "name": "NOVA WORLD HO TRAM",
    "description": "description",
    "location": {
      "province": 0,
      "district": 0,
      "village": 0
    },
    "coordinates": {
      "latitude": 0,
      "longitude": 0
    },

    "totalArea": 141,
    "detailLocation": "Ba Ria - Vung Tau",
    "totalInvestment": 10000,
    "developmentUnit": "Hung Vuong",
    "investor": "Nova Land",
    "images": ["https://api.meta365.ai/static/ezgif.com-gif-maker (1)-1642745574399.jpg"],
    "author": "61ea2cb5d8a55751c0e1682a",
    "media": "https://bds.vr360plus.vn/projects/nova-world-ho-tram/",
    "status": "public",
    "phase": "open_for_sale",
    "__v": 0
  },
  {
    "name": "TMS HOMES WONDER WORLD",
    "description": "description",
    "location": {
      "province": 0,
      "district": 0,
      "village": 0
    },
    "coordinates": {
      "latitude": 0,
      "longitude": 0
    },

    "totalArea": 13000,
    "detailLocation": "Bac Ha Noi",
    "totalInvestment": 13000,
    "developmentUnit": "HUNG VUONG",
    "investor": "TMS GROUP",
    "images": ["https://api.meta365.ai/static/tms-homes-wonder-world-1642745739720.png"],
    "author": "61ea2cb5d8a55751c0e1682a",
    "media": "https://bds.vr360plus.vn/projects/tms-homes-wonder-world/",
    "status": "public",
    "phase": "open_for_sale",
    "__v": 0
  },
  {
    "name": "SUN MARINA TOWN",
    "description": "description",
    "location": {
      "province": 0,
      "district": 0,
      "village": 0
    },
    "coordinates": {
      "latitude": 0,
      "longitude": 0
    },

    "totalArea": 997,
    "detailLocation": "Ha Long - Quang Ninh",
    "totalInvestment": 1000,
    "developmentUnit": "Hung Vuong",
    "investor": "Sun Group",
    "images": ["https://api.meta365.ai/static/sun-maria-town-1642746035488.png"],
    "author": "61ea2cb5d8a55751c0e1682a",
    "media": "https://bds.vr360plus.vn/projects/tour360/sun-marina-town-ver2/",
    "status": "public",
    "phase": "open_for_sale",
    "__v": 0
  },
  {
    "name": "SOL LAKE VILLAS",
    "description": "description",
    "location": {
      "province": 0,
      "district": 0,
      "village": 0
    },
    "coordinates": {
      "latitude": 0,
      "longitude": 0
    },

    "totalArea": 10000,
    "detailLocation": "Ha Dong - Ha Noi",
    "totalInvestment": 10000,
    "developmentUnit": "Hung Vuong",
    "investor": "Hung Vuong",
    "images": ["https://api.meta365.ai/static/soll-lake-villas-1642746304381.png"],
    "author": "61ea2cb5d8a55751c0e1682a",
    "media": "https://bds.vr360plus.vn/projects/sol-lake-villa-ver2/",
    "status": "public",
    "phase": "open_for_sale",
    "__v": 0
  },
  {
    "name": "NOVA WORLD PHAN THIET",
    "description": "description",
    "location": {
      "province": 0,
      "district": 0,
      "village": 0
    },
    "coordinates": {
      "latitude": 0,
      "longitude": 0
    },

    "totalArea": 9997,
    "detailLocation": "Phan Thiet - Binh Thuan",
    "totalInvestment": 9997,
    "developmentUnit": "Hung Vuong",
    "investor": "Nova land",
    "images": ["https://api.meta365.ai/static/nova-world-phan-thiet-1642746460767.png"],
    "author": "61ea2cb5d8a55751c0e1682a",
    "media": "https://bds.vr360plus.vn/projects/tour360/novaworld-ver3/",
    "status": "private",
    "phase": "open_for_sale",
    "__v": 0
  },
  {
    "name": "NOVA WORLD PHAN THIET",
    "description": "description",
    "location": {
      "province": 0,
      "district": 0,
      "village": 0
    },
    "coordinates": {
      "latitude": 0,
      "longitude": 0
    },

    "totalArea": 9997,
    "detailLocation": "Phan Thiet - Binh Thuan",
    "totalInvestment": 9997,
    "developmentUnit": "Hung Vuong",
    "investor": "Nova land",
    "images": ["https://api.meta365.ai/static/nova-world-phan-thiet-1642746460767.png"],
    "author": "61ea2cb5d8a55751c0e1682a",
    "media": "https://bds.vr360plus.vn/projects/tour360/novaworld-ver3/",
    "status": "public",
    "phase": "open_for_sale",
    "__v": 0
  },
  {
    "name": "ECO CENTER SHOP",
    "description": "description",
    "location": {
      "province": 0,
      "district": 0,
      "village": 0
    },
    "coordinates": {
      "latitude": 0,
      "longitude": 0
    },

    "totalArea": 1000,
    "detailLocation": "PHU MY - BINH DUONG - BINH PHUOC",
    "totalInvestment": 1000,
    "developmentUnit": "Hung Vuong",
    "investor": "Hung Vuong",
    "images": ["https://api.meta365.ai/static/eco-shop-center-1642747139151.png"],
    "author": "61ea2cb5d8a55751c0e1682a",
    "media": "https://bds.vr360plus.vn/projects/ecoshopcenter/",
    "status": "public",
    "phase": "open_for_sale",
    "__v": 0
  },
  {
    "name": "Thanh Đo Smart City",
    "description": "description",
    "location": {
      "province": 0,
      "district": 0,
      "village": 0
    },
    "coordinates": {
      "latitude": 0,
      "longitude": 0
    },

    "totalArea": 1000,
    "detailLocation": "Ba Ria - Vung Tau",
    "totalInvestment": 1000,
    "developmentUnit": "Hung Vuong",
    "investor": "Hung Vuong",
    "images": ["https://api.meta365.ai/static/thanh-do-smart-city-1642747280436.png"],
    "author": "61ea2cb5d8a55751c0e1682a",
    "media": "https://bds.vr360plus.vn/projects/smartcity360/",
    "status": "private",
    "phase": "open_for_sale",
    "__v": 0
  },
  {
    "name": "THE FUSION",
    "description": "description",
    "location": {
      "province": 0,
      "district": 0,
      "village": 0
    },
    "coordinates": {
      "latitude": 0,
      "longitude": 0
    },

    "totalArea": 19000,
    "detailLocation": "BA RIA - VUNG TAU",
    "totalInvestment": 19000,
    "developmentUnit": "Hung Vuong",
    "investor": "Hung Vuong",
    "images": ["https://api.meta365.ai/static/the-fusion-1642747358832.png"],
    "author": "61ea2cb5d8a55751c0e1682a",
    "media": "https://bds.vr360plus.vn/projects/the-fusion-ver2/",
    "status": "public",
    "phase": "open_for_sale",
    "__v": 0
  },
  {
    "name": "\u001dPHU MY FUTURE CITY",
    "description": "description",
    "location": {
      "province": 0,
      "district": 0,
      "village": 0
    },
    "coordinates": {
      "latitude": 0,
      "longitude": 0
    },

    "totalArea": 1000,
    "detailLocation": "PHU MY - BINH DUONG - BINH PHUOC",
    "totalInvestment": 1000,
    "developmentUnit": "Hung Vuong",
    "investor": "Hung Vuong",
    "images": ["https://api.meta365.ai/static/phu-my-future-city-1642747455764.png"],
    "author": "61ea2cb5d8a55751c0e1682a",
    "media": "https://bds.vr360plus.vn/projects/phu-my-futurecity/",
    "status": "public",
    "phase": "open_for_sale",
    "__v": 0
  },
  {
    "name": "HO TRAM ECO VILLAS",
    "description": "description",
    "location": {
      "province": 0,
      "district": 0,
      "village": 0
    },
    "coordinates": {
      "latitude": 0,
      "longitude": 0
    },

    "totalArea": 1000,
    "detailLocation": "BA RIA - VUNG TAU",
    "totalInvestment": 1000,
    "developmentUnit": "HUNG VUONG",
    "investor": "HUNG VUONG",
    "images": ["https://api.meta365.ai/static/ho-tram-eco-villas-1642747570959.png"],
    "author": "61ea2cb5d8a55751c0e1682a",
    "media": "https://bds.vr360plus.vn/projects/hotramecovillas360vr/",
    "status": "public",
    "phase": "open_for_sale",
    "__v": 0
  },
  {
    "name": "CAM LAM SKY LAKE",
    "description": "description",
    "location": {
      "province": 0,
      "district": 0,
      "village": 0
    },
    "coordinates": {
      "latitude": 0,
      "longitude": 0
    },

    "totalArea": 998,
    "detailLocation": "Cam Lam - Nha Trang - Khanh Hoa",
    "totalInvestment": 1000,
    "developmentUnit": "Hung Vuong",
    "investor": "Hung Vuong",
    "images": ["https://api.meta365.ai/static/ezgif.com-gif-maker (1)-1642747944232.png"],
    "author": "61ea2cb5d8a55751c0e1682a",
    "media": "https://bds.vr360plus.vn/projects/tour360/camlamskylake2/",
    "status": "private",
    "phase": "open_for_sale",
    "__v": 0
  },
  {
    "name": "DIAMOND CENTRE POINT",
    "description": "description",
    "location": {
      "province": 0,
      "district": 0,
      "village": 0
    },
    "coordinates": {
      "latitude": 0,
      "longitude": 0
    },

    "totalArea": 1000,
    "detailLocation": "PHU RIENG - BINH PHUOC",
    "totalInvestment": 1000,
    "developmentUnit": "Hung Vuong",
    "investor": "Hung Vuong",
    "images": ["https://api.meta365.ai/static/diamond-center-point-1642748132087.png"],
    "author": "61ea2cb5d8a55751c0e1682a",
    "media": "https://bds.vr360plus.vn/projects/diamond-centre-point/",
    "status": "public",
    "phase": "open_for_sale",
    "__v": 0
  },
  {
    "name": "Đình mông phụ - Làng Đường Lâm",
    "description": "description",
    "location": {
      "province": 0,
      "district": 0,
      "village": 0
    },
    "coordinates": {
      "latitude": 0,
      "longitude": 0
    },

    "totalArea": 10,
    "detailLocation": "Đường Lâm, Sơn Tây, Hà Nội",
    "totalInvestment": 6,
    "developmentUnit": "meta365",
    "investor": "meta365",
    "images": ["https://api.meta365.ai/static/dinhmongphulangduonglam-1646046973952.jpg"],
    "author": "61ea2cb5d8a55751c0e1682a",
    "media": "https://travel.meta365.ai/projects/son-tay/dinh-mong-phu-lang-duong-lam/",
    "status": "public",
    "phase": "open_for_sale",
    "__v": 0
  },
  {
    "name": "Đình Phùng Hưng",
    "description": "description",
    "location": {
      "province": 0,
      "district": 0,
      "village": 0
    },
    "coordinates": {
      "latitude": 0,
      "longitude": 0
    },

    "totalArea": 10,
    "detailLocation": "Đường Lâm, Sơn Tây, Hà Nội",
    "totalInvestment": 10,
    "developmentUnit": "meta365",
    "investor": "meta365",
    "images": ["https://api.meta365.ai/static/dinhphunghung-1646047241939.jpg"],
    "author": "61ea2cb5d8a55751c0e1682a",
    "media": "https://travel.meta365.ai/projects/son-tay/dinh-phung-hung/",
    "status": "private",
    "phase": "open_for_sale",
    "__v": 0
  },
  {
    "name": "Lăng Ngô Quyền",
    "description": "description",
    "location": {
      "province": 0,
      "district": 0,
      "village": 0
    },
    "coordinates": {
      "latitude": 0,
      "longitude": 0
    },

    "totalArea": 1,
    "detailLocation": "Đường Lâm, Sơn Tây, Hà Nội",
    "totalInvestment": 1,
    "developmentUnit": "1",
    "investor": "meta365",
    "images": ["https://api.meta365.ai/static/langngoquyen-1646047384648.jpg"],
    "author": "61ea2cb5d8a55751c0e1682a",
    "media": "https://travel.meta365.ai/projects/son-tay/lang-ngo-quyen/",
    "status": "public",
    "phase": "open_for_sale",
    "__v": 0
  },
  {
    "name": "Chùa Mía",
    "description": "description",
    "location": {
      "province": 0,
      "district": 0,
      "village": 0
    },
    "coordinates": {
      "latitude": 0,
      "longitude": 0
    },

    "totalArea": 1,
    "detailLocation": "Sơn Tây, Hà Nội",
    "totalInvestment": 1,
    "developmentUnit": "meta365",
    "investor": "meta365",
    "images": ["https://api.meta365.ai/static/chuamia-1646047500259.jpg"],
    "author": "61ea2cb5d8a55751c0e1682a",
    "media": "https://travel.meta365.ai/projects/son-tay/chua-mia/",
    "status": "public",
    "phase": "open_for_sale",
    "__v": 0
  },
  {
    "name": "Văn Miếu Sơn Tây",
    "description": "description",
    "location": {
      "province": 0,
      "district": 0,
      "village": 0
    },
    "coordinates": {
      "latitude": 0,
      "longitude": 0
    },

    "totalArea": -3,
    "detailLocation": "Sơn Tây, Hà Nội",
    "totalInvestment": 1,
    "developmentUnit": "meta365",
    "investor": "meta365",
    "images": ["https://api.meta365.ai/static/vanmieusontay-1646047623222.jpg"],
    "author": "61ea2cb5d8a55751c0e1682a",
    "media": "https://travel.meta365.ai/projects/son-tay/van-mieu-son-tay/",
    "status": "public",
    "phase": "open_for_sale",
    "__v": 0
  }
]
@Injectable()
export default class extends BaseSeeder {

  @Command({
    command: 'project',
    describe: 'create a project',
  })
  async create () {
    await this._createMany('project', data)
  }
}