module.exports = {
  apps: [
    {
      "name": "Meta365 Backend",
      "script": "dist/src/main.js",
      "instance": "max",
      "exec_mode": "cluster"
    }
  ]
}