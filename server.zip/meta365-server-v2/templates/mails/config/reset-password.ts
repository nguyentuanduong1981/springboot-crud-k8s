export const resetPassword = {
  reset: {
    label: "Reset password",
    link: "{{ url }}"
  },
  email: "{{ user.email }}",
  unsubscribe: "hihi"
}
