export const welcome = {
  sections: [
    {
      welcome: true,
      type: "welcome",
      title: "Welcome to Stream, your bespoke Ai service.",
      content: "Powered by global insights and analytics from thousands of sources, Stream helps you to make empowered decisions and build your personal brand.",
      image: {
        link: "",
        alt: "Notion Services"
      }
    },
    {
      features: true,
      type: "key-features",
      title: "Key features",
      items: [
        {
          title: "Create your first workspace to pin articles",
          content: "You can save articles to read them later or share with your colleagues by pinning them to your workspace.",
          indicator: "workspace",
          image: {
            link: "http://cdn.mcauto-images-production.sendgrid.net/978a94ce14e93a33/3aaf0e0f-c58a-4081-81b5-bf651eeb5725/652x1267.png",
            alt: "Create your first workspace to pin articles"
          }
        },
        {
          title: "Share articles with your colleagues",
          content: "Share articles to social media, to your email, to your colleagues via workspaces, even to people not using Stream.",
          indicator: "articles",
          image: {
            link: "http://cdn.mcauto-images-production.sendgrid.net/978a94ce14e93a33/b0fb1078-0209-4f74-8094-ec5facd70d96/375x414.png",
            alt: "Share articles with your colleagues"
          }
        },
        {
          title: "Setup your first interest to track important concepts",
          content: "Interests help you to track topics that are important to you, providing you with the latest global articles..",
          indicator: "interest",
          image: {
            link: "http://cdn.mcauto-images-production.sendgrid.net/978a94ce14e93a33/5791d707-1d41-40e1-a5ed-f71086463843/624x1294.png",
            alt: "Setup your first interest to track important concepts"
          }
        }
      ],
      link: "{{ link }}"
    }
  ]
}