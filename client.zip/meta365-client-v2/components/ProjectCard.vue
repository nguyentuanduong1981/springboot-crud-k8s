<template lang="pug">
.project-card(
  shadow="always"
)
  .meta
    .photo(v-image="medias[0]")
  .info

    h1.flex-between
      nuxt-link(
        :to="to || { name: 'project-id', params: { id: project._id } }"
      ) {{ project.name }}
      el-dropdown(
        trigger="click"
        size="medium"
      )
        //- :hide-on-click="false"
        span.el-dropdown-link
          more-vertical-icon(size="20")
        el-dropdown-menu(
          slot="dropdown"
        )
          el-dropdown-item.flex-center-y(
            @click.stop.native="onClickDeleteLink"
          )
            trash-icon.mr-4(size="20")
            | {{ $t('components.project_card.delete_project') }}
          //- el-dropdown-item.flex-center-y(
          //-     v-clipboard:copy="sharing.url"
          //-   v-clipboard:success="clipboardSuccess"
          //- )
          //-   CopyIcon.mr-4(size="20")
          //-   | {{ $t('common.copy_link') }}
    .description(
     v-html="project.description"
    )
    nuxt-link.category(
      v-if="project.type"
      :to="{ name: 'project', query: { type: project.type } }"
    ) {{ project.type }}
    .action.flex-center-y
      el-button(
        size="small"
      ) {{ $t('components.project_card.view_vr') }}
      nuxt-link(
        :to="{ name: 'project-id', params: { id: project._id } }"
      ) {{ $t('components.project_card.view_project') }}
</template>

<script>
import { TrashIcon, MoreVerticalIcon } from 'vue-feather-icons'
import { parseImage } from '@/utilities/helpers'

export default {
  name: 'ProjectCard',

  components: {
    TrashIcon,
    MoreVerticalIcon
  },

  props: {
    project: {
      type: Object,
      default: () => ({})
    },

    to: {
      type: Object,
      default: () => ({})
    }
  },

  computed: {
    medias () {
      return this.project?.images.map(item => {
        return parseImage(item)
      })
    }
  },

  methods: {
    onClickDeleteLink () {
      this.$confirm(this.$t('notification.do_you_want_to_delete_this_project'), 'Warning', {
        confirmButtonText: this.$t('common.confirm'),
        cancelButtonText: this.$t('common.cancel'),
        type: 'warning'
      }).then(() => {
        this.$emit('delete')
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.project-card {
  display: flex;
  flex-direction: column;
  border: 1px solid var(--color-shade-2);
  background: var(--color-shade-0);
  line-height: 1.4;
  font-family: sans-serif;
  border-radius: 5px;
  overflow: hidden;
  z-index: 0;
  a {
    color: inherit;
    &:hover {
      color: var(--color-primary-7);
    }
  }
  &:hover {
    .photo {
      transform: scale(1.3);
    }
  }
  .meta {
    position: relative;
    z-index: 0;
    height: 200px;
  }
  .photo {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background-size: cover;
    background-position: center;
    transition: transform .2s;
  }
  .details,
  .details ul {
    margin: auto;
    padding: 0;
    list-style: none;
  }

  .details {
    position: absolute;
    top: 0;
    bottom: 0;
    left: -100%;
    margin: auto;
    transition: left .2s;
    background: var(--color-shade-6);
    color: var(--color-shade-0);
    padding: 10px;
    width: 100%;
    font-size: .9rem;
    a {
      text-decoration: dotted underline
    }
    ul li {
      display: inline-block;
    }
    .author:before {
      font-family: FontAwesome;
      margin-right: 10px;
      content: "\f007";
    }

    .date:before {
      font-family: FontAwesome;
      margin-right: 10px;
      content: "\f133";
    }

    .tags {
      ul:before {
        margin-right: 10px;
      }
      li {
        margin-right: 2px;
        &:first-child {
          margin-left: -4px;
        }
      }
    }
  }
  .info {
    padding: 1rem;
    background: var(--color-shade-0);
    position: relative;
    z-index: 1;
    h1 {
      line-height: 34px;
      margin: 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      a {
        font-size: 1.7rem;
        @include text-ellipsis(2);
      }
    }
    a {
      text-decoration: none;
    }
    .description {
      @include text-ellipsis(5);
      text-align: justify;
      &::first-letter {
        margin-left: 10px;
      }
    }
    .category {
      margin-top: 10px;
      cursor: pointer;
      display: inline-block;
      background: var(--color-warning-5);
      color: var(--color-shade-1);
      border-radius: 3px 0 0 3px;
      line-height: 20px;
      padding: 1px 9px;
      position: relative;
      margin-right: 20px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
      text-decoration: none;
      height: 22px;
      &::after {
        content: "";
        position: absolute;
        border-bottom: 12px solid transparent;
        border-left: 10px solid var(--color-warning-5);
        border-top: 12px solid transparent;
        right: -10px;
        top: 0;
      }
    }
    .action {
      margin-top: 10px;
      justify-content: space-between;
      a {
        color: $--color-brand;
        display: inline-block;
        position: relative;
        &:after {
          margin-left: -10px;
          opacity: 0;
          vertical-align: middle;
          transition: margin .3s, opacity .3s;
        }

        &:hover:after {
          margin-left: 5px;
          opacity: 1;
        }
      }
    }
  }
  p {
    position: relative;
    margin: 1rem 0 0;
    &:first-of-type {
      padding-top: 1.25rem;
      margin-top: 0;
      &:before {
        content: "";
        position: absolute;
        height: 5px;
        background: var(--color-primary-7);
        width: 35px;
        top: 0.5rem;
        border-radius: 3px;
      }
    }
  }
  &:hover {
    .details {
      left: 0%;
    }
  }

  @include media(mobile-up) {
    flex-direction: row;
    max-width: 678px;
    .meta {
      flex-basis: 40%;
      height: auto;
    }
    .info {
      flex-basis: 60%;
    }
    &.alt {
      flex-direction: row-reverse;
      .info {
        &:before {
          left: inherit;
          right: -10px;
          transform: skew(3deg)
        }
      }
      .details {
        padding-left: 25px;
      }
    }
  }
}
</style>
