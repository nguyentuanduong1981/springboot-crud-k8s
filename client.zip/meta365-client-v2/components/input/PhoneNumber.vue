<template lang="pug">
.phone-input
  .custom-phone-number
    .select-country-container
      .country-selector
        .show-selector(:class="{ 'is-focus': visible }")
          .country-selector-flag
            country-flag(:country='countryCode' size='small')
          .calling-code.ellipsis {{ callingCode }}
          el-select(
            :disabled="true"
            :readonly="true"
            v-model="countryCode"
            popper-class="v2 el-select-phone-number-custom"
            @visible-change="clearQuery"
            @change="onChangeCode"
          )
            .search-country-phone-number
              .search-input
                el-input(
                  v-model.trim="query"
                  type="text"
                  :autofocus="true"
                )
            el-option(
              v-for="i in options"
              :key="i.keyCode"
              :value="i.keyCode"
              :label="i.label"
            )
              country-flag(:country='i.keyCode' size='small')
              span.ml-2 {{ i.label }}
    .elk-phone-input
      el-input(
        class="elk__input"
        ref="phoneNumber"
        type="text"
        :maxlength="maxlength"
        :value="phoneNumber.replace(callingCode, '')"
        @input="onPhoneNumberChange"
        :disabled="disabled"
        :readonly="readonly"
        :placeholder="placeholder"
      )
    span.phone-suffix
      slot(name="phone-suffix")
</template>

<script>
import { filter, toLower, trim, chain } from 'lodash'
import countryCodesList from 'country-codes-list'
import libPhoneNumberJs from 'libphonenumber-js'
import CountryFlag from 'vue-country-flag'

const COUNTRY_CODE_DEFAULT = 'VN'

export default {
  name: 'ElkVuePhoneNumberInput',

  components: {
    CountryFlag
  },

  props: {
    value: {
      type: String,
      default: ''
    },

    placeholder: {
      type: String,
      default: ''
    },

    defaultCountryCode: {
      type: String,
      default: ''
    },

    readonly: {
      type: Boolean,
      default: false
    },

    disabled: {
      type: Boolean,
      default: false
    },

    clearable: {
      type: Boolean,
      default: false
    },
    maxlength: {
      type: Number,
      default: 17
    }
  },

  data () {
    return {
      countryCode: COUNTRY_CODE_DEFAULT,
      phoneNumber: '',
      query: '',
      options: [],
      visible: false
    }
  },

  computed: {
    translations () {
      return {
        phoneNumberLabel: this.placeholder
      }
    },

    preferenceCallingCodes () {
      return countryCodesList.customList('countryCode', '+{countryCallingCode}')
    },

    allCountryCodes () {
      return chain(countryCodesList.all())
        .sortBy('countryNameEn')
        .map(i => {
          return {
            keyCode: i.countryCode,
            label: `+${i.countryCallingCode} ${i.countryNameEn}`
          }
        })
        .value()
    },

    callingCode () {
      return this.preferenceCallingCodes[this.countryCode] || this.preferenceCallingCodes[COUNTRY_CODE_DEFAULT]
    }
  },

  watch: {
    clearable (val) {
      if (val) {
        this.phoneNumber = ''
        this.$emit('clearable', false)
      }
    },

    query (newValue) {
      const standardQuery = trim(toLower(newValue))
      this.options = filter(this.allCountryCodes, item => {
        return toLower(item.label)
          .includes(standardQuery)
      })
    },

    defaultCountryCode (val) {
      if (val) {
        this.countryCode = val
      }
    },

    value (val) {
      if (this.readonly || this.disabled) {
        this.onPhoneNumberChange(val)
      }
    }
  },

  mounted () {
    this.initData()
  },

  methods: {
    initData () {
      this.$emit('updateCountryCode', this.countryCode)
      this.$emit('updateCallingCode', this.callingCode)
      this.options = this.allCountryCodes
      this.$nextTick(() => {
        this.onPhoneNumberChange(this.value)
      })
    },

    clearQuery (visible) {
      this.visible = visible
      if (visible) {
        this.query = ''
      }
    },

    onChangeCode () {
      this.clearQuery()

      this.$emit('updateCountryCode', this.countryCode)

      this.onPhoneNumberChange(this.phoneNumber)
    },

    onPhoneNumberChange (newValue) {
      // remove all, just keep number, character +
      newValue = `${newValue}`.replace(/[^0-9\u002B]+/g, '')
      if (newValue.length > 1) {
        newValue = `${newValue}`.replace(/^(?!00[^0])0/, '')
      }

      this.phoneNumber = newValue

      const standardPhoneNumber = libPhoneNumberJs(newValue, this.countryCode)
      if (!standardPhoneNumber) {
        const phoneNumber = newValue ? `${this.preferenceCallingCodes[this.countryCode]}${newValue}` : ''
        return this.$emit('input', phoneNumber)
      }
      this.$emit('updatePhoneNumberWithCode', standardPhoneNumber.number)
      this.$emit('input', standardPhoneNumber.nationalNumber)

      // const phoneNumberInfo = libPhoneNumberJs(standardPhoneNumber.number)
      // this.phoneNumber = phoneNumberInfo.formatNational()
    },

    focus (...args) {
      this.$refs.phoneNumber.focus(...args)
    }
  }
}
</script>

<style lang="scss" scoped>
::v-deep.phone-input {
  .custom-phone-number {
    position: relative;
    .select-country-container {
      position: absolute;
      .country-selector {
        font-size: $--size-base-xs;
        .country-selector-flag {
          position: absolute;
          top: 45%;
          left: 16px;
          transform: translate(0, -40%);
          z-index: 500;
          cursor: pointer;
          .flag {
            transform: scale(0.35);
          }
        }
        .show-selector {
          max-height: 40px;
          width: 120px;
          position: relative;
          background-color: transparent;
          .calling-code {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 500;
            max-width: 35px;
            cursor: pointer;
          }
          .el-select {
            z-index: 500;
            > .el-input {
              &.el-input--suffix {
                max-height: 40px;
              }
              background-color: transparent;
              > .el-input__inner {
                opacity: 0;
                &::placeholder {
                  display: none !important;
                }
              }
            }
            .search-country {
              position: absolute;
              top: 0px;
              z-index: 500;
              .el-input__inner {
                color: #fff;
                border-radius: 4px;
                background-color: rgba(255, 255, 255, 0.12);
                border: 1.5px solid transparent;
                font-size: $--size-base;
                line-height: 1;
                font-weight: 400;
              }
            }
            .el-select__caret {
              font-weight: 900;
            }
          }
        }
      }
    }
    .elk-phone-input {
      max-height: 40px;
      margin-left: 2px;
      flex: 1;
      .el-input {
        input {
          &::placeholder {
            white-space: nowrap !important;
            overflow: hidden !important;
            text-overflow: ellipsis !important;
          }
          &[placeholder] {
            white-space: nowrap !important;
            overflow: hidden !important;
            text-overflow: ellipsis !important;
          }
        }
      }
      .el-input__inner {
        border-radius: 4px;
        font-weight: 500;
        padding-left: 115px;
      }
    }
    .phone-suffix {
      position: absolute;
      right: 10px;
      top: 0;
    }
  }
  @include media(mobile) {
    .show-selector {
      width: 100px!important;
      .calling-code {
        left: 55%!important;
        transform: translate(-55%, -50%)!important;
      }
      .el-select {
        width: 100px!important;
      }
    }
    .el-input__inner {
      padding-left: 100px!important;
    }
  }
}
</style>
