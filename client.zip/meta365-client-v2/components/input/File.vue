<template lang="pug">
input(
  :key="key"
  type="file"
  ref="file"
  @change.stop="loadImage($event)"
  :accept="accept"
)
</template>

<script>
import { File as Image } from '~/utilities/file'
export const FILE_ACCEPT = {
  AUDIOS: 'audio/mp3,audio/mpeg,audio/m4a,audio/x-m4a,audio/wav',
  IMAGES: 'image/jpg,image/jpeg,image/png',
  VIDEOS: 'video/mp4,video/webm,video/quicktime,video/qt,.mov',
  IMAGES_VIDEOS: 'image/jpg,image/jpeg,image/png,image/gif,video/mp4,video/webm,video/quicktime,video/qt,.mov',
  ALL: 'image/jpg,image/jpeg,image/png,image/gif,video/mp4,video/webm,.mp3,video/quicktime,video/qt,.mov'
}
const MAXIMUM_SIZE = 10
export default {
  name: 'InputImage',
  props: {
    accept: {
      type: String,
      default: FILE_ACCEPT.ALL
    },

    maximum: {
      type: Number,
      default: MAXIMUM_SIZE
    }
  },

  data () {
    return {
      key: 0,
      file: {
        src: null,
        type: 'image/png'
      },
    }
  },

  methods: {
    async loadImage(event) {
      const file = new Image(this.accept, { maximum: this.maximum, dimension: { width: 1200 } }, this)
      await file.handleUploadEvent(event)
        .then(image => {
          this.$emit('ready', image)
        })
        .catch((error) => {
          Promise.resolve(error)
        })
    }
  }
}
</script>
