<template lang="pug">
el-form-item(
  :prop="formField"
  :label="$t(`field.${field}`)"
  :class="{ 'is-disabled': disabled }"
  :error="$t(error, { field: $t(`field.${field}`) })"
)
  .input
    input-phone-number(
      v-if="phoneNumberType"
      v-model="data"
      :disabled="disabled"
      ref="defaultFocus"
      v-bind="$attrs"
      :placeholder="$t('field.phoneNumber')"
      @updateCountryCode="updateCountryCode"
      @updateCallingCode="updateCallingCode"
      @updatePhoneNumberWithCode="updatePhoneNumberWithCode"
    )
    el-input(
      v-else
      :type="type"
      v-model="data"
      v-bind="$attrs"
      :disabled="disabled"
      :placeholder="$t(`field.${field}`)"
    )
  .edit
    span(
      v-if="!editable"
      @click="$emit('editable', formField)"
    ) {{ $t('common.change') }}
    span(
      v-else
      @click="onClickCancelEditable"
    ) {{ $t('common.cancel') }}
  .action-button
    el-button(
      v-if="!disabled"
      size="small"
      type="primary"
      :loading="loading"
      @click="$emit('done', formField)"
    ) {{ $t('common.save') }}

  slot(
    name="error"
  )
</template>

<script>
export default {
  name: 'SettingInput',

  props: {
    formField: {
      type: String,
      required: true
    },

    error: {
      type: String,
      required: false,
    },

    type: {
      type: String,
      default: 'text'
    },

    field: {
      type: String,
      required: true
    },

    editable: {
      type: Boolean,
      default: false
    },

    loading: {
      type: Boolean,
      default: false
    },

    value: {
      type: [String, Number, Boolean],
      default: ''
    },
  },

  data () {
    return {
      country: '',
      callingCode: '',
      phoneNumberWithCode: null
    }
  },

  computed: {
    disabled () {
      return this.$attrs.disabled || !this.editable
    },
    data: {
      get () {
        return this.value
      },
      set (value) {
        this.$emit('input', value)
      }
    },

    phoneNumberType () {
      return ['phone'].includes(this.type)
    }
  },

  watch: {
    value (newValue) {
      this.$emit('input', newValue)
    }
  },

  methods: {
    onClickCancelEditable () {
      this.$emit('cancel', this.formField)
    },

    updateCallingCode (code) {
      this.callingCode = code
      this.$emit('updateCallingCode', code)
    },

    updateCountryCode (code) {
      this.country = code
    },

    updatePhoneNumberWithCode (phoneNumberWithCode) {
      this.$emit('updatePhoneNumberWithCode', phoneNumberWithCode)
      this.phoneNumberWithCode = phoneNumberWithCode
    },
  }
}
</script>

<style lang="scss" scoped>
::v-deep.el-form-item {
  margin-bottom: 44px;
  &.is-error {
  //   +.el-alert {
  //     display: flex;
  //   }
    .action-button {
      display: none;
    }
  }
  &.is-disabled {
    margin-bottom: 30px;
  }
  @include media(xs) {
    &.is-disabled {
      margin-bottom: 28px;
    }
    &.editable {
      margin-bottom: 44px;
    }
    .el-form-item__label {
      float: none;
      display: inline-block;
      text-align: left;
      padding: 0 0 4px;
      line-height: 20px;
    }
    .el-form-item__content {
      margin-left: 0!important;
    }
  }
  .input {
    flex: 1 1;
  }
  .edit {
    flex: 0 0 84px;
    text-align: right;
    @include media(xs) {
      flex: 0 0 74px;
      span {
        padding: 4px 2px 4px 4px;
      }
    }
    span {
      cursor: pointer;
      padding: 4px 6px;
      user-select: none;
      font-weight: 500;
    }
  }
  .action-button {
    color: #F56C6C;
    font-size: $--size-base-xs;
    line-height: 1;
    padding-top: 4px;
    position: absolute;
    top: 100%;
    left: 0;
  }
}
</style>
