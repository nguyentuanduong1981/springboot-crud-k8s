<template lang="pug">
canvas(ref="canvas")
</template>

<script>
import { debounce } from 'lodash'
const STROKE_COLORS = ['#3A75E866', '#166CF666']
const PRESETS = {
  o (x, y, s, dx, dy) {
    return {
      x,
      y,
      r: 12 * s,
      w: 5 * s,
      dx,
      dy,
      draw (ctx, t) {
        ctx.lineWidth = 1
        ctx.save();
        ctx.strokeStyle='rgba(0,0,0,0)';
        ctx.miterLimit=4;
        ctx.font="15px / 21.4286px ''";
        ctx.font="   15px ''";
        ctx.save();
        ctx.restore();
        ctx.save();
        ctx.fillStyle='rgba(0,0,0,0)';
        ctx.strokeStyle='rgba(0,0,0,0)';
        ctx.font="   15px ''";
        ctx.save();
        ctx.fillStyle='#166CF666';
        ctx.strokeStyle='rgba(0,0,0,0)';
        ctx.font="   15px ''";
        ctx.save();
        ctx.strokeStyle='rgba(0,0,0,0)';
        ctx.font="   15px ''";
        ctx.beginPath();
        ctx.moveTo(this.x + 12, this.y + 6);
        ctx.bezierCurveTo(this.x + 14.8884435, this.y + 6, this.x + 17.7796305, this.y + 6.35991157, this.x + 20.6723064, this.y + 7.07921311);
        ctx.bezierCurveTo(this.x + 21.4036605, this.y + 7.26107383, this.x + 21.9306439, this.y + 7.8881124, this.x + 21.9936599, this.y + 8.62811321);
        ctx.lineTo(this.x + 22, this.y + 8.7775211);
        ctx.lineTo(this.x + 22, this.y + 11.8716481);
        ctx.bezierCurveTo(this.x + 22, this.y + 14.0807462, this.x + 20.2634396, this.y + 15.8842489, this.x + 18.0809516, this.y + 15.9915236);
        ctx.lineTo(this.x + 17.8750763, this.y + 15.9965717);
        ctx.lineTo(this.x + 15.4047907, this.y + 15.9965717);
        ctx.bezierCurveTo(this.x + 14.6799917, this.y + 15.9965717, this.x + 13.9873392, this.y + 15.7105919, this.x + 13.4747786, this.y + 15.2055506);
        ctx.lineTo(this.x + 13.3395656, this.y + 15.0624311);
        ctx.lineTo(this.x + 12.6866359, this.y + 14.3198368);
        ctx.lineTo(this.x + 12.6036321, this.y + 14.2368479);
        ctx.bezierCurveTo(this.x + 12.2536443, this.y + 13.9292307, this.x + 11.7346352, this.y + 13.9372739, this.x + 11.394747, this.y + 14.238546);
        ctx.lineTo(this.x + 11.313708, this.y + 14.31996);
        ctx.lineTo(this.x + 10.6614486, this.y + 15.0620605);
        ctx.bezierCurveTo(this.x + 10.1828482, this.y + 15.6065824, this.x + 9.51058915, this.y + 15.9380632, this.x + 8.79270442, this.y + 15.9895286);
        ctx.lineTo(this.x + 8.59589768, this.y + 15.9965717);
        ctx.lineTo(this.x + 6.12537597, this.y + 15.9965717);
        ctx.bezierCurveTo(this.x + 3.91603562, this.y + 15.9965717, this.x + 2.11233515, this.y + 14.259821, this.x + 2.00504875, this.y + 12.0770936);
        ctx.lineTo(this.x + 2, this.y + 11.8711958);
        ctx.lineTo(this.x + 2, this.y + 8.77749488);
        ctx.bezierCurveTo(this.x + 2, this.y + 7.97365979, this.x + 2.54761134, this.y + 7.27319856, this.x + 3.32769572, this.y + 7.07921258);
        ctx.bezierCurveTo(this.x + 6.2203709, this.y + 6.35991139, this.x + 9.11155722, this.y + 6, this.x + 12, this.y + 6);
        ctx.closePath();
        ctx.moveTo(this.x + 12, this.y + 7.5);
        ctx.bezierCurveTo(this.x + 9.23458591, this.y + 7.5, this.x + 6.46489315, this.y + 7.84478718, this.x + 3.689674, this.y + 8.5348814);
        ctx.bezierCurveTo(this.x + 3.60051996, this.y + 8.55705161, this.x + 3.53262102, this.y + 8.62552885, this.x + 3.50902761, this.y + 8.71082755);
        ctx.lineTo(this.x + 3.5, this.y + 8.77749488);
        ctx.lineTo(this.x + 3.5, this.y + 11.8711958);
        ctx.bezierCurveTo(this.x + 3.5, this.y + 13.2653834, this.x + 4.58674266, this.y + 14.4057486, this.x + 5.95934306, this.y + 14.4914066);
        ctx.lineTo(this.x + 6.12537597, this.y + 14.4965717);
        ctx.lineTo(this.x + 8.59589768, this.y + 14.4965717);
        ctx.bezierCurveTo(this.x + 8.91044509, this.y + 14.4965717, this.x + 9.21166969, this.y + 14.3780783, this.x + 9.44104858, this.y + 14.1675687);
        ctx.lineTo(this.x + 9.53478447, this.y + 14.0717939);
        ctx.lineTo(this.x + 10.1870439, this.y + 13.3296934);
        ctx.bezierCurveTo(this.x + 11.067205, this.y + 12.3283005, this.x + 12.5925058, this.y + 12.2300227, this.x + 13.5938987, this.y + 13.1101838);
        ctx.lineTo(this.x + 13.7070326, this.y + 13.2162533);
        ctx.lineTo(this.x + 13.7070326, this.y + 13.2162533);
        ctx.lineTo(this.x + 13.8131224, this.y + 13.3293681);
        ctx.lineTo(this.x + 14.466052, this.y + 14.0719624);
        ctx.bezierCurveTo(this.x + 14.6737064, this.y + 14.3081332, this.x + 14.9615184, this.y + 14.4560966, this.x + 15.2709997, this.y + 14.4893973);
        ctx.lineTo(this.x + 15.4047907, this.y + 14.4965717);
        ctx.lineTo(this.x + 17.8750763, this.y + 14.4965717);
        ctx.bezierCurveTo(this.x + 19.2690237, this.y + 14.4965717, this.x + 20.4091925, this.y + 13.4100163, this.x + 20.4948358, this.y + 12.0376524);
        ctx.lineTo(this.x + 20.5, this.y + 11.8716481);
        ctx.lineTo(this.x + 20.5, this.y + 8.77747784);
        ctx.bezierCurveTo(this.x + 20.5, this.y + 8.66265772, this.x + 20.4217815, this.y + 8.56259627, this.x + 20.310335, this.y + 8.53488363);
        ctx.bezierCurveTo(this.x + 17.5351082, this.y + 7.84478735, this.x + 14.7654148, this.y + 7.5, this.x + 12, this.y + 7.5);
        ctx.closePath();
        ctx.moveTo(this.x + 16.7516748, this.y + 9.00000267);
        ctx.lineTo(this.x + 18.2516748, this.y + 9.00400267);
        ctx.bezierCurveTo(this.x + 18.6658869, this.y + 9.00510723, this.x + 19.0007767, this.y + 9.3417879, this.x + 18.999672, this.y + 9.75599999);
        ctx.bezierCurveTo(this.x + 18.9986596, this.y + 10.1356944, this.x + 18.7156699, this.y + 10.4487361, this.x + 18.3494632, this.y + 10.4974221);
        ctx.lineTo(this.x + 18.2476748, this.y + 10.5039973);
        ctx.lineTo(this.x + 16.7476748, this.y + 10.5000027);
        ctx.bezierCurveTo(this.x + 16.3334627, this.y + 10.4988928, this.x + 15.9985729, this.y + 10.1622121, this.x + 15.999672, this.y + 9.74800001);
        ctx.bezierCurveTo(this.x + 16.00069, this.y + 9.36830559, this.x + 16.2836796, this.y + 9.05526392, this.x + 16.6498863, this.y + 9.00657787);
        ctx.lineTo(this.x + 16.7516748, this.y + 9.00000267);
        ctx.closePath();
        ctx.moveTo(this.x + 7.25032521, this.y + 9);
        ctx.bezierCurveTo(this.x + 7.66453877, this.y + 9, this.x + 8.00032521, this.y + 9.33578644, this.x + 8.00032521, this.y + 9.75);
        ctx.bezierCurveTo(this.x + 8.00032521, this.y + 10.1296958, this.x + 7.71817133, this.y + 10.443491, this.x + 7.35209577, this.y + 10.4931534);
        ctx.lineTo(this.x + 7.25032521, this.y + 10.5);
        ctx.lineTo(this.x + 5.74707815, this.y + 10.5);
        ctx.bezierCurveTo(this.x + 5.33286458, this.y + 10.5, this.x + 4.99707815, this.y + 10.1642136, this.x + 4.99707815, this.y + 9.75);
        ctx.bezierCurveTo(this.x + 4.99707815, this.y + 9.37030423, this.x + 5.27923203, this.y + 9.05650904, this.x + 5.64530759, this.y + 9.00684662);
        ctx.lineTo(this.x + 5.74707815, this.y + 9);
        ctx.lineTo(this.x + 7.25032521, this.y + 9);
        ctx.closePath();
        ctx.moveTo(this.x + 12, this.y + 8.5);
        ctx.bezierCurveTo(this.x + 12.4142136, this.y + 8.5, this.x + 12.75, this.y + 8.83578644, this.x + 12.75, this.y + 9.25);
        ctx.bezierCurveTo(this.x + 12.75, this.y + 9.66421356, this.x + 12.4142136, this.y + 10, this.x + 12, this.y + 10);
        ctx.bezierCurveTo(this.x + 11.5857864, this.y + 10, this.x + 11.25, this.y + 9.66421356, this.x + 11.25, this.y + 9.25);
        ctx.bezierCurveTo(this.x + 11.25, this.y + 8.83578644, this.x + 11.5857864, this.y + 8.5, this.x + 12, this.y + 8.5);
        ctx.closePath();
        ctx.fill('nonzero');
        ctx.stroke();
        ctx.restore();
        ctx.restore();
        ctx.restore();
        ctx.restore();
      }
    }
  },
  star(x, y, dx, dy, dr, r, spikes) {
    return {
      x,
      y,
      dx,
      dy,
      dr,
      r,
      spikes,
      draw (ctx, t) {
        this.rot = Math.PI / 2 * 3
        this.x += this.dx
        this.y += this.dy
        this.r += this.dr
        this.step = Math.PI / this.spikes

        ctx.beginPath()
        const line = (x, y) => {
          x = x + Math.cos(this.rot) * 2
          y = y + Math.sin(this.rot) * 2
          ctx.lineTo(x, y)
          this.rot += this.step

          x = x + Math.cos(this.rot) * 4
          y = y + Math.sin(this.rot) * 4
          ctx.lineTo(x, y)
          this.rot += this.step
        }
        for (let i = 0; i < this.spikes; i++) {
          line(this.x + +Math.sin((50 + this.x + (t / 10)) / 100) * 3, this.y + +Math.sin((50 + this.x + (t / 10)) / 100) * 3)
        }
        ctx.closePath()
        ctx.save()
        ctx.translate(this.x + Math.sin(((t / 10)) / 100) * 5, this.y + Math.sin((10 + (t / 10)) / 100) * 2)
        ctx.rotate(this.r * Math.PI / 180)
        ctx.lineWidth = 2
        ctx.strokeStyle = STROKE_COLORS[1]
        ctx.stroke()
        ctx.fillStyle = ctx.isPointInPath(x, y) ? STROKE_COLORS[0] : STROKE_COLORS[1]
        ctx.fill()
        ctx.restore()
      }
    }
  },

  x (x, y, s, dx, dy, dr, r) {
    r = r || 0
    return {
      x,
      y,
      s: 20 * s,
      w: 5 * s,
      r,
      dx,
      dy,
      dr,
      draw (ctx, t) {
        this.x += this.dx
        this.y += this.dy
        this.r += this.dr
        const _this = this
        const line = (x, y, tx, ty, c, o) => {
          o = o || 0
          ctx.beginPath()
          ctx.moveTo(-o + ((_this.s / 2) * x), o + ((_this.s / 2) * y))
          ctx.lineTo(-o + ((_this.s / 2) * tx), o + ((_this.s / 2) * ty))
          ctx.lineWidth = _this.w
          ctx.strokeStyle = c
          ctx.stroke()
        }
        ctx.save()
        ctx.translate(this.x + Math.sin((x + (t / 10)) / 100) * 5, this.y + Math.sin((10 + x + (t / 10)) / 100) * 2)
        ctx.rotate(this.r * Math.PI / 180)
        line(-1, -1, 1, 1, STROKE_COLORS[1])
        line(1, -1, -1, 1, STROKE_COLORS[1])
        ctx.restore()
      }
    }
  }
}

export default {
  data () {
    return {
      elements: [],
      ticker: null,
      resizer: () => {}
    }
  },

  mounted () {
    this.$nextTick(this.init)
  },

  beforeDestroy () {
    window.removeEventListener('resize', this.resizer)
    if (this.ticker) clearInterval(this.ticker)
  },

  methods: {
    init () {
      this.resize()
      this.resizer = debounce(this.resize, 100)
      window.addEventListener('resize', this.resizer)
    },

    resize () {
      this.$refs.canvas.width = this.$refs.canvas.clientWidth
      this.$refs.canvas.height = this.$refs.canvas.clientHeight
      this.generate()
    },

    generate () {
      this.elements = []
      const canvas = this.$refs.canvas
      if (!canvas) return
      const ctx = canvas.getContext('2d')
      // add elements
      for (let x = 0; x < canvas.width; x++) {
        for (let y = 0; y < canvas.height; y++) {
          if (Math.round(Math.random() * 8000) === 1) {
            const s = ((Math.random() * 5) + 1) / 10
            if (Math.round(Math.random()) === 1)
              this.elements.push(PRESETS.o(x, y, s, 0, 0))
            else
              this.elements.push(PRESETS.star(x, y, 0, 0, ((Math.random() * 3) - 1) / 10, (Math.random() * 360), Math.floor(Math.random() * 5) + 4))
          }
        }
      }
      // tick
      if (this.ticker) clearInterval(this.ticker)
      this.ticker = setInterval(() => {
        ctx.clearRect(0, 0, canvas.width, canvas.height)
        const time = new Date().getTime()
        for (const e in this.elements)
          this.elements[e].draw(ctx, time)
      }, 10)
    }
  }
}
</script>

<style lang="scss" scoped>
@keyframes gradient {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}
canvas {
  z-index: -1;
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: $--color-page-background;
  // background: linear-gradient(-45deg, $--color-page-background, #18102E);
  // background-size: 400% 400%;
  // animation: gradient 10s ease infinite;
}
</style>
