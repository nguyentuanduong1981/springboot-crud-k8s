<template lang="pug">
el-tooltip(
  v-bind="$attrs"
  :effect="$colorMode.value === 'dark' ? 'dark' : 'light'"
)
  slot
</template>

<script>
export default {
  name: 'ElTooltipTheme',
}
</script>
