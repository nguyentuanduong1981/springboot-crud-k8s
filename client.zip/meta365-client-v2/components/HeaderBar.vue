<template lang="pug">
header.header-bar#header(:class="{ searching: inSearchMode, authenticated: user || false, light }")
  .intop
    .container.flex-center-y.flex-between
      .intop__left
        | {{ $t('pages.home.real_estate_decentralized_exchange') }}
      .intop__right
        nuxt-link(
          :to="{ name: 'for-real-estate-enterprises' }"
        ) {{ $t('pages.home.are_you_a_real_estate_enterprises') }}
        el-divider(
          direction="vertical"
        )
        nuxt-link(
          :to="{ name: 'for-real-estate-brokers' }"
        ) {{ $t('pages.home.are_you_a_real_estate_brokers') }}
  el-divider.m-0
  .frame.py-16(:class="{ 'mobile-full' : framed }")
    .flex.container
      .menu
        .logo
          nuxt-link(
            :to="{ name: 'index' }"
          )
            img.full(
              :src="`/logo-${logo}.svg`"
            )
            //- .beta-badge Beta
        component(
          v-for="i, k in pages"
          :is="i.external ? 'a' : 'nuxt-link'"
          :target="i.external ? '_blank' : '_self'"
          :key="k"
          :to="i.to"
          :href="i.to"
          v-if="i.visible"
        )
          component(
            :is="i.icon"
            size="18"
          )
          span(
            :class="{ 'highlight beta-badge': i.highlight }"
          ) {{ i.title }}

      .button.hidden-sm-and-down
        component.color-switcher(
          :is="$colorMode.value === 'light' ? 'SunIcon' : 'MoonIcon'"
          size="24"
          @click="$colorMode.preference = $colorMode.value === 'light' ? 'dark' : 'light'"
        )
      .cs-pointer.ml-10.translator.d-flex.hidden-sm-and-down
        el-select(
          v-model="language"
        )
          el-option(
            v-for="item in languages"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          )
      client-only
        .user.hidden-sm-and-down
          el-popover(
            popper-class="user-menu-dropdown"
            :popper-options="{ boundariesElement: 'body', gpuAcceleration: true }"
            placement="bottom-end"
            width="300"
            trigger="manual"
            v-model="userMenuVisible"
            v-if="user"
            v-click-outside="onHandleCloseUserMenu"
          )
            .button.mr-0(
              slot="reference"
              @click="userMenuVisible = !userMenuVisible"
            )
              .address {{ user.fullName || user.username || user.phoneNumber || user.publicAddress }}
              //-   align-right-icon
              .placeholder
                user-icon
            nav
              nuxt-link.avatar.flex-center-y(
                @click.native="onHandleCloseUserMenu"
                :to="{ name: '_user-profile', params: { username: user.username } }"
              )
                nuxt-img(
                  format="webp"
                  :src="avatar"
                )
                .profile.flex-column.ml-12
                  strong {{  user.fullName || user.username }}
                  span {{ $t('navigation.profile') }}
              el-divider.my-4
              //- nuxt-link(
              //-   v-if="user.agent"
              //-   :to="{ name: 'agent-id', params: { id: user.agent._id } }"
              //-   @click.native="onHandleCloseUserMenu"
              //- ) {{ user.agent.name }}
              //- a.flex-between(
              //-   v-else
              //-   @click="oncLickBecomeAnAgency"
              //- )
              //-   | {{ $t('navigation.become_an_agency') }}
              a.flex-between(
                v-if="user && user.userType === 'normal' && !user.agent"
                @click="onClickBecomeABroker"
              )
                | {{ $t('navigation.become_a_broker') }}
              a.flex-between(@click="activeSubNav = 0")
                | {{ $t('navigation.setting_and_privacy') }}
                ChevronRightIcon
              nav.sub-nav(
                :class="{ 'is-active': [0, 1].includes(activeSubNav) }"
              )
                a(@click="activeSubNav = -1")
                  ChevronLeftIcon
                  | {{ $t('common.back') }}
                component(
                  v-for="i in navbarDropdownOption[activeSubNav]"
                  :key="i.label"
                  :is="i.type"
                  @click.native="i.function"
                  @click="i.function"
                  :to="i.route"
                ) {{ $t(i.label) }}
              a(
                @click="onClickLogout"
              )
                | {{ $t('navigation.logout') }}

          el-button.login-button.text-bg-main.text-uppercase(
            v-else
            plain
            @click.native="login"
          )
            | {{ $t('navigation.login') }}
      menu-icon.hidden-md-and-up.menu-icon(@click="drawer = true")
      nuxt-link.logo.logo-mobile.hidden-md-and-up(
        :to="{ name: 'index' }"
      )
          .full
            img(
              :src="`/logo-${logo}.svg`"
            )
            //- .beta-badge Beta
      el-button.login-button.text-bg-main.hidden-md-and-up.text-uppercase(
        v-if="!user"
        plain
        @click.native="login"
      )
        | {{ $t('navigation.login') }}

  el-drawer(
    :visible.sync="drawer"
    size="300px"
    :modal-append-to-body="false"
  )
    template(slot="title")
      .user.d-flex
        .button(v-if="user")
          nuxt-link(
            :to="{ name: '_user-profile', params: { username: user.username } }"
            @click.native="drawer = false"
          )
            .address {{ user.fullName || user.username || user.phoneNumber || user.publicAddress }}

        //- .button.ml-6.text-white
        //-   .cs-pointer.translator(@click="onClickSwitchLocalePath()")
        //-     svg(xmlns="http://www.w3.org/2000/svg" fill="currentColor" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewbox="0 0 24 24" version="1.1")
        //-       path(d="M 6.816406 10.070312 L 6.164062 12 L 4.5 12 L 7.292969 4.5 L 9.21875 4.5 L 12 12 L 10.25 12 L 9.597656 10.070312 Z M 9.269531 8.96875 L 8.25 5.933594 L 8.175781 5.933594 L 7.15625 8.96875 Z M 9.269531 8.96875 ")
        //-       path(d="M 0 3 C 0 1.34375 1.34375 0 3 0 L 13.5 0 C 15.15625 0 16.5 1.34375 16.5 3 L 16.5 7.5 L 21 7.5 C 22.65625 7.5 24 8.84375 24 10.5 L 24 21 C 24 22.65625 22.65625 24 21 24 L 10.5 24 C 8.84375 24 7.5 22.65625 7.5 21 L 7.5 16.5 L 3 16.5 C 1.34375 16.5 0 15.15625 0 13.5 Z M 3 1.5 C 2.171875 1.5 1.5 2.171875 1.5 3 L 1.5 13.5 C 1.5 14.328125 2.171875 15 3 15 L 13.5 15 C 14.328125 15 15 14.328125 15 13.5 L 15 3 C 15 2.171875 14.328125 1.5 13.5 1.5 Z M 13.707031 16.492188 C 13.996094 16.945312 14.308594 17.367188 14.652344 17.761719 C 13.53125 18.625 12.140625 19.261719 10.5 19.699219 C 10.765625 20.023438 11.175781 20.652344 11.332031 21 C 13.019531 20.460938 14.453125 19.734375 15.660156 18.757812 C 16.828125 19.757812 18.269531 20.507812 20.054688 20.96875 C 20.257812 20.585938 20.675781 19.957031 21 19.632812 C 19.3125 19.253906 17.914062 18.589844 16.769531 17.707031 C 17.792969 16.585938 18.601562 15.230469 19.203125 13.570312 L 21 13.570312 L 21 12 L 16.5 12 L 16.5 13.570312 L 17.648438 13.570312 C 17.171875 14.835938 16.539062 15.890625 15.738281 16.765625 C 15.519531 16.53125 15.3125 16.285156 15.117188 16.027344 C 14.695312 16.300781 14.207031 16.457031 13.707031 16.492188 Z M 13.707031 16.492188 ")
        .button.ml-6
          component.color-switcher(
            :is="$colorMode.value === 'light' ? 'SunIcon' : 'MoonIcon'"
            size="24"
            @click="$colorMode.preference = $colorMode.value === 'light' ? 'dark' : 'light'"
          )
        .cs-pointer.translator.d-flex.ml-6
          el-select(
            v-model="language"
            popper-class="fit"
          )
            el-option(
              v-for="item in languages"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            )
    .menu-list
      component.menu-item(
        v-for="i in advanceMobileMenu"
        :key="i.title"
        :is="i.type"
        :to="i.to"
        @click="i.function"
        @click.native="i.function"
      ) {{ i.title }}
      component.menu-item(
        v-for="i in [...pages, ...mobilePage]"
        :key="i.title"
        :is="i.external ? 'a' : 'nuxt-link'"
        :target="i.external ? '_blank' : '_self'"
        :to="i.to"
        :href="i.to"
        v-if="i.visible"
        @click.native="drawer = false"
      )
        component(
          :is="i.icon"
          size="24"
        )
        span(
          :class="{ 'highlight beta-badge': i.highlight }"
        ) {{ i.title }}
      .menu-item(
        v-if="user && user.userType === 'normal' && !user.agent"
        @click="onClickBecomeABroker"
      )
        | {{ $t('navigation.become_a_broker') }}
      .menu-item.el-button--primary.el-button--medium.logout(
        v-if="user"
        :style="{ padding: '12px 20px' }"
        @click="onClickLogout"
      ) {{ $t('navigation.logout') }}

</template>

<script>
import {
  ZapIcon,
  SunIcon,
  HomeIcon,
  BellIcon,
  MoonIcon,
  UserIcon,
  PlusIcon,
  InfoIcon,
  BookIcon,
  FileIcon,
  GridIcon,
  MenuIcon,
  LogInIcon,
  UsersIcon,
  InboxIcon,
  LogOutIcon,
  Share2Icon,
  CalendarIcon,
  SettingsIcon,
  FileTextIcon,
  CrosshairIcon,
  AlignRightIcon,
  CreditCardIcon,
  ChevronDownIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  ShoppingCartIcon,
  MessageSquareIcon,
} from 'vue-feather-icons'
import { chain, isEmpty } from 'lodash'
import { mapState } from 'vuex'
import vClickOutside from 'v-click-outside'
import { generateAssetUrl, stringIsHttp } from '@/utilities/helpers'
import ResponsiveWebMixin from '~/mixins/responsive-web'

const MEDIUM_WIDTH_EL_LAYOUT = 992

export default {
  name: 'Header',

  components: {
    ZapIcon,
    SunIcon,
    HomeIcon,
    BellIcon,
    MoonIcon,
    UserIcon,
    PlusIcon,
    InfoIcon,
    BookIcon,
    FileIcon,
    GridIcon,
    MenuIcon,
    LogInIcon,
    UsersIcon,
    InboxIcon,
    LogOutIcon,
    Share2Icon,
    CalendarIcon,
    SettingsIcon,
    FileTextIcon,
    CrosshairIcon,
    AlignRightIcon,
    CreditCardIcon,
    ChevronDownIcon,
    ChevronLeftIcon,
    ChevronRightIcon,
    ShoppingCartIcon,
    MessageSquareIcon,
  },

  directives: {
    clickOutside: vClickOutside.directive
  },

  mixins: [ResponsiveWebMixin],

  props: {
    framed: {
      type: Boolean,
      default: false
    }
  },

  data () {
    return {
      userMenuVisible:false,
      inSearchMode: false,
      isLogoutSubmitting: false,
      showTotalNotify: true,
      maxTotalShowNotify: 10,
      minimal: false,
      loadedUserChannels: false,
      drawer: false,
      activeSubNav: -1,
      languages: [
        {
          label: 'VI',
          value: 'vi'
        },
        {
          label: 'EN',
          value: 'en'
        }
      ],
      language: null,
      logo: 'dark'
    }
  },

  computed: {
    avatar () {
      const avatar = this.user.avatar
      if (!avatar) return '/winking.png'
      if (stringIsHttp(avatar)) return avatar
      return generateAssetUrl(`/${avatar}`)
    },

    navbarDropdownOption () {
      return [
        [
          {
            type: 'nuxt-link',
            route: { name: 'settings' },
            label: 'navigation.settings',
            function: this.onHandleCloseUserMenu
          }
        ]
      ]
    },

    light () {
      return !['index', 'for-real-estate-enterprises', 'for-real-estate-brokers'].includes(this.$route.name)
    },

    pages () {
      return [
        // { to: '/', title: this.$t('navigation.home'), visible: true },
        { to: '/', title: this.$t('navigation.home'), visible: true },
        { to: '/project', title: this.$t('navigation.project'), visible: true },
        // { to: '/news', title: this.$t('navigation.news'), visible: true, highlight: true },
        { to: '/marketplace', title: this.$t('navigation.marketplace'), visible: true },
        // { to: '/phone-book', title: this.$t('navigation.phone_book'), visible: true },
        // { to: '/faq', title: this.$t('navigation.faq'), visible: true },
      ]
    },

    mobilePage () {
      return [
        { to: '/settings', title: this.$t('navigation.settings'), visible: true }
      ]
    },

    advanceMobileMenu () {
      return [
        // {
        //   function: () => {
        //     this.drawer = false
        //   },
        //   type: 'nuxt-link',
        //   to: { name: '_user-profile', params: { username: this.user.username } },
        //   title: this.$t('navigation.profile')
        // },
        // {
        //   function: this.oncLickBecomeAnAgency,
        //   title: this.$t('navigation.become_an_agency')
        // },
      ]
    },

    page () {
      const name = this.$route.name
      if (!name) return null
      const page = this.pages.find(i => {
        if (name === 'download') {
          return i.name === 'connect'
        }
        const configName = `_${i.name}`
        return (name.startsWith(i.name) || name.startsWith(configName)) && !!i.visible
      })
      return page || null
    },

    trigger () {
      if (this.isResponsiveWeb) {
        return 'click'
      }

      return 'hover'
    },

    numberUncompletedTasks () {
      if (!this.userTasks || isEmpty(this.userTasks)) {
        return 0
      }

      return chain(this.userTasks)
        .filter(item => !item.completed)
        .size()
        .value()
    },

    avatarOptions () {
      return {
        size: 24
      }
    },

    ...mapState('auth', {
      user: state => state.user
    })
  },

  watch: {
    language (val, oldVal) {
      if (!oldVal) return
      this.$i18n.setLocale(val)
    },

    '$colorMode.value' (val) {
      this.logo = this.light ? val === 'system' ? 'dark' : val : 'dark'
    }
  },

  created () {
    this.$nuxt.$on('login-done', () => {
      this.close()
    })
    this.logo = this.light ? this.$colorMode.value === 'system' ? 'dark' : this.$colorMode.value : 'dark'
    this.language = this.$i18n.locale
  },

  mounted () {
    document.addEventListener('scroll', e => {
      this.animationFrame = window.requestAnimationFrame(this.scroll)
    })
    window.addEventListener('resize', this.handleResizeWindow)
    // this.checkMinimal()
  },

  destroyed() {
    document.removeEventListener('scroll', e => {
      window.cancelAnimationFrame(this.animationFrame)
    })
    window.removeEventListener('resize', this.handleResizeWindow)
    // window.addEventListener('resize', this.checkMinimal)
  },

  methods: {
    scroll(s) {
      const scrollPos = window.scrollY
      const header = document.getElementById('header')
      if (scrollPos > 24) {
        header.classList.add('lock')
        this.logo = this.$colorMode.value
      } else {
        header.classList.remove('lock')
        this.logo = this.light ? this.$colorMode.value === 'system' ? 'dark' : this.$colorMode.value : 'dark'
      }
    },

    onClickSwitchLocalePath () {
      const lang = this.$i18n.locale === 'en' ? 'vi' : 'en'
      this.$i18n.setLocale(lang)
    },

    checkMinimal () {
      this.minimal = window.innerWidth > MEDIUM_WIDTH_EL_LAYOUT
    },

    onClickChooseLoginMethod () {
      this.drawer = false
      this.$flows.loginMethod({
        parent: this
      })
    },

    exit () {
      this.inSearchMode = !this.inSearchMode
    },

    toggleSearchMode () {
      this.inSearchMode = !this.inSearchMode
      this.$nextTick(() => {
        if (this.inSearchMode)
          this.$refs.searchBar.focus()
        else
          this.$refs.searchBar.blur()
      })
    },

    login () {
      this.$flows.login({
        parent: this
      })
    },

    register () {
      this.$flows.register({
        parent: this
      })
    },

    onClickLogout () {
      this.drawer = false
      this.onHandleCloseUserMenu()
      this.$auth.logout()
    },

    onHandleCloseUserMenu () {
      this.activeSubNav = -1
      this.userMenuVisible = false
    },

    oncLickBecomeAnAgency () {
      this.drawer = false
      this.$flows.becomeAnAgency({
        parent: this
      })
        .then(({ data }) => {
          this.$auth.fetchUser()
        })
      this.onHandleCloseUserMenu()
    },

    onClickBecomeABroker () {
      this.drawer = false
      this.$flows.becomeABroker({
        parent: this
      })
        .then(async () => {
          await this.$auth.fetchUser()
          this.$notify.success({
            message: this.$t('notification.become_a_broker_successfully')
          })
        })
    },
  }
}
</script>

<style lang="scss" scoped>
::v-deep.header-bar {
  height: $--header-height;
  // background: transparent linear-gradient(270deg, #27AAE1 100%, #2E9ED4 100%, #407EB4 100%, #59578C 100%) 0% 0% no-repeat padding-box;
  // mix-blend-mode: multiply;
  padding: 0;
  // position: sticky;
  // top: 0;
  display: unset;
  z-index: 2000;
  box-sizing: border-box;
  @include media(sm-down) {
    height: $--header-height-mobile;
    // background: rgba(#030D16, .6);
  }
  &.lock {
    .frame {
      background: var(--color-bg-header);
      top: var(--sat);
      padding: 16px 0;
      max-width: initial;
      z-index: 2000;
      box-shadow: 0px 2px 6px rgb(182 182 182 / 35%);
      @include media(sm-down) {
        padding: 16px 0;
      }
    }
    a {
      color: var(--color-shade-7)!important;
      &.nuxt-link-exact-active, &:hover {
        color: var(--color-shade-8);
      }
    }
  }
  &.light {
    .intop {
      background: var(--color-shade-1);
      color: var(--color-shade-8);
      span {
        color: var(--color-shade-8);
      }
    }
    .frame {
      background: var(--color-shade-1);
      box-shadow: 0px 2px 6px rgb(182 182 182 / 35%);
    }
    a {
      color: var(--color-shade-7)!important;
      &.nuxt-link-exact-active, &:hover {
        color: var(--color-shade-8);
      }
    }
  }
  .intop {
    height: 44px;
    color: rgba($--color-text-primary, 0.8);
    font-weight: 600;
    a {
      text-decoration: none;
      font-size: $--size-base-md;
      color: rgba($--color-text-primary, 0.8);
    }
    .container {
      height: 100%;
    }
    @include media(xs) {
      .intop__left {
        font-size: $--size-base;
        display: none;
      }
      .el-divider {
        display: none;
      }
      .intop__right {
        a {
          font-size: $--size-base;
        }
        display: flex;
        justify-content: space-between;
        width: 100%;
      }
    }
    &__left {
      font-size: $--size-base-md;
    }

  }
  @include media(md-down) {
    &.searching {
      .logo,
      .menu,
      .dropdown,
      .user {
        display: none;
      }
      .search-box {
        flex: 1;
        .input {
          display: block;
          flex: 1;
          margin-right: 16px;
        }
        .toggler {
          .open {
            display: none;
          }
          .close {
            display: block;
          }
        }
      }
    }
    &.authenticated {
      .full {
        left: initial!important;
        right: 0;
      }
    }
  }
  .translator {
    width: 70px;
    input {
      border: 1px solid var(--color-warning-6);
      color: var(--color-shade-5);
      font-size: $--size-base;
      font-weight: 700;
    }
  }
  .el-drawer {
    background-color: var(--color-shade-1);
    &__header {
      padding: calc(var(--sat) + 12px) 12px 0;
      margin-bottom: 10px;
      .button {
        height: 36px;
      }
      .user {
        a {
          text-decoration: none;
        }
        .translator {
          input {
            height: 36px;
            color: var(--color-shade-8);
            border-radius: $--radius-mini;
            border: 1px solid var(--color-warning-6);
          }
        }
      }
    }
    &__body {
      .menu-list {
        .menu-item {
          border-radius: 1.6vw;
          padding: 12px;
          display: flex;
          align-items: center;
          margin: 1vw 20px;
          color: var(--color-shade-6);
          font-weight: bold;
          text-decoration: none;
          text-transform: uppercase;
          &.el-button--primary {
            color: var(--color-shade-1);
          }
          &:hover {
            color: var(--color-shade-2);
          }
          &.nuxt-link-exact-active {
            // border: 0.4vw solid #f9ac00;
            // background-color: #4e412a;
          }
          .feather {
            width: 24px;
            height: 24px;
            margin-right: 4px;
          }
        }
      }
      .logout {
        text-align: center;
        margin: 0 auto;
        cursor: pointer;
      }
    }
  }
}
.button {
  background-color: var(--color-warning-5);
  border-radius: $--radius-mini;
  display: inline-flex;
  height: 40px;
  min-width: 32px;
  box-sizing: border-box;
  padding: 0 8px;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  position: relative;
  font-weight: bold;
  margin-right: 0;
  &.primary {
    background-color: var(--color-success-6);
  }
  .value {
    color: #f3a600;
    font-weight: bold;
    margin-left: .5em;
  }
  .icon {
    font-size: 1.2em;
  }
  .feather {
    color: $--color-text-primary;
  }
  .address {
    width: 100px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    color: $--color-text-primary;
  }
  .placeholder,
  .avatar {
    margin-left: 4px;
    display: flex;
  }
  .counter {
    position: absolute;
    right: 0;
    bottom: 0;
    transform: translate(40%, 40%);
    z-index: 1;
    font-size: 10px;
    color: white;
    background: $--color-danger;
    padding: 2px 5px;
    border-radius: 1000px;
    line-height: 1em;
  }
  &.messages,
  &.notifications,
  &.wallet,
  &.task {
    margin-right: 10px;
    @include media(sm) {
      margin-right: 12px;
    }
  }
  .translator {
    display: flex;
    align-items: center;
  }
  .color-switcher {
    // color: var(--color-shade-1);
  }
}
.frame {
  position: sticky;
  top: 24px;
  // &:not(.container) {
  //   padding-left: 16px;
  //   padding-right: 16px;
  //   @include media(md) {
  //     padding-left: 32px;
  //     padding-right: 32px;
  //   }
  // }
}
::v-deep.flex {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 100%;
  position: relative;
  .logo {
    position: relative;
    flex: 1;
    .beta-badge {
      bottom: 0;
      position: absolute;
      left: 42px;
      font-size: $--size-base;
      color: rgb(255, 255, 255);
      display: inline-block;
      font-weight: bold;
      background: linear-gradient(45deg, rgb(234, 67, 53) 10%, rgb(246, 187, 6) 20%, rgb(52, 168, 82) 55%, rgb(66, 133, 244) 70%);
      border-radius: 4px;
      padding: 2px 6px;
    }
    a {
      display: inline-flex;
      align-items: center;
      vertical-align: middle;
    }
    .full {
      width: 48px;
      position: relative;
      transition: all 0.3s ease;
      text-align: center;
      @include media(sm-down) {
        position: absolute;
        left: 50%;
        height: auto;
        top: -17px;
        img {
          height: 35px;
        }
      }
      .beta-badge {
        bottom: 2px;
        font-size: $--size-base-xs;
      }
    }
    img.symbol {
      width: 28px;
      @include media(md) { display: none; }
    }
  }
  .menu {
    flex: 1;
    font-size: $--size-base-md;
    display: none;
    display: flex;
    align-items: center;
    .highlight {
      padding: 4px 10px;
      background: #eb9023;
      border-radius: 4px;
    }
    .feather {
      width: 18px;
      height: 18px;
      vertical-align: sub;
    }
    @include media(sm-down) {
      display: none;
    }
    > a {
      margin-right: 18px;
      height: 100%;
      display: flex;
      align-items: center;
      border-bottom: 2px solid transparent;
      font-weight: 700;
      text-decoration: none;
      color: rgba($--color-text-primary, 0.8);
      span {
        font-size: $--size-base-md;
      }
      @include media(lg) {
        margin-right: 32px;
      }
      &:hover {
        color: rgba($--color-text-primary, 1);
      }
      &.nuxt-link-exact-active {
        color: rgba($--color-text-primary, 1);
      }
    }
  }
  .dropdown {
    flex: 1;
    font-size: $--size-base-xs;
    display: block;
    margin-left: 16px;
    @include media(md) {
      display: none;
    }
    .route {
      display: flex;
      align-items: center;
      cursor: pointer;
      .title {
        margin-left: 24px;
        font-size: $--size-base;
        height: 100%;
        display: flex;
        align-items: center;
        border-bottom: 2px solid transparent;
        font-weight: bold;
        color: #bfc6d1;
      }
      .icon {
        margin-left: 8px;
      }
    }
  }
  .search-box {
    display: flex;
    align-items: center;
    .input {
      display: none;
      width: 220px;
      @include media(lg) {
        display: block;
      }
    }
    .toggler {
      @include media(lg) {
        display: none;
      }
      .close {
        display: none;
        font-size: .8em;
      }
      .open {
        display: block;
      }
    }
  }
  .user {
    white-space: nowrap;
    margin-left: 10px;
    @include media(sm) {
      margin-left: 16px;
    }
    .dropdown-create {
      margin-right: 10px;
    }
    .el-dropdown {
      outline: none;
    }
  }
  .feather-menu {
    color: var(--color-shade-5);
    // color: $--color-text-primary;
  }
  .login-button {
    height: 40px;
    min-width: 100px;
    @include media(xs) {
      min-width: 60px;
      padding: 6px 10px;
    }
    span {
      display: flex;
      justify-content: center;
      align-items: center;
    }
  }
}
</style>

<style lang="scss" scoped>
.user-menu {
  z-index: 10001!important;
  color: var(--color-shade-1);
  a, span {
    display: flex;
    text-decoration: none;
    align-items: center;
    font-size: $--size-base-xs;
    line-height: 1.5em;
    height: 40px;
    color: var(--color-shade-4);
    &.nuxt-link-active {
      font-weight: normal;
    }
    .icon {
      color: $--color-highlight;
      flex: 24px 0;
      text-align: center;
      font-size: 1.25em;
      margin-right: 8px;
      height: 15px;
    }
    .title {
      flex: 1;
      color: white;
    }
    .counter {
      color: $--color-highlight;
      text-align: right;
      &.empty {
        font-size: 10px;
        line-height: 1.2em;
        color: rgba(white, .5)
      }
      &.unread {
        background-color: $--color-danger;
        color: white;
        margin-right: 1em;
        border-radius: 50%;
        padding: 0px;
        width: 23px;
        height: 23px;
        display: block;
        text-align: center;
        line-height: 23px;
        sup {
          vertical-align: bottom;
        }
      }
    }
    .value {
      color: white;
      > * {
        vertical-align: middle;
      }
      .coin {
        margin-right: .25em;
      }
    }
  }
}
.user-menu-dropdown {
  nav {
    list-style: none;
    padding: 0;
    margin: 0;
    position: relative;
    overflow: hidden;
    .sub-nav {
      width: 100%;
      height: 100%;
      background: var(--color-shade-1);
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      transform: translateX(100%);
      transition: transform 200ms ease-in;
      &.is-active {
        transform: translateX(0%);
      }
    }
    a {
      line-height: 24px;
      padding: 4px 8px;
      border-radius: $--radius-medium;
      &.avatar {
        height: 64px;
        img {
          width: 56px;
          height: 56px;
          border-radius: 50%;
        }
        .profile {
          flex: 1 1;
          span, strong {
            font-size: $--size-base-md;
            line-height: 1.5em;
          }
        }
      }
      &:hover {
        background-color: var(--color-shade-2);
      }
    }
  }
  a {
    display: flex;
    text-decoration: none;
    align-items: center;
    font-size: $--size-base;
    line-height: 1.5em;
    height: 40px;
    color: var(--color-shade-4);
    cursor: pointer;
    &.nuxt-link-active {
      font-weight: 500;
    }
  }
}
</style>
