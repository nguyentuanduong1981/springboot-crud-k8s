<template lang="pug">
v-chart(
  class="chart"
  :option="option"
  :theme="$colorMode.value"
  autoresize
)
</template>

<script>
import { use } from 'echarts/core';
import { SVGRenderer } from 'echarts/renderers';
import { LineChart } from 'echarts/charts';
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent
} from 'echarts/components';
import VChart, { THEME_KEY } from 'vue-echarts';

use([
  SVGRenderer,
  LineChart,
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent
]);

export default {
  name: 'HelloWorld',

  components: {
    VChart,
  },

  provide () {
    return {
      [THEME_KEY]: 'light',
    }
  },

  props: {
    title: {
      type: String,
      default: ''
    }
  },

  data () {
    return {
      option: {
        title: {
          text: this.title,
          left: 'left',
        },
        tooltip: {
          trigger: 'item',
          left: 'center',
          formatter: '{a} <br/>{b} : {c}',
        },
        legend: {
          orient: 'vertical',
          left: 'left',
          data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        },
        xAxis: {
          type: 'category',
          data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            data: [150, 230, 224, 218, 135, 147, 260],
            type: 'line'
          }
        ]
      },
    };
  },
};
</script>

<style scoped>
.chart {
  height: 300px;
}
</style>
