<template lang="pug">
v-chart(
  class="chart"
  :option="option"
  :theme="$colorMode.value"
  autoresize
)
</template>

<script>
import { use } from 'echarts/core';
import { SVGRenderer } from 'echarts/renderers';
import { PieChart } from 'echarts/charts';
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
} from 'echarts/components';
import VChart, { THEME_KEY } from 'vue-echarts';

use([
  SVGRenderer,
  PieChart,
  TitleComponent,
  TooltipComponent,
  LegendComponent,
]);

export default {
  name: 'PieChart',

  components: {
    VChart,
  },

  provide () {
    return {
      [THEME_KEY]: 'light',
    }
  },

  props: {
    title: {
      type: String,
      default: ''
    }
  },

  data () {
    return {
      option: {
        title: {
          text: this.title,
          left: 'left',
        },
        tooltip: {
          trigger: 'item',
          formatter: '{a} <br/>{b} : {c} ({d}%)',
        },
        legend: {
          orient: 'vertical',
          left: 'left',
          top: 'middle',
          data: [
            'Nhà đất',
            'Cao ốc',
            'Nhà ở',
            'Đô thị mới',
          ],
        },
        series: [
          {
            name: this.$t('pages.settings.projects'),
            type: 'pie',
            radius: '55%',
            center: ['50%', '60%'],
            data: [
              { value: 335, name: 'Nhà đất' },
              { value: 310, name: 'Cao ốc' },
              { value: 234, name: 'Nhà ở' },
              { value: 135, name: 'Đô thị mới' },
            ],
            emphasis: {
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)',
              },
            },
          },
        ],
      },
    };
  },
};
</script>

<style scoped>
.chart {
  height: 300px;
}
</style>
