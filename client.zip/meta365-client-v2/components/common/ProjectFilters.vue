<template lang="pug">
el-tabs.tab(
  v-model="activeTab"
  stretch
)
  el-tab-pane.p-relative(
    :label="$t('pages.project.filters')"
    name="pages.project.filters"
  )
    el-form.px-16(
      ref="formFilter"
      :model="query"
      label-position="top"
    )
      el-form-item(
        prop="name"
      )
        el-input.fw(
          v-model="query.name"
          :placeholder="$t('pages.project.project_name')"
          @keydown.enter.native="onClickSearch()"
        )
      el-form-item(
        prop="category"
      )
        el-select.fw(
          v-model="query.category"
          clearable
          popper-class="no-arrow fit"
          :placeholder="$t('pages.project.categories')"
        )
          //- el-option(
          //-   :label="$t('common.all')"
          //-   value=""
          //- )
          el-option(
            v-for="category in categories"
            :key="category.value"
            :label="category.label"
            :value="category.value"
          )
      el-form-item(
        prop="phase"
      )
        el-select.fw(
          v-model="query.phase"
          clearable
          popper-class="no-arrow fit"
          :placeholder="$t('pages.home.phase')"
        )
          //- el-option(
          //-   :label="$t('pages.home.phase')"
          //-   disabled
          //- )
          el-option(
            v-for="item in optionsPhases"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          )
      //- el-form-item(
      //-   prop="totalInvestment"
      //-   :label="`${$t('pages.home.price')}: ${query.totalInvestment[0]} - ${query.totalInvestment[1]} ${$t('currency.millions')}`"
      //- )
      //-   .d-flex
      //-     el-input-number(
      //-       v-model="query.totalInvestment[0]"
      //-       controls-position="right"
      //-       :min="1"
      //-       :max="query.totalInvestment[1] - 1"
      //-     )
      //-     .space
      //-     el-input-number(
      //-       v-model="query.totalInvestment[1]"
      //-       controls-position="right"
      //-       :min="query.totalInvestment[0] + 1"
      //-       :max="100000"
      //-     )
        //- el-slider.mt-10(
        //-     range
        //-     :min="1"
        //-     show-stops
        //-     :max="100000"
        //-     :show-tooltip="false"
        //-     v-model="query.totalInvestment"
        //-   )
      el-form-item(
        prop="sort"
      )
        el-select.fw.last-item(
          v-model="query.sort"
          clearable
          popper-class="no-arrow fit"
          :placeholder="$t('common.sort_by')"
        )
          el-option(
            :label="$t('pages.project.latest')"
            value="createdAt:desc"
          )
          el-option(
            :label="$t('pages.project.oldest')"
            value="createdAt:asc"
          )
          el-option(
            :label="$t('pages.project.top_rated')"
            value="rate:desc"
          )

    .bottom-action.py-10.d-flex
      el-button.fw(
        type="primary"
        icon="el-icon-search"
        @click.native="onClickSearch()"
      ) {{ $t('common.search') }}
      el-button.fw(
        type="info"
        @click.native="resetFields()"
        icon="el-icon-refresh-left"
      ) {{ $t('common.reset') }}

  el-tab-pane(
    disabled
    :label='$t("pages.project.categories")',
    name='pages.project.categories'
  )
</template>

<script>
import { mapState } from 'vuex'
const DEFAULT = {
  name: '',
  category: '',
  location: '',
  status: '',
  sort: '',
  phase: '',
  limit: 12,
  page: 1
}

export default {
  name: 'ProjectFilters',

  props: {
    query: {
      type: Object,
      default: () => (DEFAULT)
    }
  },

  data () {
    return {
      activeTab: 'pages.project.filters',
      display: 0,
      optionsPhases: [
        // {
        //   value: '',
        //   label: 'All'
        // },
        {
          value: 'open_for_sale',
          label: 'Mở bán',
        },
        {
          value: 'hand_over',
          label: 'Đang bàn giao',
        },
      ],
    }
  },

  computed: {
    ...mapState('project', {
      categories: state => state.categories
    })
  },

  methods: {
    onClickSearch () {
      this.$emit('search', this.query)
    },

    resetFields () {
      this.$emit('reset')
    }
  }
}
</script>

<style lang="scss" scoped>
.last-item {
}
::v-deep.tab {
  .el-tabs {
    &__item {
      font-size: $--size-base-md;
      padding: 0;
      color: var(--color-shade-6);
      &.is-active {
        border-radius: 20px;
        background-color: var(--color-primary-5);
      }
    }
    &__nav {
      padding: 6px 0;
    }
    &__active-bar {
      display: none;
    }
    &__nav-wrap {
      padding: 0 14px;
      &::after {
        background-color: transparent;
      }
    }
    .form-label {
      font-size: $--size-base;
    }
  }
  .el-form {
    &-item {
      margin-bottom: 28px;
      &__label {
        color: var(--color-shade-6);
        padding-bottom: 0;
      }
    }
  }
}

.bottom-action {
  $pd: 10px;
  width: calc(100% - $pd * 2);
  padding: 10px $pd;
  position: sticky;
  background: var(--color-shade-2);
  justify-content: space-between;
  bottom: 0;
}
</style>
