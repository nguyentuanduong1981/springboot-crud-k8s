<template lang="pug">
.marketplace-component
  el-form.px-16(
    ref="formFilter"
    :model="query"
    label-position="top"
  )
    el-form-item(
      prop="status"
      :label="$t('components.marketplace.status')"
    )
      el-radio-group(
        v-model="query.status"
      )
        el-radio.fw(
          label="single_lands"
          border
        ) {{ $t('components.marketplace.single_lands') }}
        el-radio.fw(
          label="bundles"
          border
        ) {{ $t('components.marketplace.bundles') }}
        el-radio.fw(
          label="voting"
          border
        ) {{ $t('components.marketplace.voting') }}
    el-form-item(
      prop="name"
    )
      el-input.fw(
        v-model="query.name"
        :placeholder="$t('components.marketplace.land_name')"
        @keydown.enter.native="onClickSearch()"
      )
    el-form-item(
      prop="price"
      :label="`${$t('components.marketplace.price')}: ${query.price[0]} - ${query.price[1]} $`"
    )
      .d-flex
        el-input-number(
          v-model="query.price[0]"
          controls-position="right"
          :min="1"
          :max="query.price[1] - 1"
        )
        .space
        el-input-number(
          v-model="query.price[1]"
          controls-position="right"
          :min="query.price[0] + 1"
          :max="1000000"
        )
    el-form-item(
      prop="project"
    )
      el-select.fw.last-item(
        v-model="query.project"
        clearable
        popper-class="no-arrow fit"
        :placeholder="$t('components.marketplace.project')"
      )
    el-form-item(
      prop="sort"
    )
      el-select.fw.last-item(
        v-model="query.sort"
        clearable
        popper-class="no-arrow fit"
        :placeholder="$t('common.sort_by')"
      )
        el-option(
          :label="$t('components.marketplace.price_low_to_high')"
          value="price:asc"
        )
        el-option(
          :label="$t('components.marketplace.price_high_to_low')"
          value="price:desc"
        )
        el-option(
          :label="$t('components.marketplace.oldest')"
          value="updateAt:asc"
        )
        el-option(
          :label="$t('components.marketplace.latest')"
          value="updateAt:desc"
        )
  .bottom-action.py-10.d-flex
    el-button.fw(
      type="primary"
      icon="el-icon-search"
      @click.native="onClickSearch()"
    ) {{ $t('common.search') }}
    el-button.fw(
      type="info"
      @click.native="resetFields()"
      icon="el-icon-refresh-left"
    ) {{ $t('common.reset') }}
</template>

<script>
import { mapState } from 'vuex'
const DEFAULT = {
  name: '',
  price: [1, 1000000],
  sort: '',
  project: '',
  status: '',
  limit: 12,
  page: 1
}

export default {
  name: 'ProjectFilters',

  props: {
    query: {
      type: Object,
      default: () => (DEFAULT)
    }
  },

  data () {
    return {
      activeTab: 'components.marketplace.land',
      display: 0,
      optionsPhases: [
        // {
        //   value: '',
        //   label: 'All'
        // },
        {
          value: 'open_for_sale',
          label: 'Mở bán',
        },
        {
          value: 'hand_over',
          label: 'Đang bàn giao',
        },
      ],
    }
  },

  computed: {
    ...mapState('project', {
      categories: state => state.categories
    })
  },

  methods: {
    onClickSearch () {
      this.$emit('search', this.query)
    },

    resetFields () {
      this.$emit('reset')
    }
  }
}
</script>

<style lang="scss" scoped>
.marketplace-component {
}
.el-form {
  height: calc(100vh - $--header-height - 60px - 1px);
  overflow-y: auto;
  overflow-x: hidden;
  @include media(sm-down) {
    height: calc(100vh - $--header-height-mobile - 60px - 1px);
  }
  @include media(xs) {
    height: calc(100vh - 60px - 1px);
  }
  &-item {
    margin-bottom: 28px;
    &__label {
      color: var(--color-shade-6);
      padding-bottom: 0;
    }
  }
}

.bottom-action {
  $pd: 10px;
  width: calc(100% - $pd * 2);
  padding: 10px $pd;
  position: sticky;
  background: var(--color-shade-2);
  justify-content: space-between;
  bottom: 0;
}
</style>
