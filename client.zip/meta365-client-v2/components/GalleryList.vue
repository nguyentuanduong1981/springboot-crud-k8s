<template lang="pug">
el-row.gallery(:gutter="12")
  el-col.py-6(
    @click.native="onClickPreviewImage(index)",
    v-for="item, index in lists.slice(0, 9)",
    :key="index",
    :span="8"
  )
    .gallery__item(
      :class="{ 'last-item': index === 8 }"
    )
      .more(
        v-if="index === 8"
      ) +{{ lists.length - 9 }}
      nuxt-img(
        provider="meta365"
        :src="item.url"
      )
</template>

<script>
import { parseImage } from '@/utilities/helpers'

export default {
  name: 'GalleryList',

  props: {
    lists: {
      type: Array,
      default: () => ([])
    }
  },

  methods: {
    onClickPreviewImage (i) {
      this.$preview({
        parent: this,
        index: i,
        medias: this.lists.map(item => ({
          ...item,
          url: parseImage(item.url)
        }))
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.gallery {
  &__item {
    position: relative;
    width: 100%;
    border-radius: 6px;
    .more {
      z-index: 1;
      position: absolute;
      top: calc(50% - 14px);
      color: $--color-text-regular;
      font-size: 22px;
      font-weight: 500;
      right: 0;
      left: 0;
      text-align: center;
    }
    &.last-item {
      &::before {
        border-radius: 6px;
        background-color: #565656ad;
        content: "";
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        z-index: 1;
        width: 100%;
        height: 100%;
        display: block;
      }
    }
    &::after {
      content: "";
      display: block;
      padding-bottom: 100%;
    }
    img {
      border-radius: 6px;
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
    }
  }
}
</style>
