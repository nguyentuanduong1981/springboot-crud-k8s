<template lang="pug">
.card
  nuxt-link(:to="to")
    .card__info
      .d-flex
        .avatar
          img(
            :src="avatar" alt=""
          )
        .flex-column.more-info
          small.no-link.mt-0(v-if="!user.socials || !user.socials.length") {{ $t('common.no_social_network_link') }}
          .social.d-flex
            .social__item.my-0(v-for="i in user.socials")
              a(:href="i.value" target="_blank")
                img(:src="`/socials/${i.key}.svg`")
          el-rate(
            :value="user.rate || 0"
            disabled
            show-score
            text-color="#ff9900"
            disabled-void-color="#bbbbbb"
            score-template="{value}/5(0 review)"
          )
  .card__body
    h2.user__name
      nuxt-link(
        :to="{ name: '_user-profile', params: { username: user.username } }"
      )
        el-tooltip-theme(
          :content="$t('navigation.profile')"
          placement="bottom"
        )
          span {{ user.fullName || user.username }}
  .card__footer
    a.btn.fw.btn__primary(
      :href="`tel:${user.phoneNumber}`"
    )
      | {{ $t('components.user_card.call_now') }}
    nuxt-link.btn.fw.btn__primary(
      :to="{ name: '_user-profile', params: { username: user.username } }"
    ) {{ $t('components.user_card.profile') }}
</template>

<script>
import { generateAssetUrl } from '@/utilities/helpers'

export default {
  name: 'UserCard',

  props: {
    user: {
      type: Object,
      default: () => ({}),
      required: true
    },

    propRoute: {
      type: Object,
      default: () => ({}),
      required: false
    }
  },

  computed: {
    avatar () {
      if (!this.user?.avatar) return '/winking.png'
      return generateAssetUrl(`/${this.user?.avatar}`)
    },

    coverParse () {
      return generateAssetUrl(`/${this.user.cover}`)
    },

    to () {
      return this.propRoute || { name: '_user-profile', params: { username: this.user.username } }
    }
  },

  methods: {
  }
}
</script>

<style lang="scss" scoped>
a {
  text-decoration: none;
}
.card {
  position: relative;
  background-color: var(--color-shade-1);
  border-radius: $--radius;
  margin: 10px 5px;
  padding: 10px;
  &.no-margin {
    margin: 10px 0 0;
  }
  &__info {
    >.d-flex {
      .avatar {
        flex: 0 0 64px;
        width: 64px;
        height: 64px;
        img {
          border-radius: 50%;
          max-width: 100%;
          height: auto;
          border: 1px solid var(--color-shade-3);
        }
      }
      .more-info {
        margin-left: 6px;
        padding: 8px 4px;
        flex: 1 1;
        .no-link {
          height: 28px;
        }
      }
    }
    transition: 0.5s ease-in-out;
    padding: 10px 0 6px;
  }
  &__body {
    padding: 0 4px;
  }
  &__footer {
    width: 100%;
    display: flex;
    justify-content: space-between;
    text-align: center;
  }
}

.user {
  &__name {
    margin: 10px 0 20px;
    color: var(--color-warning-5);
    position: relative;
    a {
      color: var(--color-shade-6);
      @include text-ellipsis(2);
      span {
        font-size: $--size-base-md;
      }
    }
    &::after {
      position: absolute;
      left: 0;
      bottom: -8px;
      content: "";
      height: 2px;
      width: 45px;
      background-color: var(--color-warning-5);
      display: inline-block;
    }
  }
  &__social {
    text-align: center;
  }
}

.btn {
  transition: 0.3s ease-in;
  display: inline-block;
  padding: 10px 20px;
  border-radius: $--radius-medium;
  text-align: center;
  text-decoration: none;
  box-shadow: 0 1px 5px rgba(0,0,0,0.2);
  margin: 0 4px;
  font-size: $--size-base;
  font-weight: 600;
  &:hover {
   box-shadow: none;
  }
  &__primary {
    background-color: var(--color-primary-6);
      color: var(--color-shade-1);
    &:hover {
      color: var(--color-shade-1);
      background-color: var(--color-primary-6);
    }
  }
}
</style>
