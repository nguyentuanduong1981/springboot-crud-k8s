<template lang="pug">
swiper.partners-list(
  :options="swiperPartnersOptions"
)
  swiper-slide(
    v-for="item in partners" :key="item"
  )
    component(
      :is="item"
    )
</template>

<script>
import { Swiper, SwiperSlide, directive } from 'vue-awesome-swiper'
import SunGroup from '@/assets/images/partners/sun-group.svg?inline'
import Hub from '@/assets/images/partners/hub.svg?inline'
import NovaWorld from '@/assets/images/partners/nova-world.svg?inline'
import MshGroup from '@/assets/images/partners/msh-group.svg?inline'
import Red from '@/assets/images/partners/red.svg?inline'
import Fibo from '@/assets/images/partners/fibo.svg?inline'
import Dns from '@/assets/images/partners/dns.svg?inline'
import Utc from '@/assets/images/partners/utc.svg?inline'
import Fgi from '@/assets/images/partners/fgi.svg?inline'
import CenGroup from '@/assets/images/partners/cen-group.svg?inline'
import CenHousing from '@/assets/images/partners/cen-housing.svg?inline'
import MicHolding from '@/assets/images/partners/mic-holding.svg?inline'
import HungVuong from '@/assets/images/partners/hungvuong.svg?inline'
import 'swiper/css/swiper.css'

export default {
  name: 'PartnersAndCustomers',

  components: {
    Swiper,
    SwiperSlide,
    SunGroup,
    Hub,
    NovaWorld,
    MshGroup,
    Red,
    Fibo,
    Dns,
    Utc,
    Fgi,
    CenGroup,
    CenHousing,
    MicHolding,
    HungVuong
  },

  directives: {
    swiper: directive,
  },

  data () {
    return {
      swiperPartnersOptions: {
        grabCursor: true,
        loop: true,
        slidesPerView: 2,
        spaceBetween: 10,
        // freeMode: true,
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
          dynamicBullets: true,
        },
        navigation: {
          nextEl: '.partner-swiper-next',
          prevEl: '.partner-swiper-prev'
        },
        autoplay: {
          delay: 2000,
          disableOnInteraction: false,
        },
        breakpoints: {
          992: {
            slidesPerView: 5,
            spaceBetween: 10,
          },
          768: {
            slidesPerView: 4,
            spaceBetween: 10,
          },
          576: {
            slidesPerView: 2,
            spaceBetween: 10,
          },
          325: {
            slidesPerView: 1,
            spaceBetween: 10,
          },
        },
      },
      partners: [
        'SunGroup',
        'Hub',
        'NovaWorld',
        'MshGroup',
        'Red',
        'Fibo',
        'Dns',
        'Utc',
        'Fgi',
        'CenGroup',
        'CenHousing',
        'MicHolding',
        'HungVuong',
      ],
    }
  }
}
</script>

<style lang="scss" scoped>
.swiper-slide {
  height: 100px;
  text-align: center;
  color: var(--color-shade-7);
}
</style>
