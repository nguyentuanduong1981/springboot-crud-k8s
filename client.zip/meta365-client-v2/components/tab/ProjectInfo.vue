<template lang="pug">
el-container.project-info#project-info(
  name="info"
  :label="$t('pages.detail_project.info')"
)
  el-aside(
    width="30px"
  )
     ul
      li
        a(href='#overview')
          home-icon(
            size="24"
          )
      li
        a(href='#detail')
          layout-icon(
            size="24"
          )
      li
        a(href='#gallery')
          image-icon(
            size="24"
          )

  el-main.p-0.pl-4
    section.section#overview
      el-card.tab.main-info__description(shadow="never")
        .clearfix(slot='header')
          span.tab__title {{ $t('pages.detail_project.overview') }}
        div(v-html="project.description")
        //- p
        //-   TextShortener(
        //-     :text="project.description"
        //-   )
    .hidden-sm-and-down.flex-between.mt-20(
      v-if="$route.name === 'project-id'"
    )
      el-button.fw(
        icon="el-icon-message"
        type="primary"
        size="small"
        @click.native="onClickOpenContactUsModal()"
      )
        | {{ $t('pages.detail_project.contact_us') }}
      el-button(
        size="small"
        :class="{ favored }"
        @click.native="$emit('favorite')"
      )
        heart-icon(
          size="20"
        )
    section.section#detail
      el-card.tab(shadow="never")
        .clearfix(slot='header')
          span.tab__title {{ $t('pages.detail_project.details') }}
        .flex-between.p-4
          .label
            | {{ $t('pages.detail_project.total_area') }}
          .value.ta-r.ml-8
            | {{ project.totalArea }}
        .flex-between.p-4
          .label
            | {{ $t('pages.detail_project.location') }}
          .value.ta-r.ml-8
            | {{ project.detailLocation }}
        .flex-between.p-4
          .label
            | {{ $t('pages.detail_project.investor') }}
          .value.ta-r.ml-8
            | {{ project.investor }}
        .flex-between.p-4
          .label
            | {{ $t('pages.detail_project.total_investment') }}
          .value.ta-r.ml-8
            | {{ project.totalInvestment }} {{ $t('pages.detail_project.billion') }}
        .flex-between.p-4
          .label
            | {{ $t('pages.detail_project.development_unit') }}
          .value.ta-r.ml-8
            | {{ project.developmentUnit }}
        .flex-between.p-4
          .label
            | {{ $t('pages.detail_project.construction_contractor') }}
          .value.ta-r.ml-8
            | {{ project.constructionContractor }}
        .flex-between.p-4
          .label
            | {{ $t('pages.detail_project.design_consulting_unit') }}
          .value.ta-r.ml-8
            | {{ project.designConsultingUnit }}
        .flex-between.p-4
          .label
            | {{ $t('pages.detail_project.project_scale') }}
          .value.ta-r.ml-8
            | {{ project.projectScale }}
        .flex-between.p-4
          .label
            | {{ $t('pages.detail_project.legal') }}
          .value.ta-r.ml-8
            | {{ project.legal }}
        .flex-between.p-4
          .label
            | {{ $t('pages.detail_project.phase') }}
          .value.ta-r.ml-8
            | {{ $t(`components.project_item.${project.phase}`) }}
    section.section#gallery
      el-card.tab(shadow="never")
        .clearfix(slot='header')
          span.tab__title {{ $t('pages.detail_project.gallery') }}
        GalleryList(
          :lists="images"
        )
</template>

<script>
import { LayoutIcon, ImageIcon, HomeIcon, HeartIcon } from 'vue-feather-icons'

export default {
  name: 'TabProjectInfo',

  components: {
    LayoutIcon,
    HomeIcon,
    ImageIcon,
    HeartIcon
  },

  props: {
    project: {
      type: Object,
      required: true
    },

    favored: {
      type: Boolean,
      default: false
    }
  },

  data () {
    return {
      observer: null,
    }
  },

  computed: {
    images () {
      return this.project.images.map(image => {
        return {
          type: 'image',
          url: image
        }
      })
    }
  },

  mounted () {
    this.observer = new IntersectionObserver(this.onElementObserved, {
      threshold: 0.22,
    })
    // Track all sections that have an `id` applied
    document.getElementById('project-info').querySelectorAll('section[id]').forEach((section) => {
      this.observer.observe(section)
    })
  },

  beforeDestroy() {
    this.observer.disconnect()
  },

  methods: {
    onElementObserved(entries) {
      entries.forEach(({ target, isIntersecting, intersectionRatio }) => {
        const id = target.getAttribute('id')
        if (isIntersecting) {
          this.$el
            .querySelector(`aside li a[href="#${id}"]`)
            .parentElement.classList.add('active')
        } else {
          this.$el
            .querySelector(`aside li a[href="#${id}"]`)
            .parentElement.classList.remove('active')
        }
      })
    },

    onClickOpenContactUsModal () {
      this.$flows.contactUs({
        parent: this,
        project: this.project
      })
    }
  }
}
</script>

<style lang="scss" scoped>
::v-deep#project-info {
  ul {
    list-style-type: none;
    padding: 0;
    li {
      svg {
        color: var(--color-shade-7);
      }
      &.active {
        svg {
          color: var(--color-warning-5);
        }
      }
    }
  }
  .label {
    min-width: 100px;
    line-height: 22px;
  }
  .value {
    line-height: 22px;
  }
  .el-aside {
    position: sticky;
    z-index: 1;
    top: 0px;
    align-self: flex-start;
    height: auto !important;
  }
}
</style>
