<template lang="pug">
div(
  name="agency"
  :label="$t('pages.detail_project.agency')"
)
  .text-center.mb-20
    CopyComponent.copy(
      v-if="joined"
      :text="generateUrl(`/sale/${joined._id}`, domain)"
    )
      template(#title)
        span.mr-2.copy-component__title {{ $t('pages.detail_project.my_link') }}:
    el-button(
      v-else
      type="primary"
      @click.native="generateMyLink()"
    ) {{ $t('pages.detail_project.register_for_sale') }}
    el-input.mt-10(
      :placeholder="$t('components.project_agency.find_broker')"
      clearable
      v-model="name"
    )
  el-row(:gutter="16")
    el-col.tab.main-info__agency(
      :md="24"
      :sm="12"
      :xs="24"
      v-for="agency in agencies"
      :key="agency._id"
      shadow="always"
    )
      UserCard(
        :prop-route="{ name: 'sale-id', params: { id: agency._id }}"
        :user="agency.user"
      )
    el-empty(
      v-if="!agencies.length"
      :image-size="100"
      :description="$t('pages.agent.empty')"
      image="/quivering.png"
    )
    client-only
      infinite-loading(
        direction="bottom"
        :distance="20"
        @infinite="onInfiniteScroll"
        :identifier="infiniteId"
      )
        span.font-size-root(slot="no-more") {{ $t('common.no_more') }}
        span.font-size-root(slot="no-results")
          //- el-empty(
          //-   :image-size="100"
          //-   :description="$t('pages.agent.empty')"
          //-   image="/quivering.png"
          //- )
</template>

<script>
import { generateUrl } from '@/utilities/helpers'
import { debounce } from 'lodash'

export default {
  name: 'TabProjectAgency',

  props: {
    agencies: {
      type: Array,
      default: () => ([])
    },

    joined: {
      default: null
    },

    currentUserId: {
      type: String,
      default: ''
    },

    domain: {
      type: String,
      default: ''
    }
  },

  data () {
    return {
      termForm: {
        isAccept: false
      },
      infiniteId: 0,
      name: ''
    }
  },

  watch: {
    name: debounce(function (val) {
      if (!val) return
      this.$emit('search', val)
    }, 200)
  },

  methods: {
    generateUrl,

    generateMyLink () {
      if (!this.$auth.loggedIn || !this.currentUserId) {
        return this.$router.replace({
          query: {
            ...this.$route.query,
            'request-login': true
          }
        })
      }
      this.$flows.confirmTerms({
        parent: this,
        terms: ''
      })
        .then((data) => {
          this.infiniteId++
          this.$emit('refresh', data)
        })
    },

    onInfiniteScroll ($state) {
      return this.$emit('onscroll', $state)
    }
  }
}
</script>

<style lang="scss" scoped>
.main-info__agency {
  overflow: hidden;
}
</style>
