<template lang="pug">
el-table(
  :data="data"
  stripe
)
  el-table-column(
    v-if="isOwner"
    fixed
    type="selection"
    width="45"
  )
  el-table-column(
    prop="phoneNumber"
    :label="$t('field.phoneNumber')"
    width="150"
  )
  el-table-column(
    prop="fullName"
    :label="$t('field.full_name')"
    min-width="180"
  )
  el-table-column(
    prop="email"
    :label="$t('field.email')"
    min-width="150"
  )
  el-table-column(
    prop="role"
    :label="$t('field.role')"
    min-width="150"
  )
  el-table-column(
    prop="fullName"
    :label="$t('navigation.profile')"
    width="180"
  )
    template(slot-scope="scope")
      nuxt-link(:to="{ name: '_user-profile', params: { username: scope.row.username } }") {{ scope.row.username }}
  el-table-column(
    prop="city"
    :label="$t('field.avatar')"
    width="120"
  )
    template(slot-scope="scope")
      nuxt-img(
        v-if="scope.row.avatar"
        width="100"
        height="100"
        :src="parseImage(scope.row.avatar)"
      )
  el-table-column(
    v-if="isOwner"
    fixed="right"
    label="Action"
    resizable
    :width="isResponsiveWeb ? 80 : 174"
  )
    template(slot-scope="scope")
      el-button(size="mini" @click="handleEdit(scope.$index, scope.row)")
        span.hidden-xs-only {{ $t('common.edit') }}
        Edit2Icon.hidden-sm-and-up(
          size="18"
        )
      el-button(size="mini" type="danger" @click="handleDelete(scope.$index, scope.row)")
        span.hidden-xs-only {{ $t('common.delete') }}
        TrashIcon.hidden-sm-and-up(
          size="18"
        )

</template>

<script>
import { Edit2Icon, TrashIcon } from 'vue-feather-icons'
import { parseImage } from '@/utilities/helpers'

export default {
  name: 'Table',

  components: {
    Edit2Icon,
    TrashIcon
  },

  props: {
    data: {
      type: Array,
      default: () => ([])
    },

    isResponsiveWeb: {
      type: Boolean,
      default: false
    },

    isOwner: {
      type: Boolean,
      default: false
    }
  },

  data() {
    return {
    }
  },

  methods: {
    handleClick() {
    },

    handleEdit(_index, _row) {
    },

    handleDelete(_index, _row) {
    },

    parseImage,
  }
}
</script>

<style lang="scss" scoped>
::v-deep.el-table {
  .el-button + .el-button {
    @include media(sm-down) {
      margin-top: 6px;
      margin-left: 0;
    }
  }
}
</style>
