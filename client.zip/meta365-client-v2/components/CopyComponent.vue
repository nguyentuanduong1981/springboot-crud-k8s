<template lang="pug">
.flex-center-y.copy-component(
  v-if="text"
  :class="{ copied }"
  v-clipboard:copy="text"
  v-clipboard:success="clipboardSuccess"
)
  slot(
    v-if="$slots.title"
    name="title"
  )
  p.copy-component__text.c-text-ellipsis-0(
  ) {{ text }}
  CopyIcon(size="22")
</template>

<script>
import { CopyIcon } from 'vue-feather-icons'

export default {
  name: 'CopyComponent',

  components: {
    CopyIcon
  },

  props: {
    text: {
      type: String,
      required: true
    }
  },

  data () {
    return {
      copied: false
    }
  },

  methods: {
    clipboardSuccess () {
      this.copied = true
      this.$message({
        type: 'success',
        message: this.$t('common.copied')
      })
      setTimeout(() => {
        this.copied = false
      }, 1000)
    }
  }
}
</script>

<style lang="scss" scoped>
.copy-component {
  color: var(--color-shade-6);
  background: var(--color-shade-1);
  border: 1px solid var(--color-primary-4);
  border-radius: 4px;
  padding: 0 8px;
  margin-bottom: 10px;
  justify-content: space-between;
  &__title {
    font-weight: 500;
  }
  &__text {
    margin: 10px 0;
    flex: 1 1;
  }
  &.copied {
    .feather {
      color: $--color-success;
    }
  }
  .feather {
    flex: 0 0 24px;
  }
}
</style>
