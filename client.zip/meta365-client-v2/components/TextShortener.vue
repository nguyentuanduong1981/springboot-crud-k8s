<template lang="pug">
  span.text-shortener
    template(v-if="isShorter")
        span(v-for="word in processWordsOrigin")
          span(v-if="!word.value") {{ word.key }}
          a(v-else :href="word.key" target="_blank") {{ word.key }}
    template(v-else-if="isShorten")
        span(v-for="word in processWordsShorten")
          span(v-if="!word.value") {{ word.key }}
          a(v-else :href="word.key" target="_blank") {{ word.key }}
        span.show(@click="isShorten = false")  {{ $t('common.show_more') }}
    template(v-else)
      span(v-for="word in processWordsOrigin")
          span(v-if="!word.value") {{ word.key }}
          a(v-else :href="word.key" target="_blank") {{ word.key }}
      span.show(@click="isShorten = true")  {{ $t('common.show_less') }}
</template>

<script>
export default {
  name: 'TextShortener',
  props: {
    text: {
      type: String,
      default: null
    },
    max: {
      type: Number,
      default: 300
    }
  },
  data () {
    return {
      isShorten: true,
      patternUrl: /(https?:\u002F\u002F[^\s]+)/g
    }
  },

  computed: {
    isShorter () {
      if (!this.text) {
        return true
      }

      return this.text.length < this.max
    },

    processWordsShorten () {
      if (!this.text) {
        return {}
      }

      const chaSpace = ' '
      const etc = '...'

      if (!this.text.includes(chaSpace))
        return this.getText(this.text.slice(0, this.max))
      else
        return this.getText(this.text.slice(0, this.max).split(chaSpace).slice(0, -1).join(chaSpace).concat(etc))
    },

    processWordsOrigin () {
      if (!this.text) {
        return {}
      }
      return this.getText(this.text)
    }
  },

  methods: {
    getText (text) {
      if (!text) {
        return []
      }

      const tokens = text.split(this.patternUrl)
      const myDict = []
      tokens.forEach(token => {
        myDict.push({
          key: token,
          value: token.startsWith('http')
        })
      })
      return myDict
    }
  }
}
</script>

<style lang="scss" scoped>
  .text-shortener {
    word-break: break-word;
    white-space: pre-wrap;
    a {
      color: var(--color-primary-5);
    }
    .show {
      color: var(--color-warning-6);
      cursor: pointer;
      transition: all 1s;
    }
  }
</style>
