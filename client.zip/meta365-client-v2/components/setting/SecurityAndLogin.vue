<template lang="pug">
section.security-and-login
  h3.title.my-8 {{ $t('pages.settings.security') }}
  el-divider.mt-12.mb-20
  el-form(
    ref="passwordForm"
    :model="passwordForm"
    :rules="passwordRules"
    label-width="124px"
    label-position="left"
  )
    InputSetting(
      v-model="passwordForm.password"
      field="password"
      :error="errors.password"
      :loading="loading"
      form-field="password"
      :editable="false"
      :disabled="false"
      @cancel="cancelEditField($event)"
      @editable="changeEditableField($event)"
      @done="saveEditableField($event)"
    )
</template>

<script>
export default {
  component: 'SecurityAndLoginComponent',

  data () {
    return {
      editable: {
        prevValue: '',
        field: ''
      },
      loading: false,
      errors: {},
      passwordForm: {
        password: '**********'
      },
    }
  },

  computed: {
    passwordRules () {
      return {}
    }
  },


  methods: {
    changeEditableField () {
      this.$flows.changePassword({
        parent: this
      })
    },
  }
}
</script>
