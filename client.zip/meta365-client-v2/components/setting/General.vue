<template lang="pug">
div
  section
    h3.title.my-8 {{ $t('pages.settings.general') }}
    el-divider.mt-12.mb-20
    el-form(
      ref="informationForm"
      :model="informationForm"
      :rules="informationRules"
      label-width="124px"
      label-position="left"
    )
      //- el-form-item.form-item-phonenumber(
      //-   prop="phoneNumber"
      //-   :label="$t('field.phoneNumber')"
      //- )
      //-   input-phone-number(
      //-     v-model="informationForm.phoneNumber"
      //-     ref="defaultFocus"
      //-     :placeholder="$t('phoneNumber')"
      //-     @updateCountryCode="updateCountryCode"
      //-     @updatePhoneNumberWithCode="updatePhoneNumberWithCode"
      //-   )
      //- el-form-item(
      //-   prop="username"
      //-   :class="{ editable: editable.field === 'username' }"
      //-   :label="$t('field.username')"
      //- )
      //-   .input
      //-     el-input(
      //-       v-model.trim="informationForm.username"
      //-       :disabled="editable.field !== 'username'"
      //-       :placeholder="$t('field.username')"
      //-     )
      //-   .edit
      //-     span(
      //-       v-if="editable.field !== 'username'"
      //-       @click="changeEditableField('username')"
      //-     ) {{ $t('common.change') }}
      //-     span(
      //-       v-else
      //-       @click="cancelEditField('username')"
      //-     ) {{ $t('common.cancel') }}
      //-   .action-button
      //-     el-button(
      //-       v-if="editable.field === 'username'"
      //-       size="small"
      //-       type="primary"
      //-     ) {{ $t('common.save') }}
      InputSetting(
        v-model="informationForm.username"
        field="username"
        :error="errors.username"
        :loading="loading"
        form-field="username"
        :editable="editable.field === 'username'"
        :disabled="!user.username.includes('#')"
        @cancel="cancelEditField($event)"
        @editable="changeEditableField($event)"
        @done="saveEditableField($event)"
      )
      el-alert(
        :effect="$colorMode.value === 'dark' ? 'dark' : 'light'"
        v-if="editable.field === 'username'"
        :closable="false"
        :title="$t('pages.settings.note')"
        type="info"
      )
        p.my-4 {{ user.username.includes('#') ? $t('pages.settings.username_note_1') : $t('pages.settings.username_note_2') }}
        p.my-4 {{ $t('pages.settings.username_info') }}
        p.my-4 {{ domain }}/
          strong @{{ informationForm.username }}
      InputSetting(
        v-model="informationForm.fullName"
        field="full_name"
        :error="errors.fullName"
        :loading="loading"
        form-field="fullName"
        :editable="editable.field === 'fullName'"
        @cancel="cancelEditField($event)"
        @editable="changeEditableField($event)"
        @done="saveEditableField($event)"
      )
      el-alert(
        :effect="$colorMode.value === 'dark' ? 'dark' : 'light'"
        v-if="editable.field === 'fullName'"
        :closable="false"
        :title="$t('pages.settings.note')"
        type="info"
      )
        p.my-4 {{ $t('pages.settings.full_name_note_1') }}
      InputSetting(
        v-model="informationForm.description"
        type="textarea"
        show-word-limit
        :maxlength="512"
        :loading="loading"
        field="description"
        form-field="description"
        :autosize="{ minRows: 2, maxRows: 4}"
        :editable="editable.field === 'description'"
        @cancel="cancelEditField($event)"
        @editable="changeEditableField($event)"
        @done="saveEditableField($event)"
      )
      el-alert(
        :effect="$colorMode.value === 'dark' ? 'dark' : 'light'"
        v-if="editable.field === 'description'"
        :closable="false"
        :title="$t('pages.settings.note')"
        type="info"
      )
        p.my-4 {{ $t('pages.settings.description_note_1') }}
      InputSetting(
        v-model="informationForm.email"
        field="email"
        :loading="loading"
        form-field="email"
        :error="errors.email"
        :editable="editable.field === 'email'"
        @cancel="cancelEditField($event)"
        @editable="changeEditableField($event)"
        @done="saveEditableField($event)"
      )
        .el-form-item__error(
          slot="error"
          v-if="!user.verifiedEmailAt && editable.field !== 'email'"
        ) {{ $t('notification.error.email_is_not_verified') }}
      el-alert(
        :effect="$colorMode.value === 'dark' ? 'dark' : 'light'"
        v-if="editable.field === 'email'"
        :closable="false"
        :title="$t('pages.settings.note')"
        type="info"
      )
        p.my-4 - {{ $t('pages.settings.email_note_1') }}
        p.my-4 - {{ $t('pages.settings.email_note_2') }}
      InputSetting(
        v-model="informationForm.phoneNumber"
        type="phone"
        field="phoneNumber"
        :error="errors.phoneNumber"
        :loading="loading"
        form-field="phoneNumber"
        :maxlength="9"
        :editable="editable.field === 'phoneNumber'"
        @cancel="cancelEditField($event)"
        @updatePhoneNumberWithCode="updatePhoneNumberWithCode"
        @editable="changeEditableField($event)"
        @done="saveEditableField($event)"
      )
        .el-form-item__error(
          slot="error"
          v-if="!user.verifiedPhoneAt && editable.field !== 'phoneNumber'"
        ) {{ $t('notification.error.phone_number_is_not_verified') }}
      //- el-alert(
      //-   :effect="$colorMode.value === 'dark' ? 'dark' : 'light'"
      //-   v-if="editable.field === 'phoneNumber'"
      //-   :closable="false"
      //-   :title="$t('pages.settings.note')"
      //-   type="info"
      //- )
      //-   p.my-4 {{ $t('pages.settings.full_name_note_1') }}
  section
    h3.title.my-8 {{ $t('pages.settings.identity_verification') }}
    el-divider.mt-12.mb-20
    el-result.p-0.py-6(
      icon='error'
    )
      template(slot="title")
        p {{ $t('pages.settings.error_identity_verification') }}
      template(slot="subTitle")
        el-alert(
          :effect="$colorMode.value === 'dark' ? 'dark' : 'light'"
          :closable="false"
          type="info"
          show-icon
        )
          span.my-4 {{ $t('pages.settings.note_for_identity_verification') }}
      template(slot="extra")
        el-button(
          type='primary'
          size='medium'
          @click.native="onClickKycForm()"
        ) {{ $t('pages.settings.kyc_now')}}
</template>

<script>
import { pick, cloneDeep, trim } from 'lodash'

export default {
  component: 'SettingGeneral',

  props: {
    domain: {
      type: String,
      default: '',
      required: true
    }
  },

  data () {
    return {
      editable: {
        prevValue: '',
        field: ''
      },
      phoneNumberWithCode: '',
      loading: false,
      errors: {},
      informationForm: {
        fullName: '',
        username: '',
        phoneNumber: '',
        country: '',
        email: '',
        birthday: '',
        gender: '',
      },
    }
  },

  computed: {
    user () {
      return this.$auth.user
    },
    informationRules () {
      const defaultRules =  {
        fullName: [
          { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.full_name') }), trigger: ['blur', 'change'] },
          { pattern: /^[^<`!@#$%^&*()_+\-=[\]{};':"|,.<>/?~>]{6,32}$/, message: this.$t('notification.error.form_isnt_valid_pattern_with_length', { field: this.$t('field.full_name'), pattern: 'a-z 0-9 .', min: 6, max: 32 }), trigger: ['change', 'blur'] },
        ],
        username: [
          { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.username') }), trigger: ['blur', 'change'] },
          { pattern: /^[a-zA-Z0-9.]{6,16}$/, message: this.$t('notification.error.form_is_valid_pattern_with_length', { field: this.$t('field.username'), pattern: 'a-z 0-9 .', min: 6, max: 18 }), trigger: ['change', 'blur'] },
        ],
        phoneNumber: [
          { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.phoneNumber') }), trigger: ['blur', 'change'] },
          // { pattern: /([+84|84|0]+(3+[2-9]|5+[6|8|9]|7+[0|6|7|8|9]|8+[1-9]|9+[1-4|6-9]))+([0-9]{7})\b/, message: this.$t('notification.error.phoneNumber_is_invalid', { field: this.$t('field.phoneNumber'), pattern: '0-9' }), trigger: ['change', 'blur'] },
        ],
        email: [
          { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.email') }), trigger: ['blur', 'change'] }
        ]
      }
      return pick(defaultRules, [this.editable.field])
    }
  },

  created () {
    this.informationForm = pick(this.user, ['username', 'email', 'phoneNumber', 'fullName', 'country', 'birthday', 'gender', 'description'])
  },

  methods: {
    changeEditableField (field) {
      const oldField = cloneDeep(this.editable)
      if (oldField && oldField.field) {
        this.$confirm(this.$t('common.not_save', { field: this.$t(`field.${field}`) }), this.$t('common.warning'), {
          confirmButtonText: this.$t('common.confirm'),
          cancelButtonText: this.$t('common.cancel'),
          type: 'warning'
        })
          .then(() => {
            this.informationForm[oldField.field] = this.user[oldField.field]
            this.handleConfirmChangeEditableField(field)
          })
          .catch(() => {})
      } else {
        this.handleConfirmChangeEditableField(field)
      }
    },

    handleConfirmChangeEditableField (field) {
      this.editable = {
        prevValue: cloneDeep(this.informationForm[field]),
        field
      }
      this.clearError()
    },

    updateCountryCode (code) {
      this.informationForm.country = code
    },

    updatePhoneNumberWithCode (phoneNumberWithCode) {
      this.phoneNumberWithCode = phoneNumberWithCode
      this.clearError()
    },

    clearError () {
      this.errors = {}
      this.$nextTick(() => {
        this.$refs.informationForm.clearValidate()
      })
    },

    cancelEditField (field) {
      this.informationForm[field] = this.user[field]
      this.editable = {
        prevValue: '',
        field: ''
      }
      this.clearError()
    },

    saveEditableField (field) {
      this.$refs.informationForm.validate((valid) => {
        if (valid) {
          this.submitChangeProfile(field)
        } else {
          return false
        }
      })
    },

    onClickKycForm () {
      return this.$message({
        type: 'info',
        message: this.$t('common.feature_under_development')
      })
    },

    submitChangeProfile (field) {
      let fieldCanUpdate = null
      if (field === 'phoneNumber') {
        fieldCanUpdate = {
          phoneNumber: this.phoneNumberWithCode
        }
      } else {
        fieldCanUpdate = pick(this.informationForm, [field])
      }
      fieldCanUpdate[field] = trim(fieldCanUpdate[field])
      if (this.informationForm[field] !== fieldCanUpdate[field]) {
        this.informationForm[field] = fieldCanUpdate[field]
      }
      this.clearError()
      this.loading = true
      return this.$api.user.updateProfile(fieldCanUpdate)
        .then(async (res) => {
          await this.$auth.setUser(res.data.user)
          this.cancelEditField(field)
        })
        .catch((error) => {
          const response = error.response
          if(response.status === 422) {
            this.errors = response.data.message.reduce((errors, errorField) => {
              errors[errorField.field] = errorField.message
              return errors
            }, {})
            return this.$notify.error({
              message: this.$t('notification.error.invalid_information_input'),
            })
          }
          this.$notify.error({
            message: response.data.message || this.$t('notification.error.invalid_information_input'),
          })
        })
        .finally(() => {
          this.loading = false
        })
    }
  }
}
</script>
