<template lang="pug">
.project-item
  .clearfix.cover
    nuxt-link(
      :to="{ name: 'project-id', params: { id: project._id } }"
    )
      nuxt-img(
        loading="lazy"
        :src="medias[0]"
        :alt="project.name"
        quality="80"
        format="webp"
        sizes="sm:100vw md:50vw lg:400px"
        @load="onLoadImage"
        @error.native="onErrorImage"
      )
      //- img(
      //-   v-if="loading || error"
      //-   src="/meta365-loading.gif"
      //- )
    //- .image-slot(slot="error")
    //-   i.el-icon-picture-outline
  .project-item__body
    .d-flex
      span.status {{ $t(`components.project_item.${project.phase}`) }}
      el-rate(:value="5" disabled)
    .project-item__info
      nuxt-link(
        :to="{ name: 'project-id', params: { id: project._id } }"
      ).title {{ project.name }}
      i.location
        map-pin-icon.location__icon(size="16")
        span.ml-2 {{ project.detailLocation }}
      .price
        //- span.unit 90M/ m2
        span.dot
        span.area {{ project.totalArea }}
      .description(
        v-html="project.description"
      )
</template>

<script>
import { parseImage } from '@/utilities/helpers'
import { MapPinIcon } from 'vue-feather-icons'

export default {
  name: 'ProjectItem',

  components: {
    MapPinIcon
  },

  props: {
    project: {
      type: Object,
      default: () => ({}),
      required: true
    }
  },

  data () {
    return {
      loading: true,
      error: false
    }
  },

  computed: {
    medias () {
      return this.project?.images.map(item => {
        return parseImage(item)
      })
    }
  },

  watch: {},

  methods: {
    onLoadImage () {
      this.loading = false
    },

    onErrorImage () {
      this.error = true
      this.loading = false
    }
  }
}
</script>

<style lang="scss" scoped>
::v-deep.project-item {
  position: relative;
  border-radius: $--radius-medium;
  background: var(--color-shade-1);
  // padding: 2px;
  box-shadow: rgb(50 50 93 / 20%) 0px 2px 5px -1px, rgb(0 0 0 / 20%) 0px 1px 3px -1px;
  &:hover {
    img {
      transform: scale(1.1);
    }
  }
  .cover {
    height: 200px;
    border-radius: $--radius-medium;
    overflow: hidden;
    a {
      height: inherit;
    }
    img {
      width: 100%;
      transition: all 100ms ease-in;
      box-sizing: border-box;
      height: inherit;
      object-fit: cover;
      &.hidden {
        height: 0;
        width: 0;
      }
      // padding: 1.5px 1.5px 0;
    }
  }
  &__badge {
    background: $--background-color-button-primary;
    position: absolute;
    top: 14px;
    font-size: $--size-base-xs;
    padding: 6px 14px;
    border: 1px solid #4dbbff;
    border-top-right-radius: 8px;
    border-top-left-radius: 4px;
    border-bottom-right-radius: 8px;
    left: -8px;
    box-shadow: 0 2px 12px 2px rgb(0 0 0 / 16%);
    &::after {
      width: 10px;
      height: 10px;
      z-index: -1;
      bottom: -6px;
      position: absolute;
      border-bottom: #4dbbff solid 2px;
      border-left: #4dbbff solid 2px;
      transform: skew(0, 45deg);
      content: '';
      background-color: #4dbbff;
      left: -1px;
    }
  }
  &__body {
    // background-color: $--color-text-primary;
    padding: 10px 0;
    border-bottom-left-radius: 8px;
    border-bottom-right-radius: 8px;
    .d-flex {
      justify-content: space-between;
      .status {
        font-size: $--size-base-xs;
        padding: 3px 8px;
        border-bottom-right-radius: 2px;
        border-top-right-radius: 2px;
        background: $--background-color-button-primary;
      }
      .el-rate {
        &__icon {
          margin-right: 0;
        }
      }
    }
  }
  &__info {
    padding: 10px 10px 0;
    .title {
      font-weight: 500;
      color: var(--color-shade-6);
      text-decoration: none;
      font-size: 20px;
      margin-bottom: 8px;
      @include text-ellipsis(1);
      &:hover {
        color: var(--color-shade-6);
      }
    }
    .description {
      color: var(--color-shade-5);
      min-height: 44px;
      font-size: $--size-base;
      margin: 10px 0;
      line-height: 22px;
      font-weight: 400;
      @include text-ellipsis(2);
      max-height: 50px; // fallback cut-off for Safari if it doesn't recognize -webkit-line-clamp
      line-break: after-white-space;
    }
    .price {
      font-size: $--size-base;
      color: var(--color-shade-5);
    }
    .dot {
      width: 10px;
      height: 10px;
      background-color: var(--color-shade-3);
      display: inline-block;
      margin: 0px 10px 0px 0px;
      border-radius: 50%;
    }
    .location {
      font-size: $--size-base;
      color: var(--color-shade-5);
      @include text-ellipsis(1);
      &__icon {
        stroke: var(--color-primary);
        vertical-align: bottom;
      }
    }
  }
}
</style>
