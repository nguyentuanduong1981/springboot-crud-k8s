<template lang="pug">
el-drawer.share-popup(
  :visible.sync="drawer"
  direction="btt"
  :show-close="false"
  size="160px"
  ref="sharePopup"
  @close="$emit('close')"
)
  template(#title)
    h3.type-title(
      align="center"
    ) {{ $t('pages.profile.share_to') }}
  el-scrollbar(:native="true")
    .d-flex
      client-only
        span(
          data-hover="#ffffff"
        )
          .zalo-share-button(
            :data-href="sharing.url"
            data-oaid="579745863508352884"
            data-layout="icon-text"
            data-color="blue"
            :data-customize="true"
          )
            .flex-column.el-link.el-link--primary
              img.mr-4(
                width="24"
                src="/socials/zalo.svg"
              )
              span.zshare-label Zalo
      span(
        v-clipboard:copy="sharing.url"
        v-clipboard:success="clipboardSuccess"
      )
        .flex-column.el-link.el-link--primary
          LinkIcon
          span.zshare-label Link
      span(
        @click="onClickOpenQrCodeModal()"
      )
        .flex-column.el-link.el-link--primary
          img.mr-4(
              width="24"
              :src="`/socials/qr-code.svg`"
            )
          span {{ $t('common.qr_code') }}
      span(
        v-for="network in networks"
        :key="network.network"
        :data-hover="network.color"
      )
        share-network(
          :style="{ 'text-decoration': 'none' }"
          :network="network.network"
          :url="sharing.url"
          :title="sharing.title"
          :description="sharing.description"
          :quote="sharing.quote"
          :hashtags="sharing.hashtags"
          :twitter-user="sharing.twitterUser"
          @close="closeSharePopup"
        )
          .flex-column.el-link.el-link--primary
            img(
              width="24"
              :src="`/socials/${network.icon}`"
            )
            span {{ network.name }}

  h5.cancel(align="center" @click="onClickCancelShare") {{ $t('common.cancel') }}
</template>

<script>
import { generateUrl } from '@/utilities/helpers'

import {
  LinkIcon,
} from 'vue-feather-icons'

export default {
  name: 'ShareSheet',

  components: {
    LinkIcon
  },

  props: {
    active: {
      type: Boolean,
      default: false
    },

    sharing: {
      type: Object,
      default: () => ({}),
      required: true
    },

    networks: {
      type: Array,
      default: () => ([
        { network: 'email', name: 'Email', icon: 'gmail.svg', color: '#333333' },
        { network: 'facebook', name: 'Facebook', icon: 'facebook.svg', color: '#1877f2' },
        { network: 'linkedin', name: 'LinkedIn', icon: 'linkedin.svg', color: '#007bb5' },
        { network: 'messenger', name: 'Messenger', icon: 'messenger.svg', color: '#0084ff' },
        { network: 'sms', name: 'SMS', icon: 'sms.svg', color: '#333333' },
        { network: 'telegram', name: 'Telegram', icon: 'telegram.svg', color: '#0088cc' },
        { network: 'twitter', name: 'Twitter', icon: 'twitter.svg', color: '#1da1f2' },
      ])
    }
  },

  data () {
    return {
      drawer: false
    }
  },

  watch: {
    active (val) {
      this.drawer = val
    }
  },

  mounted () {
    const script = document.createElement('script')
    script.setAttribute('type', 'text/javascript')
    script.setAttribute('src', 'https://sp.zalo.me/plugins/sdk.js')
    document.body.appendChild(script)
  },

  destroyed() {
    const script = document.getElementsByTagName('script')
    console.log(script)
  },

  methods: {
    clipboardSuccess () {
      this.$message({
        type: 'success',
        message: this.$t('common.copied')
      })
    },

    closeSharePopup(network) {
    },

    onClickCancelShare () {
      this.$emit('close')
      this.$refs.sharePopup.closeDrawer()
    },

    onClickOpenQrCodeModal () {
      this.$flows.qrCode({
        parent: this,
        qr: {
          value: this.sharing.url,
          imagePath: this.avatar || generateUrl('/winking.png', this.domain)
        },
        download: {
          visible: true
        }
      })
    },
  }
}
</script>

<style lang="scss" scoped>
::v-deep.share-popup {
  .el-drawer {
    border-radius: 12px 12px 0 0;
    background-color: var(--color-shade-1);
    &__header {
      padding: 10px;
      .type-title {
        color: var(--color-shade-6);
        margin-bottom: 6px;
        margin-top: 0;
      }
    }
    &__header {
      margin-bottom: 0;
    }
    .el-link {
      height: 64px;
      width: 80px;
    }
    .el-scrollbar {
      .d-flex {
        overflow: inherit;
      }
    }
    .cancel {
      height: 40px;
      margin-bottom: calc(0px + var(--sab));
      margin-top: 4px;
      background-color: rgba(#F9BC15, 0.9);
      display: flex;
      align-items: center;
      justify-content: center;
    }
  }
}
</style>
