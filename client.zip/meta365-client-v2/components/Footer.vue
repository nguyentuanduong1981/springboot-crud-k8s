<template lang="pug">
footer.footer
  .container
    el-row(:gutter="20")
      el-col.footer__left(:sx="24" :sm="8" :md="8")
        el-row(:gutter="16")
          el-col(:span="12")
            h4 {{ $t('footer.customer_service') }}
            p
              nuxt-link(:to="{ name: 'customer-service-help-center' }") {{ $t('footer.help_center') }}
            p
              nuxt-link(:to="{ name: 'customer-service-provider-feedback' }") {{ $t('footer.provider_feedback') }}
            p
              nuxt-link(:to="{ name: 'customer-service-terms-of-service' }") {{ $t('footer.terms_of_service') }}
            p
              nuxt-link(:to="{ name: 'customer-service-privacy-statement' }") {{ $t('footer.privacy_statement') }}
            p
              nuxt-link(:to="{ name: 'customer-service-acceptable-use-policy' }") {{ $t('footer.acceptable_use_policy') }}

          el-col(:span="12")
            h4 {{ $t('footer.our_service') }}
            p {{ $t('footer.vr360_service') }}

      el-col.footer__center(:sx="24" :sm="8" :md="8")
        el-row(:gutter="16")
          el-col(:span="12")
            h4 {{ $t('footer.for_real_estate_enterprises') }}
            p
              nuxt-link(:to="{ name: 'for-real-estate-enterprises-project-listing' }") {{ $t('footer.project_listing') }}
            p
              nuxt-link(:to="{ name: 'for-real-estate-enterprises-memberships' }") {{ $t('footer.memberships') }}
            p
              nuxt-link(:to="{ name: 'for-real-estate-enterprises-learning-center' }") {{ $t('footer.learning_center') }}
            p
              nuxt-link(:to="{ name: 'for-real-estate-enterprises-partner-program' }") {{ $t('footer.partner_program') }}
            p
              nuxt-link(:to="{ name: 'for-real-estate-enterprises-meta365-select' }") {{ $t('footer.meta365_select') }}

          el-col(:span="12")
            h4 {{ $t('footer.for_real_estate_enterprises') }}
            p
              nuxt-link(:to="{ name: 'for-real-estate-brokers-product-listing' }") {{ $t('footer.product_listing') }}
            p
              nuxt-link(:to="{ name: 'for-real-estate-brokers-memberships' }") {{ $t('footer.memberships') }}
            p
              nuxt-link(:to="{ name: 'for-real-estate-brokers-learning-center' }") {{ $t('footer.learning_center') }}
            p
              nuxt-link(:to="{ name: 'for-real-estate-brokers-partner-program' }") {{ $t('footer.partner_program') }}

      el-col.footer__right(:sx="24" :sm="8" :md="8")
        el-row(:gutter="16")
          el-col(:span="12")
            h4 {{ $t('footer.about_us') }}
            p
              a(href="https://meta365.vn/gioi-thieu/") {{ $t('footer.about_meta365') }}
            p {{ $t('footer.about_meta365_group') }}
            p
              a(href="/sitemap.xml") {{ $t('footer.sitemap') }}
            p {{ $t('footer.blog') }}
          el-col(:span="12")
            h4 {{ $t('footer.our_office') }}
            p Hanoi - Vietnam
            p Singapore - Singapore
            p Dubai - UAE
            p United Kingdom

    .mt-6.follow-us
      span {{ $t('footer.follow_us_on') }}
      span.social
        .social__item(
          v-for="i in weOn"
          :key="i.icon"
        )
          a(
            :href="i.href" target="_blank"
          )
            img(:src="`/socials/${i.icon}.svg`")

    el-divider.dark.mt-10.mb-24
    .copyright-and-more.d-flex
      span.copyright {{ $t('footer.copyright') }}
        | © 2021 - {{ (new Date()).getFullYear() }}&nbsp;
        span.text-brand META365&nbsp;
        | Group
        | Power of&nbsp;
        a(href="https://unicornchain.io") UnicornChain
      .d-flex.more
        span {{ $t('pages.home.real_estate_decentralized_exchange') }}
</template>

<script>
export default {
  name: 'Footer',

  data () {
    return {
      weOn: [
        {
          href: 'https://www.facebook.com/meta365land',
          icon: 'facebook-light'
        },
        {
          href: 'https://twitter.com/Meta365Official',
          icon: 'twitter-light'
        },
        {
          href: 'https://www.linkedin.com/company/77119678/',
          icon: 'linkedin-light'
        },
        {
          href: 'https://www.tiktok.com/@meta365.ai',
          icon: 'tiktok-light'
        }
      ]
    }
  }
}
</script>

<style lang="scss" scoped>
.footer {
  color: var(--color-shade-9);
  padding: 40px 0 20px;
  @include media(sm-down) {
    padding: 20px 0 10px;
  }
  h4 {
    color: var(--color-shade-9);
    margin-top: 0;
    font-weight: 700;
    font-size: $--size-base-md;
    margin-bottom: 0.9rem;
  }
  span, p, a {
    font-weight: 400;
    color: var(--color-shade-8);
  }
  a {
    text-decoration: none;
  }
  &__left {
    @include media(sm-down) {
      padding: 20px 10px;
      .description {
        font-size: $--size-base;
      }
    }
    .d-flex {
      img.logo {
        width: 64px;
      }
      flex-direction: column;
    }
    .description {
      margin-top: 10px;
      line-height: 26px;
      color: var(--color-shade-7);
    }
  }
  &__center {
    @include media(sm-down) {
      padding: 10px 10px 20px;
      .info {
        span {
          font-size: $--size-base;
        }
        .label {
          font-size: $--size-base;
        }
      }
    }
    .contact {
      &__item {
        display: flex;
        padding: 6px 0;
        // flex-direction: column;
        align-items: center;
        &:first-child {
          padding-top: 0;
        }
        .feather {
          stroke: #fad55b;
          margin-right: 10px;
          flex-shrink: 0;
        }
        .info {
          margin-left: 10px;
          flex-direction: column;
          justify-content: center;
          line-height: 26px;
          span {
            font-weight: 500;
          }
          .label {
            font-weight: 400;
            color: var(--color-shade-4);
          }
        }
      }
    }
  }
  &__right {
    @include media(sm-down) {
      padding: 20px 10px;
      p {
        font-size: $--size-base;
      }
    }
  }
  .follow-us {
    display: flex;
    justify-content: center;
    align-items: center;
    span {
      font-size: 16px;
    }
    .social {
      display: inline-flex;
      &__item {
        cursor: pointer;
        margin: 4px;
        padding: 6px;
        border-radius: 50%;
        background-color: var(--color-primary-5);
        img {
          width: 18px;
          height: 18px;
        }
        a {
          display: flex;
          justify-content: center;
          align-items: center;
        }
      }
    }
  }
  .copyright-and-more {
    justify-content: space-between;
    font-size: $--size-base;
    .copyright {
      font-weight: 600;
      font-size: $--size-base-md;
      span, a {
        font-weight: 600;
        color: var(--color-warning-5);
      }
    }
    .more {
      span {
        font-weight: 600;
        margin: 0 6px;
        font-size: 16px;
      }
    }
    @include media(xs) {
      flex-direction: column;
      .copyright {
        text-align: center;
        margin-bottom: 4px;
      }
      .more {
        margin-top: 6px;
        justify-content: center;
      }
    }
  }
  }
</style>
