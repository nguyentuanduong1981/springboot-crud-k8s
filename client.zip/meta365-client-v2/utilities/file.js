import { getMimeTypeFromFile } from '@/utilities/helpers'
import { Message } from 'element-ui'
export const FILE_ACCEPT = {
  AUDIOS: 'audio/mp3,audio/mpeg,audio/m4a,audio/x-m4a,audio/wav',
  IMAGES: 'image/jpg,image/jpeg,image/png',
  VIDEOS: 'video/mp4,video/webm,video/quicktime,video/qt,.mov',
  IMAGES_VIDEOS: 'image/jpg,image/jpeg,image/png,image/gif,video/mp4,video/webm,video/quicktime,video/qt,.mov',
  ALL: 'image/jpg,image/jpeg,image/png,image/gif,video/mp4,video/webm,.mp3,video/quicktime,video/qt,.mov'
}
const FILE_TYPES = 'mp3, mpga, mp4, webm, jpg, jpeg, png, gif'
const MAXIMUM_SIZE = 10 * 1024 * 1024
const ERROR = {
  IMAGE_DIMENSION: 'notification.error.upload_file.image',
  NOT_FOUND: 'notification.error.upload_file.file_not_found',
  MAX_FILE_SIZE: 'notification.error.upload_file.maximum_size',
  INVALID_TYPE: 'notification.error.upload_file.valid_type'
}

export class File {
  file
  accept = FILE_ACCEPT.ALL
  maximum = MAXIMUM_SIZE
  dimension
  i18n

  constructor(accept, options, i18n) {
    this.file = {
      src: null,
      type: 'image/png'
    }
    this.accept = accept
    this.maximum = options.maximum
    this.dimension = options.dimension
    this.i18n = i18n
  }

  getFile() {
    return this.file
  }

  async handleUploadEvent (event) {
    const { files } = event.target
    const file = files[0]
    const valid = this.validateFile(file, () => { }, () => { })
    const type = getMimeTypeFromFile(event.target.result, file.type)
    if (!valid) return Promise.reject(new Error('error'))
    if (type.includes('image')) {
      // const dimension = await this.imageDimensions(file)
      // if (dimension.width <= this.dimension.width || dimension.hight <= this.dimension.hight) {
      //   Message.error(this.i18n.$t(ERROR.IMAGE_DIMENSION, {  }))
      //   return
      // }
    }
    return await this.setFile(file)
  }

  async setFile(file) {
    return await new Promise((resolve, reject) => {
      if (!file) reject(new Error(this.i18n.$t(ERROR.NOT_FOUND)))
      if (this.file.src) {
        URL.revokeObjectURL(this.file.src)
      }
      const blob = URL.createObjectURL(file)
      const reader = new FileReader()

      reader.onload = (e) => {
        const object = {
          src: blob,
          type: getMimeTypeFromFile(e.target.result, file.type),
        }
        this.file = object
        resolve(object)
      }
      reader.readAsArrayBuffer(file)
    })
  }

  imageDimensions (file) {
    return new Promise((resolve, reject) => {
      const img = new Image()

      img.onload = () => {
        const { naturalWidth: width, naturalHeight: height } = img
        resolve({ width, height })
      }

      img.onerror = () => {
        reject(new Error('There was some problem with the image.'))
      }

      img.src = URL.createObjectURL(file)
    })
  }

  validateFile(file, onHandlerValid, onHandlerError) {
    let message = null
    const isValidSize = file.size < this.maximum * 1024 * 1024

    if (!isValidSize) {
      message = this.i18n.$t(ERROR.MAX_FILE_SIZE, { maximum: this.maximum })
    }

    const isValidType = this.accept.includes(file.type)
    if (!isValidType) {
      const listTypeAccept = this.getListAcceptType()
      message = this.i18n.$t(ERROR.INVALID_TYPE, { type: listTypeAccept || FILE_TYPES })
    }

    if (message) {
      onHandlerError()
      Message.error(message)
      return false
    }

    onHandlerValid()
    return true
  }

  getListAcceptType() {
    if (!this.accept) {
      return null
    }
    const listType = []

    this.accept.split(',').forEach(element => {
      const type = element.split(/\W/)
      listType.push(type[type.length - 1])
    })

    return listType.join(', ')
  }
}