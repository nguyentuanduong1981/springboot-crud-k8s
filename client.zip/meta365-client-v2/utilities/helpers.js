export function generateUrl(path, customDomain) {
  const appUrl = `${customDomain || process.env.DOMAIN}` || ''
  return appUrl.replace(/\/$/, '') + path
}

export function generateAssetUrl(path, customDomain) {
  const appUrl = `${customDomain || process.env.api}/asset/` || ''
  return appUrl.replace(/\/$/, '') + path
}

export function parseImage(image) {
  if (stringIsHttp(image)) return image
  return generateAssetUrl(`/${image}`)
}

export function stringIsHttp (string) {
  return !!(string.includes('http') || string.includes('https'))
}

export function getMimeTypeFromFile(file, fallback = null) {
  const byteArray = (new Uint8Array(file)).subarray(0, 4)
  let header = ''
  for (let i = 0; i < byteArray.length; i++) {
    header += byteArray[i].toString(16)
  }
  switch (header) {
    case '89504e47':
      return 'image/png'
    case '47494638':
      return 'image/gif'
    case 'ffd8ffe0':
    case 'ffd8ffe1':
    case 'ffd8ffe2':
    case 'ffd8ffe3':
    case 'ffd8ffe8':
      return 'image/jpeg'
    default:
      return fallback
  }
}

/**
* Native scrollTo with callback
* @param offset - offset to scroll to
* @param callback - callback function
*/
export function scrollTo(offset = 0, callback = () => ({})) {
  if(!window) return
  const fixedOffset = offset.toFixed()
  const onScroll = function () {
    if (window.pageYOffset.toFixed() === fixedOffset) {
      window.removeEventListener('scroll', onScroll)
      callback()
    }
  }

  window.addEventListener('scroll', onScroll)
  onScroll()
  window.scrollTo({
    top: offset,
    behavior: 'smooth'
  })
}
