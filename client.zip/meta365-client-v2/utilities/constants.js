export const MEDIA_TYPES = {
  IMAGE: 'image',
  VIDEO: 'video'
}

export const USER_TYPE = {
  NORMAL: 'normal',
  BROKER: 'broker',
  AGENCY: 'agency'
}

export const SITEMAP_EXCLUDE = [
  '/settings/**',
  '/settings',
  '/add-new-product',
  '/forgot-password',
  '/logout',
  '/login',
  '/login/**',
  '/signup',
  '/verify-email'
]

export const DEFAULT_ROUTE = 'index'
