import { joinURL } from 'ufo'

export function getImage(src, { modifiers, baseURL } = {}, { nuxtContext }) {
  baseURL = baseURL  || `${nuxtContext.env.api}/asset/`
  const { width, height, format, fit, ...providerModifiers } = modifiers
  const operations = []
  // process modifiers
  const operationsString = operations.join(',')
  return {
    url: src.includes('https') ? src : joinURL(baseURL, operationsString, src)
  }
}
