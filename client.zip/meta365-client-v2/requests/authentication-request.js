import BaseRequest from './base-request'

export default class extends BaseRequest {

  alias () {
    return 'authentication'
  }

  getPublicAddressAvailability (publicAddress) {
    return this.get(`${this.alias()}/public-address-availability?publicAddress=${publicAddress}`)
  }

  registration (data) {
    return this.post(`${this.alias()}/register`, data)
  }

  registerWithWallet (data) {
    return this.post(`${this.alias()}/register-with-wallet`, data)
  }

  loginWithWallet (data) {
    return this.post(`${this.alias()}/login-with-wallet`, data)
  }

  login (data) {
    return this.post(`${this.alias()}/login`, data)
  }

  loginSocial(type, data) {
    return this.post(`${this.alias()}/social/${type}`, data)
  }
}