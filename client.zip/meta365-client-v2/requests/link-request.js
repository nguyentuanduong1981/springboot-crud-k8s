import BaseRequest from './base-request'

export default class extends BaseRequest {

  alias () {
    return 'link'
  }

  all (query) {
    return this.get(`${this.alias()}`, query)
  }

  checkLinkExisted (id) {
    return this.get(`${this.alias()}/my-link/${id}`)
  }

  getLinkById (id) {
    return this.get(`${this.alias()}/${id}`)
  }

  createLink (data) {
    return this.post(`${this.alias()}`, data)
  }

  deleteLink (id) {
    return this.delete(`${this.alias()}/${id}`)
  }
}
