import BaseRequest from './base-request'

export default class extends BaseRequest {

  alias () {
    return 'agent'
  }

  all (query) {
    return this.get(`${this.alias()}`, query)
  }

  getAgentById (id) {
    return this.get(`${this.alias()}/${id}`)
  }

  requestBecomeAnAgency (data) {
    return this.post('/become-an-agency', data)
  }
}
