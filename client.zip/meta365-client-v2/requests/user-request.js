import BaseRequest from './base-request'

export default class extends BaseRequest {

  alias () {
    return 'user'
  }

  profile (data) {
    return this.get(`${this.alias()}/profile`, data)
  }

  getUserByUsername (username) {
    return this.get(`/${this.alias()}/${username}`)
  }

  updateProfile (data) {
    return this.put(`/${this.alias()}/profile`, data)
  }

  updateAvatar (data) {
    return this.post(`/${this.alias()}/update-avatar`, data)
  }

  updateCover (data) {
    return this.post(`/${this.alias()}/update-cover`, data)
  }

  becomeABroker (data) {
    return this.post(`/${this.alias()}/become-a-broker`, data)
  }

  /**
   * update social links of the current user
   *
   * @param {Array} array of object have key and value
   */
  updateSocialLink (data) {
    return this.put(`/${this.alias()}/profile/social-link`, {
      links: data
    })
  }

  changePassword (data) {
    return this.put(`/${this.alias()}/change-password`, data)
  }

  addFavorite (data) {
    return this.put(`/${this.alias()}/favorite`, data)
  }

  removeFavorite (data) {
    return this.delete(`/${this.alias()}/favorite`, data)
  }
}