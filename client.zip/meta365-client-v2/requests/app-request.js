import BaseRequest from './base-request'

export default class extends BaseRequest {

  alias () {
    return 'app'
  }

  sync () {
    return this.get('/appdata')
  }
}
