export default class {

  constructor (store, $axios) {
    this.$store = store
    this.$axios = $axios
  }

  getVersion () {
    return '/api/v1'
  }

  post (url, data = {}, config = {}) {
    if (config.fetch) {
      return this.sendFetchRequest(url, data, 'POST')
    }
    return this.$axios.$post(this.buildUrl(url), data, config)
  }

  put (url, data = {}, config = {}) {
    if (config.fetch) {
      return this.sendFetchRequest(url, data, 'PUT')
    }
    return this.$axios.$put(this.buildUrl(url), data)
  }

  get (url, data = {}) {
    return this.$axios.$get(this.buildUrl(url), { params: data })
  }

  delete (url, data = {}) {
    return this.$axios.$request({
      method: 'DELETE',
      url: this.buildUrl(url),
      data
    })
  }

  sendFetchRequest (url, data, method) {
    const apiUrl = this.buildUrl(url)

    return window.fetch(
      apiUrl,
      {
        method,
        body: data,
        headers: {
          'Content-Type': 'application/json',
          Authorization: this.$store.$auth.$storage.getUniversal('_token.local')
        },
        credentials: 'include',
        'keep-alive': true
      }
    )
  }

  buildUrl (url) {
    // remove both leading and trailing a slash
    url = url.replace(/^\/+|\/+$/g, '')
    return `${this.getVersion()}/${url}`
  }
}
