import BaseRequest from './base-request'

export default class extends BaseRequest {

  alias () {
    return 'project'
  }

  all (query) {
    return this.get(`${this.alias()}`, query)
  }

  handpicked (query) {
    return this.get(`${this.alias()}/handpicked`, query)
  }

  getCategory (query) {
    return this.get(`${this.alias()}-category`, query)
  }

  getProjectById (id) {
    return this.get(`${this.alias()}/${id}`)
  }

  // Contact form

  createContactForm (data) {
    return this.post('project-contact', data)
  }
}
