import BaseRequest from './base-request'

export default class extends BaseRequest {

  alias () {
    return 'province'
  }

  getAllProvince () {
    return this.get(`${this.alias()}`)
  }

  getWardByProvinceCode (code) {
    return this.get(`${this.alias()}/${code}`)
  }
}