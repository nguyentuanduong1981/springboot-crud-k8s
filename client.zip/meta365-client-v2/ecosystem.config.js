module.exports = {
  apps: [
    {
      name: 'Meta365 Frontend',
      exec_mode: 'cluster',
      instances: 'max',
      script: './node_modules/nuxt/bin/nuxt.js',
      args: 'start',
      // env: {
      //   APP_PORT: 3001
      // }
    }
  ]
}