<template lang="pug">
#app.error
  template
    HeaderBar(framed)
    main#content
      Nuxt
</template>

<script>
export default {
  name: 'ErrorLayout'
}
</script>

<style lang="scss" scoped>
#app.error {
  height: calc(100vh - 100px);
  #content {
    height: 100%;
  }
}
</style>
