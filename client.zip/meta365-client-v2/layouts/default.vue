<template lang="pug">
#app
  template
    HeaderBar(framed)
    main#content(:class="{ margin: light }")
      Nuxt
    el-backtop(
      :bottom="74"
      :right="20"
    )
</template>

<script>
import { omit } from 'lodash'
import { DEFAULT_ROUTE } from '@/utilities/constants'

export default {
  computed: {
    light () {
      return ['index', 'for-real-estate-enterprises', 'for-real-estate-brokers'].includes(this.$route.name)
    }
  },

  watch: {
    '$route.query': {
      // eslint-disable-next-line
      handler: function(query) {
        if (!query['request-login']) return
        return this.requestLoginHandle()
      },
      deep: true,
      immediate: true
    }
  },

  methods: {
    requestLoginHandle () {
      if (process.server || this.$auth.loggedIn) return
      return this.$flows.login({
        parent: this
      })
        .catch(() => {
          return Promise.resolve(true)
        })
        .finally(() => {
          const route = {
            query: omit(this.$route.query, ['request-login'])
          }
          if (['login-checking'].includes(this.$route.name)) {
            route.name = DEFAULT_ROUTE
          }
          return this.$router.replace(route)
        })
    }
  }
}
</script>

<style lang="scss" scoped>
::v-deep#app {
  #header {
    &.lock {
      + #content {
        .el-aside {
          top: 72px;
          height: calc(100vh - 72px);
          transition: top 10ms ease;
          @include media(sm-down) {
            top: 50px;
            height: calc(100vh - 50px);
          }
          &.form-filter {
            .el-form {
              height: calc(100% - 61px);
              // @include media(sm-down) {
              //   height: calc(100vh - 50px);
              // }
            }
          }
        }
      }
    }
  }
  // .el-aside {
  //   &.form-filter {
  //     .el-form {
  //       height: calc(100% - 106px);
  //     }
  //   }
  // }
  #content {
    &.margin {
      margin-top: -118px;
      // @include media(sm-down) {
        // margin-top: -118px;
      // }
    }
  }
  .el-backtop {
    background-color: var(--color-shade-1);
    color: var(--color-warning-5);
  }
}
</style>
