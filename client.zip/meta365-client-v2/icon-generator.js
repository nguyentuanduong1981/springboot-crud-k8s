const fs = require('fs')
const path = require('path')
const svg64 = require('svg64')

const generator = () => {
  const dir = path.join(__dirname, './static/icons')
  if (!fs.existsSync(dir)) {
    return console.error('\x1B[31m', 'Can\'t find folder containing icons, create icons folder in static folder (./static/icons).')
  }
  try {
    const files = fs.readdirSync(dir)
    if (!files.length) {
      return console.warn('\x1B[33m', 'No icon found.')
    }

    const svgs = files
      .filter(i => /.svg$/ig.test(i))
      .map(i => {
        const name = i.split(/.svg$/ig)[0]
        const content = fs.readFileSync(path.join(dir, i), 'utf8')
        const svg = svg64(content)
        return `.meta365-icon[data-icon='${name}']{background-image: url(${svg});mask-image: url(${svg});}`
      })

    const target = path.join(__dirname, './assets/styles/icons.scss')
    fs.writeFileSync(target, svgs.join('\n'), 'utf8')
    console.log('\x1B[32m', 'Icon generated.')
  } catch (e) {
    console.log('\x1B[31m', e)
  }
}

generator()
