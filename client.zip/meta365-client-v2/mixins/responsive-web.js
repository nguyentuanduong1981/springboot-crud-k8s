import MobileDetect from 'mobile-detect'

const RESPONSIVE_WEB_SIZE = 992
const RESPONSIVE_WEB_SIZE_GROUP_PLAY = 768

const FIRST_TIME_KEY = 'first_time_res_web'

export default {
  data () {
    return {
      isResponsiveWeb: false,
      isFirstTimeOnResponsiveWeb: false
    }
  },
  methods: {
    detectResponsiveWeb () {
      const responsiveWebSize = /(connect)/ig.test(this.$route.name) ? RESPONSIVE_WEB_SIZE_GROUP_PLAY : RESPONSIVE_WEB_SIZE
      const md = new MobileDetect(window.navigator.userAgent)
      const isMobileAgent = !!(md.mobile() || md.phone() || md.tablet() || md.match('playstation|xbox'))

      const isMobileSize = window.innerWidth <= responsiveWebSize

      this.isResponsiveWeb = isMobileAgent || isMobileSize
    },

    async detectFirstTimeOnResponsiveWeb () {
      if (!this.isResponsiveWeb) {
        return
      }

      await window.sessionStorage.setItem(FIRST_TIME_KEY, Date.now())
    },

    openInApp () {
      if (!this.isResponsiveWeb) {
        return
      }

      window.location.href = `${process.env.APP_HOST}:${process.env.APP_PORT}`

      const fallbackToStore = () => {
        window.location.replace('market://details?id=com.gamelancer')
      }
      setTimeout(fallbackToStore, 250)
    }
  },
  created () {
    if (process.client) {
      this.isFirstTimeOnResponsiveWeb = !window.sessionStorage.getItem(FIRST_TIME_KEY)
    }
  },
  mounted () {
    this.detectResponsiveWeb()
    this.detectFirstTimeOnResponsiveWeb()
  }
}
