import { setMetaPlugin } from '@nuxtjs/composition-api'

export default setMetaPlugin
