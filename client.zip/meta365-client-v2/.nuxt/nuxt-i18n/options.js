

export const Constants = {
  COMPONENT_OPTIONS_KEY: "nuxtI18n",
  STRATEGIES: {"PREFIX":"prefix","PREFIX_EXCEPT_DEFAULT":"prefix_except_default","PREFIX_AND_DEFAULT":"prefix_and_default","NO_PREFIX":"no_prefix"},
  REDIRECT_ON_OPTIONS: {"ALL":"all","ROOT":"root","NO_PREFIX":"no prefix"},
}
export const nuxtOptions = {
  isUniversalMode: true,
  trailingSlash: undefined,
}
export const options = {
  vueI18n: {},
  vueI18nLoader: false,
  locales: [{"code":"vi","name":"Vietnamese","file":"vi/index.js","iso":"vi-VN"},{"code":"en","name":"English","file":"en/index.js","iso":"en-US"}],
  defaultLocale: "vi",
  defaultDirection: "ltr",
  routesNameSeparator: "___",
  defaultLocaleRouteNameSuffix: "default",
  sortRoutes: true,
  strategy: "no_prefix",
  lazy: true,
  langDir: "/var/www/meta365-client-v2/locales",
  rootRedirect: null,
  detectBrowserLanguage: {"alwaysRedirect":true,"cookieCrossOrigin":false,"cookieDomain":null,"cookieKey":"i18n_redirected","cookieSecure":false,"fallbackLocale":"","redirectOn":"root","useCookie":true,"onlyOnRoot":true},
  differentDomains: false,
  baseUrl: "",
  vuex: {"moduleName":"i18n","syncRouteParams":true},
  parsePages: true,
  pages: {},
  skipSettingLocaleOnNavigate: false,
  onBeforeLanguageSwitch: () => {},
  onLanguageSwitched: () => null,
  normalizedLocales: [{"code":"vi","name":"Vietnamese","file":"vi/index.js","iso":"vi-VN"},{"code":"en","name":"English","file":"en/index.js","iso":"en-US"}],
  localeCodes: ["vi","en"],
  additionalMessages: [],
}

export const localeMessages = {
  'vi/index.js': () => import('../../locales/vi/index.js' /* webpackChunkName: "lang-vi/index.js" */),
  'en/index.js': () => import('../../locales/en/index.js' /* webpackChunkName: "lang-en/index.js" */),
}
