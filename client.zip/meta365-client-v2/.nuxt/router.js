import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _475758cb = () => interopDefault(import('../pages/agent/index.vue' /* webpackChunkName: "pages/agent/index" */))
const _02def4ec = () => interopDefault(import('../pages/for-real-estate-brokers/index.vue' /* webpackChunkName: "pages/for-real-estate-brokers/index" */))
const _5c212282 = () => interopDefault(import('../pages/for-real-estate-enterprises/index.vue' /* webpackChunkName: "pages/for-real-estate-enterprises/index" */))
const _4999d2ea = () => interopDefault(import('../pages/login-checking.vue' /* webpackChunkName: "pages/login-checking" */))
const _7de02451 = () => interopDefault(import('../pages/marketplace/index.vue' /* webpackChunkName: "pages/marketplace/index" */))
const _49086dc2 = () => interopDefault(import('../pages/project/index.vue' /* webpackChunkName: "pages/project/index" */))
const _22c276b3 = () => interopDefault(import('../pages/settings/index.vue' /* webpackChunkName: "pages/settings/index" */))
const _c888dd98 = () => interopDefault(import('../pages/user-profile.vue' /* webpackChunkName: "pages/user-profile" */))
const _ceb28e72 = () => interopDefault(import('../pages/customer-service/acceptable-use-policy.vue' /* webpackChunkName: "pages/customer-service/acceptable-use-policy" */))
const _470f84a5 = () => interopDefault(import('../pages/customer-service/help-center.vue' /* webpackChunkName: "pages/customer-service/help-center" */))
const _6033ffa4 = () => interopDefault(import('../pages/customer-service/privacy-statement.vue' /* webpackChunkName: "pages/customer-service/privacy-statement" */))
const _52540f25 = () => interopDefault(import('../pages/customer-service/provider-feedback.vue' /* webpackChunkName: "pages/customer-service/provider-feedback" */))
const _44e36e31 = () => interopDefault(import('../pages/customer-service/terms-of-service.vue' /* webpackChunkName: "pages/customer-service/terms-of-service" */))
const _7fe5c19c = () => interopDefault(import('../pages/for-real-estate-brokers/learning-center.vue' /* webpackChunkName: "pages/for-real-estate-brokers/learning-center" */))
const _220bba95 = () => interopDefault(import('../pages/for-real-estate-brokers/memberships.vue' /* webpackChunkName: "pages/for-real-estate-brokers/memberships" */))
const _01ceecb7 = () => interopDefault(import('../pages/for-real-estate-brokers/partner-program.vue' /* webpackChunkName: "pages/for-real-estate-brokers/partner-program" */))
const _79c9765e = () => interopDefault(import('../pages/for-real-estate-brokers/product-listing.vue' /* webpackChunkName: "pages/for-real-estate-brokers/product-listing" */))
const _781eeed8 = () => interopDefault(import('../pages/for-real-estate-enterprises/learning-center.vue' /* webpackChunkName: "pages/for-real-estate-enterprises/learning-center" */))
const _c27e84e6 = () => interopDefault(import('../pages/for-real-estate-enterprises/memberships.vue' /* webpackChunkName: "pages/for-real-estate-enterprises/memberships" */))
const _7074803c = () => interopDefault(import('../pages/for-real-estate-enterprises/meta365-select.vue' /* webpackChunkName: "pages/for-real-estate-enterprises/meta365-select" */))
const _45d9b3af = () => interopDefault(import('../pages/for-real-estate-enterprises/partner-program.vue' /* webpackChunkName: "pages/for-real-estate-enterprises/partner-program" */))
const _6988cc80 = () => interopDefault(import('../pages/for-real-estate-enterprises/project-listing.vue' /* webpackChunkName: "pages/for-real-estate-enterprises/project-listing" */))
const _1df11636 = () => interopDefault(import('../pages/agent/_id/index.vue' /* webpackChunkName: "pages/agent/_id/index" */))
const _349709c7 = () => interopDefault(import('../pages/embed/_id.vue' /* webpackChunkName: "pages/embed/_id" */))
const _2efd3c8a = () => interopDefault(import('../pages/project/_id/index.vue' /* webpackChunkName: "pages/project/_id/index" */))
const _18a4a702 = () => interopDefault(import('../pages/sale/_id.vue' /* webpackChunkName: "pages/sale/_id" */))
const _54ca5f95 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))
const _18348c9c = () => interopDefault(import('../pages/user-profile' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/agent",
    component: _475758cb,
    name: "agent"
  }, {
    path: "/for-real-estate-brokers",
    component: _02def4ec,
    name: "for-real-estate-brokers"
  }, {
    path: "/for-real-estate-enterprises",
    component: _5c212282,
    name: "for-real-estate-enterprises"
  }, {
    path: "/login-checking",
    component: _4999d2ea,
    name: "login-checking"
  }, {
    path: "/marketplace",
    component: _7de02451,
    name: "marketplace"
  }, {
    path: "/project",
    component: _49086dc2,
    name: "project"
  }, {
    path: "/settings",
    component: _22c276b3,
    name: "settings"
  }, {
    path: "/user-profile",
    component: _c888dd98,
    name: "user-profile"
  }, {
    path: "/customer-service/acceptable-use-policy",
    component: _ceb28e72,
    name: "customer-service-acceptable-use-policy"
  }, {
    path: "/customer-service/help-center",
    component: _470f84a5,
    name: "customer-service-help-center"
  }, {
    path: "/customer-service/privacy-statement",
    component: _6033ffa4,
    name: "customer-service-privacy-statement"
  }, {
    path: "/customer-service/provider-feedback",
    component: _52540f25,
    name: "customer-service-provider-feedback"
  }, {
    path: "/customer-service/terms-of-service",
    component: _44e36e31,
    name: "customer-service-terms-of-service"
  }, {
    path: "/for-real-estate-brokers/learning-center",
    component: _7fe5c19c,
    name: "for-real-estate-brokers-learning-center"
  }, {
    path: "/for-real-estate-brokers/memberships",
    component: _220bba95,
    name: "for-real-estate-brokers-memberships"
  }, {
    path: "/for-real-estate-brokers/partner-program",
    component: _01ceecb7,
    name: "for-real-estate-brokers-partner-program"
  }, {
    path: "/for-real-estate-brokers/product-listing",
    component: _79c9765e,
    name: "for-real-estate-brokers-product-listing"
  }, {
    path: "/for-real-estate-enterprises/learning-center",
    component: _781eeed8,
    name: "for-real-estate-enterprises-learning-center"
  }, {
    path: "/for-real-estate-enterprises/memberships",
    component: _c27e84e6,
    name: "for-real-estate-enterprises-memberships"
  }, {
    path: "/for-real-estate-enterprises/meta365-select",
    component: _7074803c,
    name: "for-real-estate-enterprises-meta365-select"
  }, {
    path: "/for-real-estate-enterprises/partner-program",
    component: _45d9b3af,
    name: "for-real-estate-enterprises-partner-program"
  }, {
    path: "/for-real-estate-enterprises/project-listing",
    component: _6988cc80,
    name: "for-real-estate-enterprises-project-listing"
  }, {
    path: "/agent/:id",
    component: _1df11636,
    name: "agent-id"
  }, {
    path: "/embed/:id?",
    component: _349709c7,
    name: "embed-id"
  }, {
    path: "/project/:id",
    component: _2efd3c8a,
    name: "project-id"
  }, {
    path: "/sale/:id?",
    component: _18a4a702,
    name: "sale-id"
  }, {
    path: "/",
    component: _54ca5f95,
    name: "index"
  }, {
    path: "/@:username",
    component: _18348c9c,
    name: "_user-profile"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
