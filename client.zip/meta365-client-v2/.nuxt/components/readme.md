# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<CopyComponent>` | `<copy-component>` (components/CopyComponent.vue)
- `<ElTooltipTheme>` | `<el-tooltip-theme>` (components/ElTooltipTheme.vue)
- `<Footer>` | `<footer>` (components/Footer.vue)
- `<GalleryList>` | `<gallery-list>` (components/GalleryList.vue)
- `<HeaderBar>` | `<header-bar>` (components/HeaderBar.vue)
- `<Pagination>` | `<pagination>` (components/Pagination.vue)
- `<ParticlesCanvas>` | `<particles-canvas>` (components/ParticlesCanvas.vue)
- `<PartnerAndCustomer>` | `<partner-and-customer>` (components/PartnerAndCustomer.vue)
- `<ProjectCard>` | `<project-card>` (components/ProjectCard.vue)
- `<ProjectItem>` | `<project-item>` (components/ProjectItem.vue)
- `<ShareSheet>` | `<share-sheet>` (components/ShareSheet.vue)
- `<Table>` | `<table>` (components/Table.vue)
- `<TextShortener>` | `<text-shortener>` (components/TextShortener.vue)
- `<UserCard>` | `<user-card>` (components/UserCard.vue)
- `<ChartLine>` | `<chart-line>` (components/chart/Line.vue)
- `<ChartPie>` | `<chart-pie>` (components/chart/Pie.vue)
- `<CommonMarketPlaceFilter>` | `<common-market-place-filter>` (components/common/MarketPlaceFilter.vue)
- `<CommonProjectFilters>` | `<common-project-filters>` (components/common/ProjectFilters.vue)
- `<CommonTagEditable>` | `<common-tag-editable>` (components/common/TagEditable.vue)
- `<InputFile>` | `<input-file>` (components/input/File.vue)
- `<InputPhoneNumber>` | `<input-phone-number>` (components/input/PhoneNumber.vue)
- `<InputSetting>` | `<input-setting>` (components/input/Setting.vue)
- `<SettingGeneral>` | `<setting-general>` (components/setting/General.vue)
- `<SettingSecurityAndLogin>` | `<setting-security-and-login>` (components/setting/SecurityAndLogin.vue)
- `<TabProjectAgency>` | `<tab-project-agency>` (components/tab/ProjectAgency.vue)
- `<TabProjectInfo>` | `<tab-project-info>` (components/tab/ProjectInfo.vue)
