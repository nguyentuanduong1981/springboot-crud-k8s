export const CopyComponent = () => import('../../components/CopyComponent.vue' /* webpackChunkName: "components/copy-component" */).then(c => wrapFunctional(c.default || c))
export const ElTooltipTheme = () => import('../../components/ElTooltipTheme.vue' /* webpackChunkName: "components/el-tooltip-theme" */).then(c => wrapFunctional(c.default || c))
export const Footer = () => import('../../components/Footer.vue' /* webpackChunkName: "components/footer" */).then(c => wrapFunctional(c.default || c))
export const GalleryList = () => import('../../components/GalleryList.vue' /* webpackChunkName: "components/gallery-list" */).then(c => wrapFunctional(c.default || c))
export const HeaderBar = () => import('../../components/HeaderBar.vue' /* webpackChunkName: "components/header-bar" */).then(c => wrapFunctional(c.default || c))
export const Pagination = () => import('../../components/Pagination.vue' /* webpackChunkName: "components/pagination" */).then(c => wrapFunctional(c.default || c))
export const ParticlesCanvas = () => import('../../components/ParticlesCanvas.vue' /* webpackChunkName: "components/particles-canvas" */).then(c => wrapFunctional(c.default || c))
export const PartnerAndCustomer = () => import('../../components/PartnerAndCustomer.vue' /* webpackChunkName: "components/partner-and-customer" */).then(c => wrapFunctional(c.default || c))
export const ProjectCard = () => import('../../components/ProjectCard.vue' /* webpackChunkName: "components/project-card" */).then(c => wrapFunctional(c.default || c))
export const ProjectItem = () => import('../../components/ProjectItem.vue' /* webpackChunkName: "components/project-item" */).then(c => wrapFunctional(c.default || c))
export const ShareSheet = () => import('../../components/ShareSheet.vue' /* webpackChunkName: "components/share-sheet" */).then(c => wrapFunctional(c.default || c))
export const Table = () => import('../../components/Table.vue' /* webpackChunkName: "components/table" */).then(c => wrapFunctional(c.default || c))
export const TextShortener = () => import('../../components/TextShortener.vue' /* webpackChunkName: "components/text-shortener" */).then(c => wrapFunctional(c.default || c))
export const UserCard = () => import('../../components/UserCard.vue' /* webpackChunkName: "components/user-card" */).then(c => wrapFunctional(c.default || c))
export const ChartLine = () => import('../../components/chart/Line.vue' /* webpackChunkName: "components/chart-line" */).then(c => wrapFunctional(c.default || c))
export const ChartPie = () => import('../../components/chart/Pie.vue' /* webpackChunkName: "components/chart-pie" */).then(c => wrapFunctional(c.default || c))
export const CommonMarketPlaceFilter = () => import('../../components/common/MarketPlaceFilter.vue' /* webpackChunkName: "components/common-market-place-filter" */).then(c => wrapFunctional(c.default || c))
export const CommonProjectFilters = () => import('../../components/common/ProjectFilters.vue' /* webpackChunkName: "components/common-project-filters" */).then(c => wrapFunctional(c.default || c))
export const CommonTagEditable = () => import('../../components/common/TagEditable.vue' /* webpackChunkName: "components/common-tag-editable" */).then(c => wrapFunctional(c.default || c))
export const InputFile = () => import('../../components/input/File.vue' /* webpackChunkName: "components/input-file" */).then(c => wrapFunctional(c.default || c))
export const InputPhoneNumber = () => import('../../components/input/PhoneNumber.vue' /* webpackChunkName: "components/input-phone-number" */).then(c => wrapFunctional(c.default || c))
export const InputSetting = () => import('../../components/input/Setting.vue' /* webpackChunkName: "components/input-setting" */).then(c => wrapFunctional(c.default || c))
export const SettingGeneral = () => import('../../components/setting/General.vue' /* webpackChunkName: "components/setting-general" */).then(c => wrapFunctional(c.default || c))
export const SettingSecurityAndLogin = () => import('../../components/setting/SecurityAndLogin.vue' /* webpackChunkName: "components/setting-security-and-login" */).then(c => wrapFunctional(c.default || c))
export const TabProjectAgency = () => import('../../components/tab/ProjectAgency.vue' /* webpackChunkName: "components/tab-project-agency" */).then(c => wrapFunctional(c.default || c))
export const TabProjectInfo = () => import('../../components/tab/ProjectInfo.vue' /* webpackChunkName: "components/tab-project-info" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
