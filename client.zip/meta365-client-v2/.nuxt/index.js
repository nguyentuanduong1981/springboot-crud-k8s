import Vue from 'vue'
import Vuex from 'vuex'
import Meta from 'vue-meta'
import ClientOnly from 'vue-client-only'
import NoSsr from 'vue-no-ssr'
import { createRouter } from './router.js'
import NuxtChild from './components/nuxt-child.js'
import NuxtError from '../layouts/error.vue'
import Nuxt from './components/nuxt.js'
import App from './App.js'
import { setContext, getLocation, getRouteData, normalizeError } from './utils'
import { createStore } from './store.js'

/* Plugins */

import nuxt_plugin_plugin_b8a4645a from 'nuxt_plugin_plugin_b8a4645a' // Source: ./components/plugin.js (mode: 'all')
import nuxt_plugin_plugin_49f1470a from 'nuxt_plugin_plugin_49f1470a' // Source: ./composition-api/plugin.mjs (mode: 'all')
import nuxt_plugin_vuesocialsharingplugin_5bfd6c3c from 'nuxt_plugin_vuesocialsharingplugin_5bfd6c3c' // Source: ./vue-social-sharing-plugin.js (mode: 'all')
import nuxt_plugin_image_7a56da64 from 'nuxt_plugin_image_7a56da64' // Source: ./image.js (mode: 'all')
import nuxt_plugin_pluginutils_473c201c from 'nuxt_plugin_pluginutils_473c201c' // Source: ./nuxt-i18n/plugin.utils.js (mode: 'all')
import nuxt_plugin_pluginrouting_01a648bd from 'nuxt_plugin_pluginrouting_01a648bd' // Source: ./nuxt-i18n/plugin.routing.js (mode: 'all')
import nuxt_plugin_pluginmain_cb56b85c from 'nuxt_plugin_pluginmain_cb56b85c' // Source: ./nuxt-i18n/plugin.main.js (mode: 'all')
import nuxt_plugin_workbox_7c9e9c45 from 'nuxt_plugin_workbox_7c9e9c45' // Source: ./workbox.js (mode: 'client')
import nuxt_plugin_metaplugin_6a0dce58 from 'nuxt_plugin_metaplugin_6a0dce58' // Source: ./pwa/meta.plugin.js (mode: 'all')
import nuxt_plugin_iconplugin_6eb573cc from 'nuxt_plugin_iconplugin_6eb573cc' // Source: ./pwa/icon.plugin.js (mode: 'all')
import nuxt_plugin_axios_e160452e from 'nuxt_plugin_axios_e160452e' // Source: ./axios.js (mode: 'all')
import nuxt_plugin_pluginserver_0d2ea633 from 'nuxt_plugin_pluginserver_0d2ea633' // Source: ./color-mode/plugin.server.js (mode: 'server')
import nuxt_plugin_pluginclient_b11596aa from 'nuxt_plugin_pluginclient_b11596aa' // Source: ./color-mode/plugin.client.js (mode: 'client')
import nuxt_plugin_elementui_d905880e from 'nuxt_plugin_elementui_d905880e' // Source: ../plugins/element-ui (mode: 'all')
import nuxt_plugin_i18n_926bd3dc from 'nuxt_plugin_i18n_926bd3dc' // Source: ../plugins/i18n (mode: 'all')
import nuxt_plugin_flows_226a0791 from 'nuxt_plugin_flows_226a0791' // Source: ../plugins/flows (mode: 'all')
import nuxt_plugin_axios_2228ef02 from 'nuxt_plugin_axios_2228ef02' // Source: ../plugins/axios (mode: 'all')
import nuxt_plugin_api_caeae0b4 from 'nuxt_plugin_api_caeae0b4' // Source: ../plugins/api (mode: 'all')
import nuxt_plugin_clientOnly_9a4501ea from 'nuxt_plugin_clientOnly_9a4501ea' // Source: ../plugins/clientOnly (mode: 'client')
import nuxt_plugin_workspaces_720f7b72 from 'nuxt_plugin_workspaces_720f7b72' // Source: ../plugins/workspaces (mode: 'client')
import nuxt_plugin_directives_7e8ad6f8 from 'nuxt_plugin_directives_7e8ad6f8' // Source: ../plugins/directives (mode: 'all')
import nuxt_plugin_sfx_caea5bde from 'nuxt_plugin_sfx_caea5bde' // Source: ../plugins/sfx (mode: 'client')
import nuxt_plugin_ga_170fd464 from 'nuxt_plugin_ga_170fd464' // Source: ../plugins/ga (mode: 'client')
import nuxt_plugin_auth_18ddfaa7 from 'nuxt_plugin_auth_18ddfaa7' // Source: ./auth.js (mode: 'all')
import nuxt_plugin_authredirect_4c47342c from 'nuxt_plugin_authredirect_4c47342c' // Source: ../plugins/auth-redirect.js (mode: 'all')
import nuxt_plugin_meta_7e821a4d from 'nuxt_plugin_meta_7e821a4d' // Source: ./composition-api/meta.mjs (mode: 'all')

// Component: <ClientOnly>
Vue.component(ClientOnly.name, ClientOnly)

// TODO: Remove in Nuxt 3: <NoSsr>
Vue.component(NoSsr.name, {
  ...NoSsr,
  render (h, ctx) {
    if (process.client && !NoSsr._warned) {
      NoSsr._warned = true

      console.warn('<no-ssr> has been deprecated and will be removed in Nuxt 3, please use <client-only> instead')
    }
    return NoSsr.render(h, ctx)
  }
})

// Component: <NuxtChild>
Vue.component(NuxtChild.name, NuxtChild)
Vue.component('NChild', NuxtChild)

// Component NuxtLink is imported in server.js or client.js

// Component: <Nuxt>
Vue.component(Nuxt.name, Nuxt)

Object.defineProperty(Vue.prototype, '$nuxt', {
  get() {
    const globalNuxt = this.$root.$options.$nuxt
    if (process.client && !globalNuxt && typeof window !== 'undefined') {
      return window.$nuxt
    }
    return globalNuxt
  },
  configurable: true
})

Vue.use(Meta, {"keyName":"head","attribute":"data-n-head","ssrAttribute":"data-n-head-ssr","tagIDKeyName":"hid"})

const defaultTransition = {"name":"page","mode":"out-in","appear":false,"appearClass":"appear","appearActiveClass":"appear-active","appearToClass":"appear-to"}

const originalRegisterModule = Vuex.Store.prototype.registerModule

function registerModule (path, rawModule, options = {}) {
  const preserveState = process.client && (
    Array.isArray(path)
      ? !!path.reduce((namespacedState, path) => namespacedState && namespacedState[path], this.state)
      : path in this.state
  )
  return originalRegisterModule.call(this, path, rawModule, { preserveState, ...options })
}

async function createApp(ssrContext, config = {}) {
  const router = await createRouter(ssrContext, config)

  const store = createStore(ssrContext)
  // Add this.$router into store actions/mutations
  store.$router = router

  // Fix SSR caveat https://github.com/nuxt/nuxt.js/issues/3757#issuecomment-414689141
  store.registerModule = registerModule

  // Create Root instance

  // here we inject the router and store to all child components,
  // making them available everywhere as `this.$router` and `this.$store`.
  const app = {
    head: {"titleTemplate":"%s | Meta365","title":"Meta365","meta":[{"charset":"utf-8"},{"name":"viewport","content":"width=device-width, height=device-height, initial-scale=1, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, viewport-fit=cover"},{"hid":"description","name":"description","content":"Meta365"},{"hid":"description","name":"theme-color","content":"#f9bc15"},{"name":"msapplication-TileColor","content":"#282828"},{"name":"format-detection","content":"telephone=no"},{"name":"google-site-verification","content":"trSKiHXMAuhfmvsmNI0FxIv5yzuhWuIh1QR2DnYzZps"},{"hid":"apple-mobile-web-app-capable","name":"apple-mobile-web-app-capable","content":"yes"}],"link":[{"rel":"icon","type":"image\u002Fx-icon","href":"\u002Ffavicon.ico"},{"rel":"alternate","hreflang":"x"},{"rel":"preconnect","href":"https:\u002F\u002Ffonts.googleapis.com"},{"rel":"preconnect","href":"https:\u002F\u002Ffonts.gstatic.com","crossorigin":"crossorigin"},{"rel":"stylesheet","href":"https:\u002F\u002Ffonts.googleapis.com\u002Fcss2?family=Barlow:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Roboto:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap"}],"script":[{"src":"https:\u002F\u002Fcdn.polyfill.io\u002Fv3\u002Fpolyfill.min.js","body":true}],"style":[]},

    store,
    router,
    nuxt: {
      defaultTransition,
      transitions: [defaultTransition],
      setTransitions (transitions) {
        if (!Array.isArray(transitions)) {
          transitions = [transitions]
        }
        transitions = transitions.map((transition) => {
          if (!transition) {
            transition = defaultTransition
          } else if (typeof transition === 'string') {
            transition = Object.assign({}, defaultTransition, { name: transition })
          } else {
            transition = Object.assign({}, defaultTransition, transition)
          }
          return transition
        })
        this.$options.nuxt.transitions = transitions
        return transitions
      },

      err: null,
      dateErr: null,
      error (err) {
        err = err || null
        app.context._errored = Boolean(err)
        err = err ? normalizeError(err) : null
        let nuxt = app.nuxt // to work with @vue/composition-api, see https://github.com/nuxt/nuxt.js/issues/6517#issuecomment-573280207
        if (this) {
          nuxt = this.nuxt || this.$options.nuxt
        }
        nuxt.dateErr = Date.now()
        nuxt.err = err
        // Used in src/server.js
        if (ssrContext) {
          ssrContext.nuxt.error = err
        }
        return err
      }
    },
    ...App
  }

  // Make app available into store via this.app
  store.app = app

  const next = ssrContext ? ssrContext.next : location => app.router.push(location)
  // Resolve route
  let route
  if (ssrContext) {
    route = router.resolve(ssrContext.url).route
  } else {
    const path = getLocation(router.options.base, router.options.mode)
    route = router.resolve(path).route
  }

  // Set context to app.context
  await setContext(app, {
    store,
    route,
    next,
    error: app.nuxt.error.bind(app),
    payload: ssrContext ? ssrContext.payload : undefined,
    req: ssrContext ? ssrContext.req : undefined,
    res: ssrContext ? ssrContext.res : undefined,
    beforeRenderFns: ssrContext ? ssrContext.beforeRenderFns : undefined,
    ssrContext
  })

  function inject(key, value) {
    if (!key) {
      throw new Error('inject(key, value) has no key provided')
    }
    if (value === undefined) {
      throw new Error(`inject('${key}', value) has no value provided`)
    }

    key = '$' + key
    // Add into app
    app[key] = value
    // Add into context
    if (!app.context[key]) {
      app.context[key] = value
    }

    // Add into store
    store[key] = app[key]

    // Check if plugin not already installed
    const installKey = '__nuxt_' + key + '_installed__'
    if (Vue[installKey]) {
      return
    }
    Vue[installKey] = true
    // Call Vue.use() to install the plugin into vm
    Vue.use(() => {
      if (!Object.prototype.hasOwnProperty.call(Vue.prototype, key)) {
        Object.defineProperty(Vue.prototype, key, {
          get () {
            return this.$root.$options[key]
          }
        })
      }
    })
  }

  // Inject runtime config as $config
  inject('config', config)

  if (process.client) {
    // Replace store state before plugins execution
    if (window.__NUXT__ && window.__NUXT__.state) {
      store.replaceState(window.__NUXT__.state)
    }
  }

  // Add enablePreview(previewData = {}) in context for plugins
  if (process.static && process.client) {
    app.context.enablePreview = function (previewData = {}) {
      app.previewData = Object.assign({}, previewData)
      inject('preview', previewData)
    }
  }
  // Plugin execution

  if (typeof nuxt_plugin_plugin_b8a4645a === 'function') {
    await nuxt_plugin_plugin_b8a4645a(app.context, inject)
  }

  if (typeof nuxt_plugin_plugin_49f1470a === 'function') {
    await nuxt_plugin_plugin_49f1470a(app.context, inject)
  }

  if (typeof nuxt_plugin_vuesocialsharingplugin_5bfd6c3c === 'function') {
    await nuxt_plugin_vuesocialsharingplugin_5bfd6c3c(app.context, inject)
  }

  if (typeof nuxt_plugin_image_7a56da64 === 'function') {
    await nuxt_plugin_image_7a56da64(app.context, inject)
  }

  if (typeof nuxt_plugin_pluginutils_473c201c === 'function') {
    await nuxt_plugin_pluginutils_473c201c(app.context, inject)
  }

  if (typeof nuxt_plugin_pluginrouting_01a648bd === 'function') {
    await nuxt_plugin_pluginrouting_01a648bd(app.context, inject)
  }

  if (typeof nuxt_plugin_pluginmain_cb56b85c === 'function') {
    await nuxt_plugin_pluginmain_cb56b85c(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_workbox_7c9e9c45 === 'function') {
    await nuxt_plugin_workbox_7c9e9c45(app.context, inject)
  }

  if (typeof nuxt_plugin_metaplugin_6a0dce58 === 'function') {
    await nuxt_plugin_metaplugin_6a0dce58(app.context, inject)
  }

  if (typeof nuxt_plugin_iconplugin_6eb573cc === 'function') {
    await nuxt_plugin_iconplugin_6eb573cc(app.context, inject)
  }

  if (typeof nuxt_plugin_axios_e160452e === 'function') {
    await nuxt_plugin_axios_e160452e(app.context, inject)
  }

  if (process.server && typeof nuxt_plugin_pluginserver_0d2ea633 === 'function') {
    await nuxt_plugin_pluginserver_0d2ea633(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_pluginclient_b11596aa === 'function') {
    await nuxt_plugin_pluginclient_b11596aa(app.context, inject)
  }

  if (typeof nuxt_plugin_elementui_d905880e === 'function') {
    await nuxt_plugin_elementui_d905880e(app.context, inject)
  }

  if (typeof nuxt_plugin_i18n_926bd3dc === 'function') {
    await nuxt_plugin_i18n_926bd3dc(app.context, inject)
  }

  if (typeof nuxt_plugin_flows_226a0791 === 'function') {
    await nuxt_plugin_flows_226a0791(app.context, inject)
  }

  if (typeof nuxt_plugin_axios_2228ef02 === 'function') {
    await nuxt_plugin_axios_2228ef02(app.context, inject)
  }

  if (typeof nuxt_plugin_api_caeae0b4 === 'function') {
    await nuxt_plugin_api_caeae0b4(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_clientOnly_9a4501ea === 'function') {
    await nuxt_plugin_clientOnly_9a4501ea(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_workspaces_720f7b72 === 'function') {
    await nuxt_plugin_workspaces_720f7b72(app.context, inject)
  }

  if (typeof nuxt_plugin_directives_7e8ad6f8 === 'function') {
    await nuxt_plugin_directives_7e8ad6f8(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_sfx_caea5bde === 'function') {
    await nuxt_plugin_sfx_caea5bde(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_ga_170fd464 === 'function') {
    await nuxt_plugin_ga_170fd464(app.context, inject)
  }

  if (typeof nuxt_plugin_auth_18ddfaa7 === 'function') {
    await nuxt_plugin_auth_18ddfaa7(app.context, inject)
  }

  if (typeof nuxt_plugin_authredirect_4c47342c === 'function') {
    await nuxt_plugin_authredirect_4c47342c(app.context, inject)
  }

  if (typeof nuxt_plugin_meta_7e821a4d === 'function') {
    await nuxt_plugin_meta_7e821a4d(app.context, inject)
  }

  // Lock enablePreview in context
  if (process.static && process.client) {
    app.context.enablePreview = function () {
      console.warn('You cannot call enablePreview() outside a plugin.')
    }
  }

  // Wait for async component to be resolved first
  await new Promise((resolve, reject) => {
    // Ignore 404s rather than blindly replacing URL in browser
    if (process.client) {
      const { route } = router.resolve(app.context.route.fullPath)
      if (!route.matched.length) {
        return resolve()
      }
    }
    router.replace(app.context.route.fullPath, resolve, (err) => {
      // https://github.com/vuejs/vue-router/blob/v3.4.3/src/util/errors.js
      if (!err._isRouter) return reject(err)
      if (err.type !== 2 /* NavigationFailureType.redirected */) return resolve()

      // navigated to a different route in router guard
      const unregister = router.afterEach(async (to, from) => {
        if (process.server && ssrContext && ssrContext.url) {
          ssrContext.url = to.fullPath
        }
        app.context.route = await getRouteData(to)
        app.context.params = to.params || {}
        app.context.query = to.query || {}
        unregister()
        resolve()
      })
    })
  })

  return {
    store,
    app,
    router
  }
}

export { createApp, NuxtError }
