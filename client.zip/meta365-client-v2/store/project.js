const initState = () => {
  return {
    updatedAt: null,
    categories: [],
  }
}
export const state = initState

export const getters = {
  updatedAt: (s) => s.updatedAt,
  categories: (s) => s.categories || [],
}

export const mutations = {
  syncCategories (state, payload) {
    state.updatedAt = new Date()
    state.categories = payload
  },

  reset (state) {
    Object.assign(state, initState())
  }
}

export const actions = {
  // something action
}
