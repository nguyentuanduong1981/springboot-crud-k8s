const initState = () => {
  return {
    updatedAt: null,
    settings: {},
  }
}
export const state = initState

export const getters = {
  updatedAt: (s) => s.updatedAt,
  settings: (s) => s.settings || {},
}

export const mutations = {
  sync (state, payload) {
    state.updatedAt = new Date()
    state.settings = payload
  },

  reset (state) {
    Object.assign(state, initState())
  }
}

export const actions = {
  // something action
}
