export const actions = {
  async nuxtServerInit (_, { $api, store }) {
    await _getAppData($api, store)
    await _getCategory($api, store)
  }
}

async function _getAppData ($api, store) {
  try {
    const { data } = await $api.app.sync()
    store.commit('app/sync', data)
  } catch (err) {
    store.commit('app/sync', {})
  }
}

async function _getCategory ($api, store) {
  try {
    const { data } = await $api.project.getCategory()
    store.commit('project/syncCategories', data.map(category => {
      return {
        id: category._id,
        value: category._id,
        label: category.name
      }
    }))
  } catch (err) {
    store.commit('project/syncCategories', [])
  }
}
