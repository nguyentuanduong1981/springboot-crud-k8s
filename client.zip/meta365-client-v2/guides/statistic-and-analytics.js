const steps = [
  {
    element: '#projects-stats',
    popover: {
      title: 'Project',
      description: 'Open && Close sidebar',
      position: 'bottom'
    }
  },
  {
    element: '#views-stats',
    popover: {
      title: 'Views',
      description: 'Indicate the current page location',
      position: 'bottom'
    }
  },
  {
    element: '#earns-stats',
    popover: {
      title: 'Earns',
      description: 'The history of the page you visited',
      position: 'bottom'
    },
  },
  {
    element: '#projects-anal',
    popover: {
      title: 'Projects',
      description: 'The history of the page you visited',
      position: 'bottom'
    },
  },
  {
    element: '#views-anal',
    popover: {
      title: 'Views',
      description: 'The history of the page you visited',
      position: 'top'
    },
  }
]

export default steps