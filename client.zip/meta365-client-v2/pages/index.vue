<template lang="pug">
.home-page
  section.home-page__banner(v-image="'/banner.webp'")
    .filter-component
      .filter-component__content
        .filter-component__input
          el-input.input-with-select.hidden-xs-only(
            :placeholder="$t('pages.home.name_of_project')"
            v-model="query.name"
            @keydown.enter.prevent.native="onClickSearchProject"
          )
            el-select(
              v-model="query.category"
              slot="prepend"
              popper-class="no-arrow"
              :placeholder="$t('pages.home.project_categories')"
            )
              el-option(
                :label="$t('common.all')"
                value=""
              )
              el-option(
                v-for="category in categories"
                :key="category.value"
                :label="category.label"
                :value="category.value"
              )
            el-button(
              slot="append"
              type="primary"
              @click.native="onClickSearchProject"
            )
              i.el-icon-search
              | {{ $t('pages.home.search') }}
          .hidden-sm-and-up
            el-select.fw(
              v-model="query.category"
              slot="prepend"
              popper-class="no-arrow"
              :placeholder="$t('pages.home.project_categories')"
            )
              el-option(
                :label="$t('common.all')"
                value=""
              )
              el-option(
                v-for="category in categories"
                :key="category.value"
                :label="category.label"
                :value="category.value"
              )

            el-input.input-with-select.mt-10.fw(
              :placeholder="$t('pages.home.name_of_project')"
              v-model="query.name"
            )
        el-button.hidden-sm-and-up.mt-10.fw(
          type="primary"
          icon="el-icon-search"
          @click.native="onClickSearchProject"
        ) {{ $t('pages.home.search') }}

  section.home-page__best-project
    //- (v-image="'/world.png'")
    .container
      .clearfix
        .home-page__best-project__title
          .d-flex.flex-between
            h3.m-0 {{ $t('pages.home.latest_project') }}
            .navigation
              .last-project-swiper-prev(slot='button-prev')
                ChevronLeftIcon(
                  size="36"
                )
              .last-project-swiper-next(slot='button-next')
                ChevronRightIcon(
                  size="36"
                )

        swiper.project-list(
          ref="latestProject"
          :options="latestProjectSwiperOptions"
        )
          swiper-slide(
            v-for="project in latestProject"
            :key="`latest-${project._id}`"
            data-hash="slide1"
          )
            ProjectItem.mx-1(:project="project")

          .swiper-pagination(slot="pagination")

  section.home-page__project-with-place
    .container
      .home-page__project-with-place__title
        .d-flex
          h3.m-0 {{ $t('pages.home.by_location') }}
      el-row(:gutter="24")
        el-col(:sm="24" :md="12")
          .project-with-place.best(
            v-image="'/hcm.webp'"
          )
            .project-with-place__total
              strong Viet Nam
              span.r {{ total }} {{ $t('pages.home.project') }}
        el-col(:sm="24" :md="12")
          el-row(
            :gutter="24"
          )
            el-col(:xs="24" :sm="12")
              .project-with-place(
                v-image="'/dubai.jpeg'"
              )
                .project-with-place__total
                  strong Dubai
                  span.r {{ parseInt(Math.random() * 0 * 10000) }} {{ $t('pages.home.project') }}

            el-col(:xs="24" :sm="12")
              .project-with-place(
                v-image="'/singapore.jpeg'"
              )
                .project-with-place__total
                  strong Singapore
                  span.r {{ parseInt(Math.random() * 0 * 10000) }} {{ $t('pages.home.project') }}

            el-col(:xs="24" :sm="12")
              .project-with-place(
                v-image="'/india.jpeg'"
              )
                .project-with-place__total
                  strong India
                  span.r {{ parseInt(Math.random() * 0 * 10000) }} {{ $t('pages.home.project') }}

            el-col(:xs="24" :sm="12")
              .project-with-place(
                v-image="'/jakarta.jpeg'"
              )
                .project-with-place__total
                  strong Indonesia
                  span.r {{ parseInt(Math.random() * 0 * 10000) }} {{ $t('pages.home.project') }}

  section.home-page__project-for-you
    .container
      .home-page__project-for-you__title
        .d-flex.flex-between
          h3.m-0 {{ $t('pages.home.handpicked_for_you') }}
          .navigation
            .hand-picked-swiper-prev(slot='button-prev')
              ChevronLeftIcon(
                size="36"
              )
            .hand-picked-swiper-next(slot='button-next')
              ChevronRightIcon(
                size="36"
              )
      swiper.project-list(
        ref="projectForYou"
        @slideChange="slideChange"
        :options="handPickedSwiperOptions"
      )
        swiper-slide(
          v-for="project in handpickedProject"
          :key="`handpicked-${project._id}`"
          data-hash="slide1"
        )
          ProjectItem(
            :project="project"
          )
      .text-center
        nuxt-link.view-more(
          :to="{ name: 'project' }"
        )
          el-button(
            plain
            size="mini"
          )
            | {{ $t('pages.home.view_more') }}
            ChevronDownIcon.ml-4

  section.home-page__utility_support
    .container
      .home-page__utility_support__title
        .d-flex
          h3.m-0 {{ $t('pages.home.utility_support') }}
      el-row(
        :gutter="30"
        type="flex"
      )
        el-col.my-14(
          :xs="24"
          :sm="12"
          :md="6"
          v-for="i in utilitySupport"
          :key="i"
        )
          el-card(
            shadow="hover"
          )
            | {{ i }}

  section.home-page__partners
    .container
      .home-page__partners__title
        .d-flex.flex-between
          h3.m-0 {{ $t('pages.home.partners') }}
          .navigation
            .partner-swiper-prev(slot='button-prev')
              ChevronLeftIcon(
                size="36"
              )
            .partner-swiper-next(slot='button-next')
              ChevronRightIcon(
                size="36"
              )
      PartnerAndCustomer(
        :partners="[]"
      )

  //- section.home-page__about_us
  //-   .container
  //-     .home-page__about_us__title
  //-       .d-flex
  //-         h3.m-0 {{ $t('pages.home.about_us') }}
  //-     el-row(
  //-       :gutter="12"
  //-     )
  //-       el-col.text-center(
  //-         :md="12"
  //-         :sm="24"
  //-       )
  //-         img.full(
  //-           :src="`/logo-${$colorMode.value}.svg`"
  //-         )
  //-         h4 Meta365 Group
  //-         p.slogan {{ $t('pages.about_us.slogan') }}
  //-       el-col(
  //-         :md="12"
  //-         :sm="24"
  //-       )
  //-         client-only
  //-           vue-plyr(
  //-             ref="plyr"
  //-             :options="playerOptions"
  //-             :crossorigin="true"
  //-           )
  //-             .plyr__video-embed
  //-               iframe(
  //-                 src='https://www.youtube.com/embed/GhNbvlnpzHI?amp;iv_load_policy=3&modestbranding=1&playsinline=1&showinfo=0&rel=0&enablejsapi=1'
  //-                 allowfullscreen
  //-                 allowtransparency
  //-                 allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
  //-               )

  section.home-page__back-to-top(
    @click="onClickBackToTop"
  )
    span {{ $t('pages.home.back_to_top') }}

  Footer
</template>

<script>
import { Swiper, SwiperSlide, directive } from 'vue-awesome-swiper'
import { mapState } from 'vuex'
import { MapPinIcon, MailIcon, MapIcon, PhoneCallIcon, ChevronRightIcon, ChevronLeftIcon, ChevronDownIcon } from 'vue-feather-icons'
import 'swiper/css/swiper.css'
import { generateUrl, scrollTo } from '@/utilities/helpers'

export default {
  name: 'HomePage',

  components: {
    Swiper,
    MapIcon,
    MailIcon,
    MapPinIcon,
    SwiperSlide,
    PhoneCallIcon,
    ChevronLeftIcon,
    ChevronDownIcon,
    ChevronRightIcon,
  },

  directives: {
    swiper: directive,
  },

  data () {
    return {
      lang: 'en',
      latestProject: [],
      handpickedProject: [],
      playerOptions: {
        autoplay: false,
        controls: [
          'play-large',
          'mute',
          'fullscreen',
          'restart',
          'pause',
          'stop',
          'play'
        ],
        youtube: {
          noCookie: 0,
        }
      },
      latestProjectSwiperOptions: {
        grabCursor: true,
        loop: true,
        slidesPerView: 3,
        spaceBetween: 30,
        // freeMode: true,
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
          dynamicBullets: true,
        },
        navigation: {
          nextEl: '.last-project-swiper-next',
          prevEl: '.last-project-swiper-prev'
        },
        // autoplay: {
        //   delay: 4500,
        //   disableOnInteraction: false,
        // },
        breakpoints: {
          1440: {
            slidesPerView: 4,
            spaceBetween: 30,
          },
          992: {
            slidesPerView: 3,
            spaceBetween: 24,
          },
          768: {
            slidesPerView: 2,
            spaceBetween: 20,
          },
          576: {
            slidesPerView: 2,
            spaceBetween: 10,
          },
          325: {
            slidesPerView: 1,
            spaceBetween: 10,
          },
          1: {
            slidesPerView: 1,
            spaceBetween: 10,
          },
        },
      },

      handPickedSwiperOptions: {
        grabCursor: true,
        loop: true,
        slidesPerView: 3,
        spaceBetween: 30,
        // freeMode: true,
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
          dynamicBullets: true,
        },
        navigation: {
          nextEl: '.hand-picked-swiper-next',
          prevEl: '.hand-picked-swiper-prev'
        },
        autoplay: {
          delay: 4500,
          disableOnInteraction: false,
        },
        breakpoints: {
          1440: {
            slidesPerView: 4,
            spaceBetween: 30,
          },
          992: {
            slidesPerView: 3,
            spaceBetween: 24,
          },
          768: {
            slidesPerView: 2,
            spaceBetween: 20,
          },
          576: {
            slidesPerView: 2,
            spaceBetween: 10,
          },
          325: {
            slidesPerView: 1,
            spaceBetween: 10,
          },
          1: {
            slidesPerView: 1,
            spaceBetween: 10,
          },
        },
      },

      utilitySupport: [
        'See the age to built a house',
        'Cost of building a house',
        'Calculate interest rate',
        'Feng Shui consultation'
      ],

      handpickedProjectOptions: {
        // centeredSlides: true,
        grabCursor: true,
        loop: true,
        slidesPerView: 1,
        spaceBetween: 10,
        // freeMode: true,
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
        },
        autoplay: {
          delay: 3000,
          disableOnInteraction: false,
        },
      },

      swiperOptions4: {
        // centeredSlides: true,
        grabCursor: true,
        loop: true,
        slidesPerView: 5,
        spaceBetween: 0,
        direction: 'vertical',
        autoplay: {
          delay: 2500,
          disableOnInteraction: false,
        },
        // pagination: {
        //   el: '.news-pagination',
        //   clickable: true,
        //   dynamicBullets: true
        // }
      },

      colorModes: [
        {
          label: 'System',
          value: 'system',
          icon: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-monitor preferred" data-v-2b778c3e=""><rect x="2" y="3" width="20" height="14" rx="2" ry="2" data-v-2b778c3e=""></rect><line x1="8" y1="21" x2="16" y2="21" data-v-2b778c3e=""></line><line x1="12" y1="17" x2="12" y2="21" data-v-2b778c3e=""></line></svg>',
        },
        {
          label: 'Light',
          value: 'light',
          icon: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-sun selected" data-v-2b778c3e=""><circle cx="12" cy="12" r="5" data-v-2b778c3e=""></circle><line x1="12" y1="1" x2="12" y2="3" data-v-2b778c3e=""></line><line x1="12" y1="21" x2="12" y2="23" data-v-2b778c3e=""></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64" data-v-2b778c3e=""></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78" data-v-2b778c3e=""></line><line x1="1" y1="12" x2="3" y2="12" data-v-2b778c3e=""></line><line x1="21" y1="12" x2="23" y2="12" data-v-2b778c3e=""></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36" data-v-2b778c3e=""></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22" data-v-2b778c3e=""></line></svg>',
        },
        {
          label: 'Dark',
          value: 'dark',
          icon: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-moon" data-v-2b778c3e=""><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" data-v-2b778c3e=""></path></svg>',
        },
      ],
      query: {
        name: '',
        category: '',
        status: '',
      },
      optionsStatus: [
        {
          value: '1',
          label: 'Mở bán',
        },
        {
          value: '2',
          label: 'Đang bàn giao',
        }
      ],
      total: 0
    }
  },

  head () {
    const description = 'META365 is a Leader in Applied Imaging Technology. Operating since 2018, META365 exploits VR360 imaging technologies, AI Artificial Intelligence, Big Data ... with the aim of building a Decentralized Real Estate Transaction Center to bring traditional Real Estate into the Metaverse Universe. As a completely new model of a real estate transaction center, the application of metaverses makes buying and selling real estate easier.'
    return {
      title: 'Home',
      meta: [
        {
          hid: 'og:title',
          property: 'og:title',
          content: 'Home'
        },
        {
          hid: 'og:description',
          property: 'og:description',
          content: description
        },
        {
          property: 'og:image',
          content: generateUrl('/pano.jpg')
        },
        {
          hid: 'og:url',
          property: 'og:url',
          content: generateUrl(this.$route.path)
        },
        {
          hid: 'og:site_name',
          property: 'og:site_name',
          content: process.env.DOMAIN
        },
        {
          hid: 'og:locale',
          property: 'og:locale',
          content: 'vi'
        },
        {
          hid: 'og:image:type',
          property: 'og:image:type',
          content: 'image/jpeg'
        },
        // {
        //   hid: 'twitter:card',
        //   property: 'twitter:card',
        //   content: article.provider_summary
        // },
        {
          hid: 'twitter:site',
          property: 'twitter:site',
          content: process.env.DOMAIN
        },
{
          hid: 'twitter:title',
          name: 'twitter:title',
          content: 'Home'
        },
        {
          hid: 'twitter:description',
          name: 'twitter:description',
          content: description
        },
        {
          hid: 'twitter:creator',
          property: 'twitter:creator',
          content: process.env.DOMAIN
        },
        {
          hid: 'twitter:image:src',
          property: 'twitter:image:src',
          content: generateUrl('/pano.jpg')
        },
        {
          hid: 'twitter:domain',
          property: 'twitter:domain',
          content: process.env.DOMAIN
        },
        {
          hid: 'twitter:image',
          name: 'twitter:image',
          content: generateUrl('/pano.jpg')
        },
        {
          hid: 'og:video:type',
          name: 'og:video:type',
          content: 'application/x-shockwave-flash'
        },
        {
          hid: 'og:type',
          name: 'og:type',
          content: 'article'
        },
        {
          hid: 'twitter:url',
          name: 'twitter:url',
          content: generateUrl(this.$route.path)
        },
        // {
        //   hid: 'og:publish_date',
        //   name: 'og:publish_date',
        //   content: article.published_date
        // },
        {
          hid: 'og:author',
          name: 'og:author',
          content: 'UnicornChain'
        }
      ]
    }
  },

  computed: {
    ...mapState('project', {
      categories: state => state.categories
    })
  },

  async mounted () {
    const projects = await Promise.all([
      this.$api.project.all({
        limit: 6
      }),
      this.$api.project.handpicked({
        limit: 6
      })
    ])
    this.latestProject = projects[0].data.results
    this.total = projects[0].data.total
    this.handpickedProject = projects[1].data
  },

  methods: {
    slideChange(e) {
      this.activeProject = this.$refs.projectForYou.$swiper.activeIndex
    },

    onClickSwitchLocalePath() {
      this.lang = this.lang === 'en' ? 'vi' : 'en'
      this.$i18n.setLocale(this.lang)
    },

    onClickOpenLoginModal() {
      this.$flows.login({
        parent: this,
      })
    },

    onClickSearchProject(e) {
      e.preventDefault()
      return this.$router.push({ name: 'project', query: this.query })
    },

    onClickBackToTop () {
      scrollTo(0)
    }
  }
}
</script>

<style lang="scss" scoped>
::v-deep.home-page {
  background-color: var(--color-shade-0);
  &__banner {
    padding: 0 15px;
    margin: 0;
    height: 400px;
    background-repeat: no-repeat;
    background-size: cover;
    background-position-y: bottom;
    @include media(sm-down) {
      height: 500px;
      background-position-x: center;
    }
  }
  .filter-component {
    height: 100%;
    padding-top: 200px;
    max-width: 678px;
    margin: 0 auto;
    &__header {
      background-image: $--background-color-button-primary;
      border-top-right-radius: 10px;
      padding: 6px 12px;
      display: inline-block;
    }
    &__content {
      border-bottom-left-radius: 8px;
      border-bottom-right-radius: 8px;
      border-top-right-radius: 8px;
    }
    .el-input-group {
      &__prepend {
        border-left-width: 0;
        width: 120px;
        border-right: 1px solid var(--color-shade-7);
      }
      .el-input {
        color: var(--color-shade-1);
        height: 48px;
        &__inner {
          height: 48px;
          color: var(--color-shade-8);
          background-color: var(--color-shade-3);
          border-width: 0;
          &:hover {
            border-width: 0;
          }
        }
        &.el-input--suffix {
          .el-input__inner {
            border-radius: 8px 0 0 8px;
            border-color: transparent;
          }
        }
      }
      &__append {
        border-left: 0;
        border-width: 0;
        background-color: transparent;
        .el-button {
          height: 48px;
          border-top-left-radius: 0;
          border-bottom-left-radius: 0;
          width: 120px;
          padding: 12px 14px;
          border-left: currentColor;
          color: var(--color-shade-1);
          background-color: var(--color-warning-5);
          filter: none;
          &:hover {
            box-shadow: none;
            filter: none;
          }
          > span {
            padding: 4px 8px;
            border-radius: $--radius-medium;
            color: var(--color-shade-1);
          }
        }
      }
    }
    .el-input {
      &__inner {
        border-width: 0;
        color: var(--color-shade-8);
        background-color: var(--color-shade-3);
        &::placeholder {
          color: var(--color-shade-8);
        }
        &:focus {
          border-color: transparent;
        }
      }
    }
    &__selection {
      margin-top: 10px;
      width: calc(100% - 120px);
      @include media(xs) {
        width: 100%;
        margin-left: 0 !important;
        margin-right: 0 !important;
        .el-col {
          margin: 5px 0;
          padding: 0 !important;
          &:first-child {
            margin-top: 0;
          }
          &:last-child {
            margin-bottom: 0;
          }
        }
      }
      .input-range {
        background-color: var(--color-shade-1);
        border-radius: $--radius-mini;
        padding: 10px 12px;
        font-size: $--size-base;
        border: 1px solid var(--color-shade-2);
        cursor: pointer;
        &.initial {
          color: var(--color-shade-3);
        }
        &:focus {
          border-color: var(--color-primary);
        }
      }
    }
  }
  &__best-project,
  &__project-for-you,
  &__project-with-place,
  &__utility_support,
  &__hot-news,
  &__latest-experience,
  &__about_us,
  &__partners {
    padding: 30px 0;
    @include media(sm-down) {
      .swiper-button-prev, .swiper-button-next {
        display: none;
      }
    }
    &__title {
      color: var(--color-shade-8);
      padding-bottom: 10px;
      > .d-flex {
        justify-content: space-between;
        align-items: center;
        h3 {
          margin: 0;
          font-size: 28px;
          padding-bottom: 5px;
          // background: linear-gradient(
          //     to left,
          //     #ffffff00 0%,
          //     #ffffff00 50%,
          //     #3e75fe 75%,
          //     #55d9ff 100%
          //   )
          //   left bottom rgba(80, 63, 63, 0) no-repeat;
          background-size: 100% 5px;
        }
        .project,
        .news {
          text-align: right;
          color: var(--color-primary);
          text-decoration: none;
        }
      }
      > .text-center {
        h3 {
          margin: 0;
          font-size: 24px;
          padding-bottom: 5px;
          background: linear-gradient(
              to left,
              rgba(255, 255, 255, 0) 0%,
              rgba(255, 255, 255, 0) 40%,
              #3e75fe 45%,
              #55d9ff 55%,
              rgba(255, 255, 255, 0) 60%,
              rgba(255, 255, 255, 0) 100%
            )
            left bottom rgba(80, 63, 63, 0) no-repeat;
          background-size: 100% 5px;
        }
      }
    }
    .swiper-button-prev, .swiper-container-rtl .swiper-button-next {
      left: -30px;
    }
    .swiper-button-next, .swiper-container-rtl .swiper-button-prev {
      right: -30px;
    }
  }

  &__back-to-top {
    margin-top: 30px;
    background: var(--color-warning-5);
    height: 48px;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    color: var(--color-shade-0);
  }
  .navigation {
    display: flex;
    .last-project-swiper-prev,
    .last-project-swiper-next,
    .partner-swiper-prev,
    .partner-swiper-next,
    .hand-picked-swiper-prev,
    .hand-picked-swiper-next {
      cursor: pointer;
      display: flex;
      justify-content: center;
      align-items: center;
      border: 1.5px solid var(--color-shade-8);
      border-radius: 50%;
      height: 37px;
      width: 37px;
      margin: 0 6px;
    }
  }
  .project-list {
    padding: 10px 0 20px;
    .swiper-pagination {
      position: relative;
      bottom: -10px;
      .swiper-pagination-bullet {
        background-color: var(--color-shade-3);
      }
    }
  }
  .view-more {
    .el-button {
      border-radius: 10px;
      > span {
        font-size: 16px;
        display: flex;
        align-items: center;
        font-weight: 400;
      }
    }
  }
  &__project-with-place {
    .project-with-place {
      position: relative;
      background-size: cover;
      border: 0.25px solid var(--color-shade-2);
      filter: drop-shadow(0px 4px 14px rgba(0, 0, 0, 0.4));
      border-radius: $--radius-medium;
      cursor: pointer;
      overflow: hidden;
      margin: 12px 0;
      height: 180px;
      background-position-y: center;
      @include media(sm-down) {
        height: 200px;
      }
      @include media(mobile) {
        height: 180px;
        margin: 10px 0;
      }
      &.best {
        @include media(sm) {
          height: 386px;
        }
      }
      &__total {
        position: absolute;
        top: 16px;
        color: var(--color-shade-1);
        font-size: $--size-base-xs;
        padding: 6px 16px;
        border-bottom-right-radius: 8px;
        border-top-right-radius: 8px;
        // background: rgba($--color-brand, 0.4);
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        strong, span {
          // text-overflow: ellipsis;
          // overflow: hidden;
          // white-space: nowrap;
          // max-width: 70%;
          // color: var(--color-shade-8);
          color: rgba($--color-text-primary, 0.9);
          display: inline-block;
        }
        .r {
          font-weight: 600;
          text-align: right;
          color: var(--color-warning-5);
        }
      }
    }
  }
  &__utility_support {
    .el-card {
      font-weight: 400;
      background-color: var(--color-shade-1);
      color: var(--color-shade-5);
      border: 1px solid var(--color-warning-5);
      font-weight: 600;
      font-size: --size-base-md;
      text-align: center;
      &:hover {
        background-color: var(--color-warning-5);
        color: var(--color-shade-1);
      }
    }
  }
  &__hot-news {
    &__title {
    }
    .subtitle {
      color: var(--color-shade-1);
      font-weight: 500;
      text-transform: uppercase;
      font-size: 24px;
      margin: 0 0 4px;
    }
    .swiper-vertical {
      height: 260px;
    }
    .new-item {
      &.only-title {
        border-top: 1.5px solid var(--color-shade-5);
        padding: 8px 0 10px;
      }
      img {
        width: 100%;
        height: auto;
        border-radius: $--radius-medium;
      }
      &__title {
        font-size: $--size-base;
        line-height: 16px;
        color: var(--color-shade-1);
      }
    }
  }
  &__about_us {
    .full {
      width: 84px;
    }
    h4 {
      font-size: 24px;
      font-weight: 700;
    }
    .slogan {
      line-height: 22px;
      text-align: justify;
    }
  }
  &__latest-experience {
    .tour {
      border-style: solid;
      border-top-width: 8px;
      border-bottom-width: 8px;
      border-image: linear-gradient(to left, black 0%, #4ccbff 50%, black 100%)
        100% 0 100% 0/8px 0 8px 0 stretch;
      text-align: center;
    }
  }
  ul {
    list-style: none;
    padding: 0;
    margin: 0;
    li {
      display: inline-block;
      padding: 5px;
      &.active {
        svg {
          border-color: $--color-highlight;
        }
      }
      svg {
        position: relative;
        top: 0;
        cursor: pointer;
        padding: 7px;
        border: 2px solid $--color-info;
        margin: 0;
        border-radius: 5px;
        transition: all 0.1s ease;
      }
    }
  }
}
</style>
<style lang="scss">
.space {
  height: 100%;
  width: 20px;
}
.swiper-for-you {
  height: 550px;
  margin-left: auto;
  margin-right: auto;

  .swiper-slide {
    height: 260px;
  }
}
</style>
