<template lang="pug">
.for-real-estate-customers-page.customer-page
  section.customer-page__banner(
    v-image="'/for-real-estate-customers.webp'"
  )
    h1.customer-page__title {{ $t('pages.for_real_estate_enterprises.title') }}
  section.container
    el-row.p-10(
      type="flex"
      :gutter="20"
    )
      el-col.py-10(:sm="24" :md="12")
        h2 Công Nghệ Nổi Bật
        ul
          li Công nghệ số hoá hình ảnh VR/AR 360* view toàn bộ quang cảnh khu dự án bất động sản.
          li Công nghệ nén dữ liệu hình ảnh với tỉ lệ 1/1000 giúp tăng trải nghiệm của người dùng, không bị giật lag dù với tốc độ đường truyền mạng internet thông thường, mà vẫn đảm bảo được độ sắc nét, chân thực của hình ảnh.
          li Công nghệ Big data & AI hỗ trợ trong quá trình tìm kiếm khách hàng nhanh hơn, chính xác với nhu cầu của khách hàng hơn.
          li Vr tour360° nhà mẫu, tạo trải nghiệm mới cho khách hàng
          li Cập nhật tiến độ thi công dự án, sơ đồ mặt bằng
          li Phối cảnh ngày đêm đem lại trải nghiệm mới cho khách hàng
          li Tích hợp định vị google maps, youtube, Facebook dự án,…
          li Tour guide ảo
          li Hỗ trợ phòng họp ảo tư vấn trực tiếp với khách hàng
      el-col.py-10(:sm="24" :md="12")
        nuxt-img.fw(
          src="/for-real-estate-customers-1.webp"
        )

    .clearfix

    el-row.p-10(
      type="flex"
      :gutter="20"
    )
      el-col.py-10(:sm="24" :md="12")
        nuxt-img.fw(
          src="/for-real-estate-customers-2.webp"
        )
      el-col.py-10(:sm="24" :md="12")
        h2 Lợi Ích Chủ Đầu Tư
        p Tiết kiệm chi phí marketing.
        p Hỗ trợ và rút ngắn quá trình đào tạo Sale bán hàng.
        .mb-10
        strong Có một bộ hồ sơ bán hàng với:
        ul
          li Hình ảnh dự án và môi trường xung quanh được số hóa hoàn toàn 360 độ, có thể tương tác đa chiều thông qua thiết bị thông minh.
          li Đầy đủ thông tin dự án, lô đất, căn hộ và các thông tin pháp lý khác đi kèm.
          li Thông tin được cá nhân hóa theo từng nhân viên bán hàng của dự án

      .clearfix

      el-row.p-10(
        type="flex"
        :gutter="20"
      )
        el-col.py-10(:sm="24" :md="12")
          h2 Lợi Ích Đối Với Sale
          ul
            li Đào tạo nhân viên bán hàng nhanh chóng, tiết kiệm thời gian, chi phí, thúc đẩy nhanh quá trình bán hàng của nhân viên
            li Hỗ trợ quá trình marketing dự án thông qua hình ảnh và các kết nối trên các mạng xã hội Facebook, Youtube …
            li Khai thác được hệ thống Nhà Môi Giới BĐS Phi Tập Trung của Meta365
            li Tiếp cận được khách hàng ở xa
            li Khai thác được hệ thống khách hàng (Nhà Đầu Tư BĐS) thường xuyên của Meta365 Đem lại trải nghiệm hoàn toàn mới cho khách hàng
        el-col.py-10(:sm="24" :md="12")
          nuxt-img.fw(
            src="/for-real-estate-customers-3.webp"
          )

      .clearfix

  section
    h2.text-center {{ $t('pages.for_real_estate_enterprises.partners') }}
    PartnerAndCustomer(
      :partners="[]"
    )

  Footer.mt-30
</template>

<script>
import { Swiper, SwiperSlide, directive } from 'vue-awesome-swiper'
import { MapPinIcon, MailIcon, MapIcon, PhoneCallIcon, ChevronRightIcon, ChevronLeftIcon, ChevronDownIcon } from 'vue-feather-icons'
import 'swiper/css/swiper.css'
import { generateUrl } from '@/utilities/helpers'
import SunGroup from '@/assets/images/partners/sun-group.svg?inline'
import Hub from '@/assets/images/partners/hub.svg?inline'
import NovaWorld from '@/assets/images/partners/nova-world.svg?inline'
import MshGroup from '@/assets/images/partners/msh-group.svg?inline'
import Red from '@/assets/images/partners/red.svg?inline'
import Fibo from '@/assets/images/partners/fibo.svg?inline'
import Dns from '@/assets/images/partners/dns.svg?inline'
import Utc from '@/assets/images/partners/utc.svg?inline'
import Fgi from '@/assets/images/partners/fgi.svg?inline'
import CenGroup from '@/assets/images/partners/cen-group.svg?inline'
import CenHousing from '@/assets/images/partners/cen-housing.svg?inline'
import MicHolding from '@/assets/images/partners/mic-holding.svg?inline'
import HungVuong from '@/assets/images/partners/hungvuong.svg?inline'

export default {
  name: 'ForRealEstateEnterprisesPage',

  components: {
    Swiper,
    MapIcon,
    MailIcon,
    MapPinIcon,
    SwiperSlide,
    PhoneCallIcon,
    ChevronLeftIcon,
    ChevronDownIcon,
    ChevronRightIcon,
    SunGroup,
    Hub,
    NovaWorld,
    MshGroup,
    Red,
    Fibo,
    Dns,
    Utc,
    Fgi,
    CenGroup,
    CenHousing,
    MicHolding,
    HungVuong
  },

  directives: {
    swiper: directive,
  },

  data () {
    return {
      swiperPartnersOptions: {
        grabCursor: true,
        loop: true,
        slidesPerView: 2,
        spaceBetween: 10,
        // freeMode: true,
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
          dynamicBullets: true,
        },
        navigation: {
          nextEl: '.partner-swiper-next',
          prevEl: '.partner-swiper-prev'
        },
        autoplay: {
          delay: 1000,
          disableOnInteraction: false,
        },
        breakpoints: {
          992: {
            slidesPerView: 5,
            spaceBetween: 10,
          },
          768: {
            slidesPerView: 4,
            spaceBetween: 10,
          },
          576: {
            slidesPerView: 2,
            spaceBetween: 10,
          },
          325: {
            slidesPerView: 1,
            spaceBetween: 10,
          },
        },
      },
      partners: [
        'SunGroup',
        'Hub',
        'NovaWorld',
        'MshGroup',
        'Red',
        'Fibo',
        'Dns',
        'Utc',
        'Fgi',
        'CenGroup',
        'CenHousing',
        'MicHolding',
        'HungVuong',
      ],
    }
  },

  head () {
    const description = 'META365 is a Leader in Applied Imaging Technology. Operating since 2018, META365 exploits VR360 imaging technologies, AI Artificial Intelligence, Big Data ... with the aim of building a Decentralized Real Estate Transaction Center to bring traditional Real Estate into the Metaverse Universe. As a completely new model of a real estate transaction center, the application of metaverses makes buying and selling real estate easier.'
    return {
      title: 'For Real Estate Enterprise',
      meta: [
        {
          hid: 'og:title',
          property: 'og:title',
          content: 'For Real Estate Enterprise'
        },
        {
          hid: 'og:description',
          property: 'og:description',
          content: description
        },
        {
          property: 'og:image',
          content: generateUrl('/pano.jpg')
        },
        // {
        //   hid: 'og:url',
        //   property: 'og:url',
        //   content: generateUrl(this.$route.path)
        // },
        // {
        //   hid: 'og:type',
        //   property: 'og:type',
        //   content: 'website'
        // },
        // {
        //   hid: 'og:site_name',
        //   property: 'og:site_name',
        //   content: process.env.DOMAIN
        // },
        // {
        //   hid: 'og:locale',
        //   property: 'og:locale',
        //   content: 'au'
        // },
        // {
        //   hid: 'og:image:type',
        //   property: 'og:image:type',
        //   content: 'image/jpeg'
        // },
        // {
        //   hid: 'twitter:card',
        //   property: 'twitter:card',
        //   content: article.provider_summary
        // },
        // {
        //   hid: 'twitter:site',
        //   property: 'twitter:site',
        //   content: process.env.DOMAIN
        // },
        // {
        //   hid: 'twitter:title',
        //   name: 'twitter:title',
        //   content: article.title
        // },
        // {
        //   hid: 'twitter:description',
        //   name: 'twitter:description',
        //   content: `${article.title}, ${article.source_name}`
        // },
        // {
        //   hid: 'twitter:creator',
        //   property: 'twitter:creator',
        //   content: process.env.DOMAIN
        // },
        {
          hid: 'twitter:image:src',
          property: 'twitter:image:src',
          content: './banner.jpg'
        },
        // {
        //   hid: 'twitter:domain',
        //   property: 'twitter:domain',
        //   content: process.env.DOMAIN
        // },
        {
          hid: 'twitter:image',
          name: 'twitter:image',
          content: './banner.jpg'
        },
        {
          hid: 'og:video:type',
          name: 'og:video:type',
          content: 'application/x-shockwave-flash'
        },
        {
          hid: 'og:video:width',
          name: 'og:video:width',
          content: '400'
        },
        {
          hid: 'og:video:height',
          name: 'og:video:height',
          content: '300'
        },
        {
          hid: 'og:type',
          name: 'og:type',
          content: 'article'
        },
        {
          hid: 'og:video:secure_url',
          name: 'og:video:secure_url',
          content: generateUrl('/tour.swf')
        },
        {
          hid: 'og:video',
          name: 'og:video',
          content: generateUrl('/tour.swf')
        }
        // {
        //   hid: 'twitter:url',
        //   name: 'twitter:url',
        //   content: generateUrl(this.$route.path)
        // },
        // {
        //   hid: 'og:publish_date',
        //   name: 'og:publish_date',
        //   content: article.published_date
        // },
        // {
        //   hid: 'og:author',
        //   name: 'og:author',
        //   content: article.source_name
        // }
      ]
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/assets/styles/component/customer'
</style>
