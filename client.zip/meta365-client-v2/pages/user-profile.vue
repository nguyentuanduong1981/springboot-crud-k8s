<template lang="pug">
.user-profile-page
  #app-landing
    #app-landing-bg.container(
      :class="{ cropper: isChangeCover }"
    )
      .cover(
        :style="{ background: `url(${coverParse})`, backgroundSize: 'cover' }"
        @click="onClickPreviewImage(0)"
      )
      template(v-if="isOwner")
        CoverUploader(
          v-if="isChangeCover"
          ref="coverCropper"
          :loading="loadingCropper"
          :src="this.cover.src || coverParse"
          :canvas="{ minHeight: 372, minWidth: 768 , maxHeight: 372, maxWidth: 2048 }"
          :minWidth="375"
          :minHeight="372"
          @loaded="loadingCropper = false"
          @cropped="onUploadCover($event)"
          image-restriction="stencil"
          :stencil-size="{ width: 1200, height: 372 }"
        )

        label.change-cover(
          v-if="!isChangeCover"
        )
          InputFile(
            :maximum="8"
            @ready="loadImage($event)"
            :accept="'image/jpg,image/jpeg,image/png'"
          )
          CameraIcon(
            size="18"
          )
          span.ml-4 {{ $t('pages.profile.change_cover') }}

        .crop-cover(
          v-else
          :class="{ loading }"
        )
          label.re-upload.mr-4(
            v-loading="loading"
            element-loading-spinner="el-icon-loading"
          )
            InputFile(
              :maximum="5"
              @ready="loadImage($event)"
              :accept="'image/jpg,image/jpeg,image/png'"
            )
            CameraIcon(
              size="18"
            )
            span.ml-4 {{ $t('common.choose_another_image') }}
          .cancel.mr-4(
            v-loading="loading"
            element-loading-spinner="el-icon-loading"
            @click.stop="resetCropper()"
          )
            XSquareIcon(
              size="18"
            )
            span.ml-4 {{ $t('pages.profile.cancel_upload_cover') }}
          .save(
            v-loading="loading"
            element-loading-spinner="el-icon-loading"
            @click.stop="onClickCropCover()"
          )
            CheckSquareIcon(
              size="18"
            )
            span.ml-4 {{ $t('pages.profile.save_cover') }}
  #app-content.container
    #app-profile-header.profile-header
      .profile-avatar
        nuxt-img.avatar(
          format="webp"
          :src="avatar"
          @click.native="onClickPreviewImage(1)"
        )
        template(
          v-if="isOwner"
        )
          .upload.hidden-xs-only
          .background-tool.hidden-xs-only
            .top(
              @click="onClickPreviewImage(1)"
            )
            .bottom.flex-center(
              @click="onClickUploadAvatar()"
            )
              CameraIcon(
                size="18"
              )
      div.username-and-contact
        .username.flex-center-y
          el-tooltip-theme(
            :content="user.fullName || user.username"
            placement="bottom"
          )
            .value.c-text-ellipsis-0 {{ user.fullName || user.username }}
          span.verified
            CheckIcon(size="18")
        p.type-subtitle.contact
          CameraIcon.hidden-sm-and-up(
            v-if="isOwner"
            size="20"
            @click="onClickUploadAvatar()"
          )
          a.mx-8(:href="`tel:${user.phoneNumber}`")
            PhoneCallIcon(size="20")
          //- el-tooltip(
          //-   :content="$t('pages.profile.message')"
          //-   placement="top-start"
          //-   :effect="$colorMode.value === 'dark' ? 'dark' : 'light'"
          //- )
          //- MessageCircleIcon.ml-8(
          //-   size="20"
          //-   @click="onClickMessage()"
          //- )
      .profile-actions
        template(v-if="isOwner")
          nuxt-link.flex-center-y(
            :to="{ name: 'settings' }"
          )
            SettingsIcon
        template(v-else)
          button.flex-center-y(
            @click="onClickFollow()"
            :class="`following-${following}`"
          )
            component.mr-4(:is="following ? 'UserCheckIcon' : 'UserPlusIcon'")
            //- .hidden-sm-and-down {{ following ? $t('pages.profile.following') : $t('pages.profile.follow') }}
          //- button.flex-center-y.hidden-xs-only
          //-   CopyIcon.mr-4(size="20")
          //-   .hidden-sm-and-down {{ $t('common.copy_link') }}
        DropdownNetworkSharing(
          :sharing="sharing"
        )
          button.flex-center-y.hidden-xs-only(
            slot="reference"
          )
            Share2Icon.mr-4(size="20")

        el-dropdown(
          trigger="click"
        )
          //- :hide-on-click="false"
          span.el-dropdown-link
            button.more-btn
              MoreVerticalIcon(size="24")
          el-dropdown-menu(
            slot="dropdown"
          )
            el-dropdown-item.flex-center-y.hidden-sm-and-up(@click.stop.native="onClickOpenSharePopup()")
              Share2Icon.mr-4(size="20")
              | {{ $t('common.share') }}
            el-dropdown-item.flex-center-y(
              v-clipboard:copy="sharing.url"
              v-clipboard:success="clipboardSuccess"
            )
              CopyIcon.mr-4(size="20")
              | {{ $t('common.copy_link') }}
            template(v-if="!isOwner")
              el-dropdown-item.flex-center-y
                AlertTriangleIcon.mr-4(size="20")
                | {{ $t('pages.profile.report') }}
              el-dropdown-item.flex-center-y
                UserXIcon.mr-4(size="20")
                | {{ $t('pages.profile.block') }}

    .profile-content
      el-tabs.v2(
        v-model="activeTab"
        type="card"
      )
        //- el-tab-pane(
        //-   name="posts"
        //-   :label="$t('pages.profile.posts')"
        //- )
        //-   el-empty(
        //-     :image-size="100"
        //-     :description="$t('common.no_posts_yet')"
        //-     image="/quivering.png"
        //-   )
        //-     el-button(
        //-       @click="onClickFollow()"
        //-       v-if="isOwner"
        //-       type="primary"
        //-     ) {{ $t('common.create_post') }}

        el-tab-pane(
          name="projects"
          :label="$t('pages.profile.projects')"
        )
          el-empty(
            v-if="!projects.length"
            :image-size="100"
            :description="$t('common.no_projects_yet')"
            image="/quivering.png"
          )
          ProjectCard.mb-16(
            v-else
            v-for="project, index in projects"
            :key="`project-${index}`"
            :project="project"
            @delete="onHandleDeleteLink(project.link)"
            :to="{ name: 'sale-id', params: { id: project.link } }"
          )
        //- el-tab-pane(
        //-   name="followers"
        //-   :label="$t('pages.profile.followers')"
        //- ) {{ $t('pages.profile.followers') }}
        //- el-tab-pane(
        //-   name="following"
        //-   :label="$t('pages.profile.following')"
        //- ) {{ $t('pages.profile.following') }}
        //- el-tab-pane(
        //-   name="reviews"
        //-   :label="$t('pages.profile.reviews')"
        //- )
        //-   el-empty(
        //-     :image-size="100"
        //-     :description="$t('common.no_reviews_yet')"
        //-     image="/quivering.png"
        //-   )
        //-     el-button(
        //-       v-if="!isOwner"
        //-       @click="onClickFollow()"
        //-       type='primary'
        //-     ) {{ $t('common.create_review') }}

      //- .content-navigation
      //-   ul
      //-     li.type-caption.active All
      //-     li.type-caption Singles
      //-     li.type-caption Playlists
      //-     li.type-caption Rating
      //-     li.type-caption Awards
    .profile-details
      //- el-row(:gutter="10").detail-section
      //-   el-col(:span="12")
      //-     p.type-caption.profile-details__label {{ $t('pages.profile.followers') }}
      //-     p.type-heading-4 {{ followerCount }}
      //-   el-col(:span="12")
      //-     p.type-caption {{ $t('pages.profile.following') }}
      //-     p.type-heading-4 {{ followingCount }}
        //- div
        //-   p.type-caption Releases
        //-   p.type-heading-4 {{ releaseCount }}
        //- .grid-icon
        //-   p.type-caption Chart
        //-   BarChart2Icon
      .detail-section
        .flex-between.flex-center-y.mb-4
          p.type-caption {{ $t('pages.profile.description') }}
          span(
            v-if="isOwner"
          )
            el-button.add-social-link(
              size="mini"
              @click.native="editableDescription = !editableDescription"
            )
              component(
                :is="editableDescription ? 'XSquareIcon' : 'EditIcon'"
                size="18"
              )
            el-button.add-social-link(
              v-if="editableDescription"
              size="mini"
              @click.native="onClickSaveDescription()"
            )
              CheckSquareIcon(
                size="18"
              )
        el-input(
          v-if="editableDescription"
          type="textarea"
          :maxlength="512"
          show-word-limit
          :autosize="{ minRows: 2, maxRows: 4}"
          :placeholder="$t('pages.profile.your_description')"
          v-model="description"
        )
        p(v-else) {{ user.description || $t('pages.profile.no_descriptions') }}
      .detail-section
        p.type-caption {{ $t('pages.profile.agency') }}
        //- nuxt-link.text-link(
        //-   v-if="user.agent"
        //-   :to="{ name: 'agent-id', params: { id: user.agent._id } }"
        //- )
        p(
          v-if="user.agent"
        ) {{ user.agent.name }}
        p(
          v-else
        ) {{ $t('pages.profile.freelance_broker') }}
      .detail-section
        p.type-caption {{ $t('pages.profile.rate') }}
        el-rate(
          :value="user.rate || 0"
          disabled
          show-score
          text-color="#ff9900"
          disabled-void-color="#bbbbbb"
          score-template="{value}/5(0 review)"
        )
      .detail-section
        .flex-between.flex-center-y
          p.type-caption {{ $t('pages.profile.social_links') }}
            el-tooltip(
              :effect="$colorMode.value === 'dark' ? 'dark' : 'light'"
              :content="$t('pages.profile.social_network_links_are_accepted')"
              placement="top"
            )
              sup
                i.el-icon-info
          el-button.add-social-link(
            v-if="isOwner"
            size="mini"
            @click.native="onClickOpenChangeSocialLink()"
          )
            EditIcon(
              size="18"
            )
        p(v-if="!user.socials.length") {{ $t('common.no_social_network_link') }}
        .social.d-flex.mt-10
          .social__item(v-for="i in user.socials")
            a(:href="i.value" target="_blank")
              img(:src="`/socials/${i.key}.svg`")

  ShareSheet(
    :active="drawer"
    :sharing="sharing"
    @close="drawer = false"
  )
</template>

<script>
import {
  RssIcon,
  EditIcon,
  LinkIcon,
  CopyIcon,
  CheckIcon,
  UserXIcon,
  Share2Icon,
  CameraIcon,
  XSquareIcon,
  SettingsIcon,
  UserPlusIcon,
  PhoneCallIcon,
  BarChart2Icon,
  UserCheckIcon,
  UserMinusIcon,
  CheckSquareIcon,
  MoreVerticalIcon,
  MessageCircleIcon,
  AlertTriangleIcon
} from 'vue-feather-icons'
import CoverUploader from '@/lazy-components/CoverUploader.vue'
import { generateUrl, generateAssetUrl, parseImage } from '@/utilities/helpers'
import DropdownNetworkSharing from '~/lazy-components/DropdownNetworkSharing.vue'

export default {
  name: 'UserProfilePage',

  components: {
    CoverUploader,
    RssIcon,
    EditIcon,
    LinkIcon,
    CopyIcon,
    UserXIcon,
    CheckIcon,
    Share2Icon,
    CameraIcon,
    XSquareIcon,
    SettingsIcon,
    UserPlusIcon,
    PhoneCallIcon,
    BarChart2Icon,
    UserCheckIcon,
    UserMinusIcon,
    CheckSquareIcon,
    MoreVerticalIcon,
    MessageCircleIcon,
    AlertTriangleIcon,
    DropdownNetworkSharing
  },

  async asyncData ({ params, $api, $auth, error, env, route }) {
    let user = null
    const authUser = $auth.user || null
    const username = encodeURIComponent(params.username) || encodeURIComponent(authUser.username)
    let projects
    let title
    let description
    try {
      const response = await $api.user.getUserByUsername(username)
      user = response.data
      if (!user) return error({
        statusCode: 404,
        message: 'pages.error.account_does_not_exist'
      })
      projects = user.links? user.links.map(link => ({
        ...link.project,
        link: link._id
      })) || [] : []
      title = user.fullName || user.username || user.phoneNumber || user.publicAddress
      description = `${user.username} in Meta365, ${user.phoneNumber} in Meta365`
    } catch (e) {
      const data = e.response?.data
      return error({
        statusCode: data?.statusCode,
        message: data?.message
      })
    }

    return {
      domain: env.domain,
      sharing: {
        url: generateUrl(`${route.path}`, env.domain),
        title,
        description,
        quote: 'Meta365 plans to introduce a real estate portal, where you can own and operate a portfolio of high-quality development properties in Metaverses.',
        hashtags: 'meta365,vr,ar',
        // twitterUser: 'youyuxi'
      },
      user,
      projects,
      isOwner: !!(authUser && user._id === authUser._id),
      authUser
    }
  },

  data () {
    return {
      drawer: false,
      editableDescription: false,
      isChangeCover: false,
      loadingCropper: false,
      loading: false,
      cover: {
        src: null,
        type: 'image/png'
      },
      description: '',
      activeTab: null,
      following: false,
      alias: 'North Sky',
      followerCount: 0,
      followingCount: 0,
      networks: [
        { network: 'email', name: 'Email', icon: 'gmail.svg', color: '#333333' },
        { network: 'facebook', name: 'Facebook', icon: 'facebook.svg', color: '#1877f2' },
        { network: 'linkedin', name: 'LinkedIn', icon: 'linkedin.svg', color: '#007bb5' },
        { network: 'messenger', name: 'Messenger', icon: 'messenger.svg', color: '#0084ff' },
        { network: 'sms', name: 'SMS', icon: 'sms.svg', color: '#333333' },
        { network: 'telegram', name: 'Telegram', icon: 'telegram.svg', color: '#0088cc' },
        { network: 'twitter', name: 'Twitter', icon: 'twitter.svg', color: '#1da1f2' },
      ],
      animationFrame: null
    }
  },

  head () {
    const title = this.user.fullName || this.user.username || this.user.phoneNumber || this.user.publicAddress
    const description = this.user.description || `${this.user.username || this.user.fullName} in Meta365`
    return {
      title,
      description,
      meta: [
        {
          hid: 'og:title',
          property: 'og:title',
          content: title
        },
        {
          hid: 'og:description',
          property: 'og:description',
          content: description
        },
        {
          hid: 'keywords',
          property: 'keywords',
          content: [
            this.user.fullName,
            this.user.phoneNumber,
            this.user.email,
            this.user.username,
          ].filter(key => key).join(', ')
        },
        {
          property: 'og:image',
          content: this.avatar
        },
        {
          hid: 'og:url',
          property: 'og:url',
          content: generateUrl(this.$route.path, this.domain)
        },
        {
          hid: 'og:type',
          property: 'og:type',
          content: 'website'
        },
        {
          hid: 'og:site_name',
          property: 'og:site_name',
          content: process.env.DOMAIN
        },
        {
          hid: 'og:locale',
          property: 'og:locale',
          content: this.user.country
        },
        {
          hid: 'og:image:type',
          property: 'og:image:type',
          content: 'image/png'
        },
        {
          hid: 'twitter:site',
          property: 'twitter:site',
          content: process.env.DOMAIN
        },
        {
          hid: 'twitter:title',
          name: 'twitter:title',
          content: title
        },
        {
          hid: 'twitter:description',
          name: 'twitter:description',
          content: description
        },
        {
          hid: 'twitter:creator',
          property: 'twitter:creator',
          content: process.env.DOMAIN
        },
        {
          hid: 'twitter:image:src',
          property: 'twitter:image:src',
          content: this.avatar
        },
        {
          hid: 'twitter:domain',
          property: 'twitter:domain',
          content: generateUrl('', this.domain)
        },
        {
          hid: 'twitter:image',
          name: 'twitter:image',
          content: this.avatar
        },
        {
          hid: 'og:type',
          name: 'og:type',
          content: 'article'
        },
        {
          hid: 'twitter:url',
          name: 'twitter:url',
          content: generateUrl(this.$route.path, this.domain)
        },
        {
          hid: 'og:publish_date',
          name: 'og:publish_date',
          content: this.user.createdAt
        },
        {
          hid: 'og:author',
          name: 'og:author',
          content: 'Meta365'
        }
      ]
    }
  },

  computed: {
    avatar () {
      const avatar = this.user.avatar
      if (!avatar) return generateUrl('/winking.png', this.domain)
      return parseImage(avatar)
    },

    coverParse () {
      if (!this.user.cover) return null
      return parseImage(this.user.cover)
    }
  },

  watch: {
    '$auth.loggedIn' (val) {
      if (val) {
        this.authUser = this.$auth.user
        this.isOwner = !!(this.authUser && this.user._id === this.authUser._id)
        return
      }
      this.isOwner = false
      this.authUser = null
    },

    activeTab (value, oldValue) {
      if(value === oldValue || value === this.$route.query.tab) return
      const query = {
        ...this.$route.query,
        tab: value
      }
      this.$router.replace({ query })
    }
  },

  created () {
    this.activeTab = this.$route.query.tab || 'projects'
  },

  mounted () {
    this.description = this.user.description
    document.addEventListener('scroll', e => {
      this.animationFrame = window.requestAnimationFrame(this.scroll)
    })
    window.addEventListener('resize', this.handleResizeWindow)
  },

  beforeDestroy () {
    document.removeEventListener('scroll', e => {
      window.cancelAnimationFrame(this.animationFrame)
    })
    window.removeEventListener('resize', this.handleResizeWindow)
  },

  methods: {
    generateAssetUrl,

    handleResizeWindow () {
      const landing = document.getElementById('app-landing')
      if (landing && this.isChangeCover) {
        const bg = document.getElementById('app-landing-bg')
        const w = bg.offsetWidth
        landing.style.height = (w / 3.225 - 10) + 'px'
      } else {
        landing.style.height = ''
      }
    },

    scroll(s) {
      const scrollPos = window.scrollY;
      const landing = document.getElementById('app-landing')
      const bg = document.getElementById('app-landing-bg')
      const content = document.getElementById('app-content')
      const profileHeader = document.getElementById('app-profile-header')

      if (!bg || !content || !landing || !profileHeader) return

      // Transform BG
      if (scrollPos < 260) { bg.style.marginTop = scrollPos / 2+'px'; }

      // Avatar Animation
      const percentage = Math.max(Math.min((scrollPos - 260) / 84 * 1.05, 1), 0)
      const	max = 140
      const min = 56
      const diff = max - min
      const dimensions = max - (diff * percentage)

      const avatar = content.querySelector('.profile-header .avatar')
      avatar.style.width  = dimensions + 'px'
      avatar.style.height = dimensions + 'px'
      avatar.style.transform = 'translate(0,-'+ ((percentage * 50) * -1 + 50) +'%)'
      avatar.style.marginTop = percentage * 10 + 'px'
      profileHeader.style.gridTemplateColumns = (dimensions + 40) + 'px auto auto'
      const backgroundTool = content.querySelector('.profile-header .background-tool')
      const wrap = content.querySelector('.profile-header .upload')

      if (wrap && backgroundTool) {
        wrap.style.width = 8 + diff + 'px'
        wrap.style.height = 36 - (36 - 32) * percentage + 'px'
        wrap.style.transform = 'translate(0,'+ -((percentage * 20) * -1 - 10) +'%)'
        backgroundTool.style.width  = dimensions + 'px'
        backgroundTool.style.height = 70 - (70 - 30) * percentage + 'px'
        if (parseInt(percentage * 100) > 50) {
          wrap.style.display = 'none'
          backgroundTool.style.display = 'none'
        } else {
          backgroundTool.style.transform = 'translate(0,'+ (percentage * 30) +'%)'
          wrap.style.display = 'block'
          backgroundTool.style.display = 'flex'
        }
      }

      // Lock Landing Image & Profile Header
      if (scrollPos >= 300) {
        landing.classList.add('locked')
        content.classList.add('header-locked')
      }
      else {
        landing.classList.remove('locked')
        content.classList.remove('header-locked')
      }
    },

    onClickOpenSharePopup () {
      this.drawer = true
    },

    closeSharePopup(network) {
    },

    clipboardSuccess () {
      this.$message({
        type: 'success',
        message: this.$t('common.copied')
      })
    },

    onClickMessage () {
      return this.$message({
        type: 'info',
        message: this.$t('common.feature_under_development')
      })
    },

    onClickFollow () {
      if (!this.$auth.loggedIn) {
        return this.$router.replace({
          query: {
            ...this.$route.query,
            'request-login': true
          }
        })
      }
      return this.$message({
        type: 'info',
        message: this.$t('common.feature_under_development')
      })
      // this.following = !this.following
    },

    onClickPreviewImage (index) {
      const medias = [
        {
          url: this.coverParse,
          type: 'image'
        },
        {
          url: this.avatar,
          type: 'image'
        }
      ]
      if (!medias[index] || !medias[index].url) return
      this.$preview({
        parent: this,
        index,
        medias
      })
    },

    onClickOpenChangeSocialLink () {
      if(!this.isOwner) return
      return this.$flows.social({
        parent: this,
        socials: this.user.socials
      })
        .then(async (res) => {
          await this.fetchProfile(res.data.user)
        })
    },

    async fetchProfile (user) {
      if (this.isOwner) {
        this.$auth.setUser(user)
      }
      const response = await this.$api.user.getUserByUsername(encodeURIComponent(this.user.username))
      this.user = response.data
    },

    onClickUploadAvatar () {
      if(!this.isOwner) return
      this.$flows.avatarUploader({
        parent: this,
        src: this.avatar
      })
        .then(async (res) => {
          await this.fetchProfile(res.data.user)
        })
    },

    onClickChangeCover () {
      this.isChangeCover = true
      this.handleResizeWindow()
      this.loadingCropper = true
    },

    loadImage(payload) {
      this.cover = payload
      this.onClickChangeCover()
    },

    onClickCropCover () {
      this.$refs.coverCropper.onCrop()
    },

    onUploadCover (payload) {
      const form = new FormData()
      form.append('file', payload)
      this.loading = true
      this.$api.user.updateCover(form)
        .then(async (res) => {
          this.resetCropper()
          await this.fetchProfile(res.data.user)
        })
        .catch((error) => {
          this.$notify.error({
            message: error.response.data.message || this.$t('notification.error.upload_cover_failed'),
          })
        })
        .finally(() => {
          this.loading = false
        })
    },

    resetCropper () {
      this.isChangeCover = false
      this.cover = {
        src: null,
        type: 'image/png'
      }
    },

    onClickSaveDescription () {
      return this.$api.user.updateProfile({
        description: this.description
      })
        .then(async (res) => {
          await this.fetchProfile(res.data.user)
          this.editableDescription = false
        })
        .catch((error) => {
          this.$notify.error({
            message: error.response.data.message || this.$t(''),
          })
        })
        .finally(() => {
        })
    },

    onHandleDeleteLink (id) {
      this.$api.link.deleteLink(id)
        .then(() => {
          this.$message({
            type: 'success',
            message: this.$t('notification.deleted_the_sale_link_successfully')
          })
          this.projects = this.projects.filter(item => item.link !== id)
        })
        .catch((error) => {
          this.$message({
            type: 'error',
            message: this.$t(error.response.data.message || 'notification.error.delete_sale_link_failed')
          })
        })
    }
  }
}
</script>

<style lang="scss" scoped>
// -----------------------------------------------------
// COLORS
$color-custom-brand: #7597C7;

$opac-1: 0.8;
$opac-2: 0.5;
$opac-3: 0.3;
$opac-4: 0.1;
$opac-5: 0.05;

// TYPE
p {
  font-size: $--size-base;
  white-space: pre-wrap;
  word-break: break-word;
  color: rgba(var(--color-shade-6), $opac-2);
}
.type-title {
  font-size: 24px;
  margin: 0;
  margin-top: 10px;
  color: rgba(var(--color-shade-6), $opac-2);
  @include media(sm-down) {
    font-size: 20px;
  }
}
.type-subtitle {
  font-size: 18px;
  font-weight: lighter;
  margin: 0;
  color: rgba(var(--color-shade-6), $opac-3);
  @include media(sm-down) {
    font-size: 16px;
  }
}
.type-heading-4 {
  font-weight: bold;
  font-size: 24px;
  line-height: 28px;
  margin: 0;
  color: rgba(var(--color-shade-6), $opac-2);
}
.type-caption {
  font-size: $--size-base;
  margin: 0;
  color: rgba(var(--color-shade-6), $opac-3);
  text-transform: uppercase;
  font-weight: 500;
  margin-bottom: 4px !important;
}

.user-profile-page {
  min-height: calc(100vh - $--header-height);
  background: var(--color-shade-0);
  @include media(sm-down) {
    min-height: calc(100vh - $--header-height-mobile);
  }
  .container {
    max-width: 1200px;
  }
}

#app-landing {
  width: 100%;
  height: 372px;
  max-height: 372px;
  min-height: 155px;
  overflow: hidden;
  background: #74ebd5; /* fallback for old browsers */
  background: -webkit-linear-gradient(to bottom, var(--color-bg-header) 0%, #acb6e584 40%, var(--color-shade-0)); /* Chrome 10-25, Safari 5.1-6 */
  background: linear-gradient(to bottom, var(--color-bg-header) 0%, #acb6e584 40%, var(--color-shade-0)); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
  @include media(md-down) {
    height: 300px;
  }
  @include media(xs) {
    height: 268px;
  }
  @include media(mobile) {
    height: 160px;
  }
}

::v-deep#app-landing-bg {
  // width: 100%;
  // max-width: initial !important;
  height: 100%;
  margin-top: 0;
  position: relative;
  user-select: none;
  border-bottom-left-radius: 24px;
  .cover {
    cursor: zoom-in;
    border-bottom-left-radius: 24px;
    background-size: cover !important;
    background-position: center !important;
    height: 100%;
  }
  &.cropper {
    .cover {
      display: none;
    }
    @include media(xs) {
      padding: 0;
    }
    overflow: hidden;
    .overlay {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      width: 100%;
      height: 100%;
      backdrop-filter: blur(4px);
    }
  }

  .change-cover {
    background: $--color-text-secondary;
    padding: 6px 10px;
  }

  .change-cover, .crop-cover {
    cursor: pointer;
    position: absolute;
    border-radius: 10px;
    bottom: 10px;
    right: 25px;
    display: flex;
    color: rgba($--color-info, 0.8);
    @include media(xs) {
      bottom: 8px;
      padding: 4px 10px;
      span {
        margin-left: 0;
        display: none;
      }
    }
  }

  .crop-cover {
    &.loading {
      .re-upload, .cancel, .save {
        pointer-events: none;
        background-color: rgba(var(--color-shade-2), 0.8);
        .el-loading-mask {
          border-radius: 10px;
          background-color: var(--color-shade-3);
          .el-loading-spinner {
            margin-top: -10px;
          }
        }
      }
    }
    .re-upload, .cancel, .save {
      padding: 6px 10px;
      border-radius: 10px;
      display: flex;
      color: var(--color-shade-6);
      background-color: var(--color-shade-2);
    }
  }
  .re-upload, .change-cover {
    cursor: pointer;
    input {
      position: absolute;
      visibility: hidden;
    }
  }

  &.locked {
    #app-landing-bg {
      position: fixed;
      // position: sticky;
      width: 100%;
      height: $--header-height;
      top: 0;
      left: 0;
      margin-top: 0 !important;
      .change-cover {
        display: none;
      }
      @include media(sm-down) {
        height: $--header-height-mobile;
      }
    }
  }
}

// CONTENT
#app-content {
  margin: auto;
  display: grid;
  grid-template-columns: auto 456px;
  grid-template-rows: 80px auto;
  gap: 30px 10px;

  @include media(md-down) {
    grid-template-columns: auto 400px;
  }

  // @include media(md-down) {
  // 	width: 100%;
  // }
  @include media(sm-down) {
    grid-template-columns: 100%;
  }

  .profile-header {
    grid-column-start: 1;
    grid-column-end: 3;
    height: 74px;
    display: grid;
    grid-template-columns: 180px auto auto;
    grid-template-rows: 74px;
    padding-bottom: 10px;
    border-bottom: 1px solid var(--color-shade-2);

    @include media(sm-down) {
      grid-column-start: 1;
      grid-column-end: 2;
      .title { margin-top: 16px; }
      .title, .subtitle { font-size: 18px; }
    }
    @include media(xs) {
      grid-template-columns: 80px auto auto !important;
      .avatar {
        width: 48px !important;
        height: 48px !important;
        transform: translate(0, 0) !important;
        margin-top: 8px !important;
        margin-left: 12px !important;
      }
      .upload {
        display: none;
      }
    }

    .profile-avatar {
      position: relative;
      .upload {
        position: absolute;
        background: transparent;
        left: 16px;
        z-index: 1;
        width: 148px;
        height: 36px;
        bottom: 10px;
        backdrop-filter: blur(2px);
      }
      .avatar {
        width: 140px;
        height: 140px;
        border: 4px solid var(--color-shade-2);
        border-radius: 50%;
        margin-left: 16px;
        transform: translate(0,-50%);
        cursor: zoom-in;
        user-select: none;
      }
      .background-tool {
        position: absolute;
        background: transparent;
        left: 16px;
        bottom: 0px;
        z-index: 1;
        width: 140px;
        border: 4px solid var(--color-shade-2);
        border-top: none;
        border-bottom-left-radius: 140px;
        border-bottom-right-radius: 140px;
        height: 70px;
        display: flex;
        flex-direction: column;
        .feather {
          color: var(--color-shade-5);
        }
        .top {
          height: 70px;
          cursor: zoom-in;
        }
        .bottom {
          height: 70px;
        }
      }
    }

    .username-and-contact {
      margin-left: 4px;
      padding-top: 8px;
      max-width: 600px;
      // @include media(md-down) {
      //   max-width: 600px;
      //   // max-width: calc(100vw - 208px);
      // }
      @include media(sm-down) {
        max-width: 400px;
      }
      @include media(xs) {
        max-width: 300px;
      }
      @include media(mobile) {
        max-width: calc(100vw - 218px);
      }
      .verified {
        margin-left: 4px;
        border-radius: 50%;
        background: var(--color-primary);
        height: 22px;
        width: 22px;
        flex: 0 0 22px;
        display: flex;
        justify-content: center;
        align-items: center;
      }
      .username {
        margin-top: 0!important;
        margin-bottom: 10px;
        max-width: 576px;
        .value {
          font-size: 22px;
        }
        @include media(sm-down) {
          max-width: calc(100% - 6px);
        }
      }
      .contact {
        color: var(--color-shade-5);
        a:-webkit-any-link {
          color: var(--color-shade-5);
        }
        .feather {
          cursor: pointer;
          &:hover {
            color: var(--color-primary);
          }
        }
      }
    }
  }

  &.header-locked .profile-header {
    position: sticky;
    top: 72px;
    grid-template-columns: 80px auto auto;
    z-index: 100;
    box-shadow: 0px 1px 5px 3px rgb(0 0 0 / 10%);
    background: var(--color-shade-1);
    @include media(sm-down) {
      top: 56px;
    }
    @include media(md-down) {
      width: 100%;
    }
    .avatar {
      width: 60px;
      height: 60px;
      transform: translate(0, 0);
      margin-top: 12px;
    }
    .background-tool, .upload {
      display: none;
    }
  }
  .profile-content {
    padding: 4px 0 8px;
    grid-row-start: 2;
    @include media(sm-down) {
      grid-row-start: 3;
    }

    .content-navigation ul {
      height: 49px;
      padding: 0;
      list-style: none;
      margin: 0 16px;

      li {
        float: left;
        padding: 16px;
        cursor: pointer;

        &:hover {
          background: var(--color-shade-2);
        }
        &.active {
          color: $color-custom-brand;
          background: rgba($color-custom-brand, 0.15);
          box-shadow: 0 4px 0 $color-custom-brand inset;
        }
      }
    }
  }
  .profile-details {
    padding: 16px;
    grid-row-start: 2;
    @include media(sm-down) { grid-row-start: 2; }
    &__label {
      margin-bottom: 9px!important;
    }
    .detail-section {
      margin-bottom: 24px;
      &:last-child {
        margin-bottom: 0px;
      }
      .add-social-link {
        background: transparent;
        border: none;
        color: var(--color-shade-6);
        border-radius: 50%;
        padding: 6px!important;
      }
    }
  }
}

::v-deep.profile-actions {
  min-width: 60px;
  justify-self: right;
  padding: 16px 0px 16px 0;

  button, a {
    color: var(--color-shade-5);
    background: transparent;
    border: none;
    padding: 16px 8px;
    margin: 0 1px;
    cursor: pointer;
    vertical-align: top;
    float: left;
    height: 48px;
    border-radius: 4px;
    transition: 0.1s ease;
    font-size: $--size-base;
    text-transform: uppercase;
    @include media(xs) {
      padding: 16px 8px;
    }
    &.more-btn {
      padding: 12px 8px;
    }

    &:focus { outline: none; }
    &:hover { background: var(--color-shade-2) }

    &.following-true {
      color: $color-custom-brand;
      background: rgba($color-custom-brand, 0.15);
    }
  }
  a {
    padding: 0 12px;
  }
}
</style>

<style lang="scss">
.social-share-dropdown {

}
</style>
