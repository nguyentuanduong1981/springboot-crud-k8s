<template lang="pug">
.setting-page.main-page
  el-container
    el-aside(width="300px")
      h2.setting-page__title {{ $t('navigation.settings') }}
      el-divider.underline-title
      ul.setting-page__nav
        component.flex-center-y.setting-page__nav__item(
          v-for="i in sideBarItems"
          :key="i.name"
          :is="i.divider ? 'el-divider' : 'li'"
          :class="{ 'is-active': i.name === activeTab }"
          @click="onClickChangeActiveTab(i.name)"
        )
          component.mr-4(
            :is="i.icon"
            size="24"
          )
          span {{ $t(i.label) }}
    el-main(
      :class="{ disabled: onlyBroker }"
    )
      .overlay
        h4(align="center") {{ $t('pages.settings.for_broker_only') }}
        //- @click.native="onClickBecomeABroker()"
        el-button.el-button--highlight(
        ) {{ $t('navigation.become_a_broker') }}
      .layout.container
        template(
          v-if="activeTab === 'account'"
        )
          SettingGeneral(
            :domain="domain"
          )

        template(
          v-if="activeTab === 'security_and_login'"
        )
          SettingSecurityAndLogin

        template(
          v-else-if="activeTab === 'statistic_and_analysis'"
        )
          div
            el-row(:gutter="12")
              el-col(
                :md="8"
                :sm="12"
                :xs="24"
              )
                el-card.stat-card#projects-stats(shadow="always")
                  .flex-column
                    .title {{ $t('pages.settings.projects') }}
                    .total 0
                  LayersIcon(
                    size="30"
                  )
              el-col(
                :md="8"
                :sm="12"
                :xs="24"
              )
                el-card.stat-card#views-stats(shadow="always")
                  .flex-column
                    .title {{ $t('pages.settings.views') }}
                    .total 0
                  EyeIcon(
                    size="30"
                  )
              el-col(
                :md="8"
                :sm="12"
                :xs="24"
              )
                el-card.stat-card#earns-stats(shadow="always")
                  .flex-column
                    .title {{ $t('pages.settings.earns') }}
                    .total 0
                  CreditCardIcon(
                    size="30"
                  )
            el-row(:gutter="12")
              el-col(
                :md="12"
                :sm="24"
              )
                el-card.anal-card#projects-anal(shadow="always")
                  ChartPie(
                    :title="$t('pages.settings.projects')"
                  )
              el-col(
                :md="12"
                :sm="24"
              )
                el-card.anal-card#views-anal(shadow="always")
                  ChartLine(
                    :title="$t('pages.settings.views')"
                  )

</template>

<script>
import { ShieldIcon, SettingsIcon, BellIcon, UserXIcon, TrendingUpIcon, HelpCircleIcon, EditIcon, LayersIcon, EyeIcon, CreditCardIcon } from 'vue-feather-icons'
import { generateUrl } from '@/utilities/helpers'
import { USER_TYPE } from '@/utilities/constants'
import steps from '@/guides/statistic-and-analytics'

export default {
  name: 'SettingsPage',

  components: {
    EyeIcon,
    BellIcon,
    EditIcon,
    UserXIcon,
    LayersIcon,
    ShieldIcon,
    SettingsIcon,
    CreditCardIcon,
    HelpCircleIcon,
    TrendingUpIcon,
  },

  middleware: 'auth',

  asyncData ({ env }) {
    return {
      domain: env.domain
    }
  },

  data () {
    return {
      USER_TYPE,
      activeTab: '',
      sideBarItems: [
        {
          name: 'account',
          label: 'pages.settings.general',
          icon: 'SettingsIcon',
          divider: false
        },
        {
          name: 'security_and_login',
          label: 'pages.settings.security_and_login',
          icon: 'ShieldIcon',
          divider: false
        },
        // {
        // divider: true
        // },
        // {
        //   name: 'notifications',
        //   label: 'pages.settings.notifications',
        //   icon: 'BellIcon',
        //   divider: false
        // },
        // {
        //   name: 'blocking',
        //   label: 'pages.settings.blocking',
        //   icon: 'UserXIcon',
        //   divider: false
        // },
        // {
        //   name: 'statistic_and_analysis',
        //   label: 'pages.settings.statistics_and_analysis',
        //   icon: 'TrendingUpIcon',
        //   divider: false
        // },
        // {
        //   divider: true
        // },
        // {
        //   name: 'support_mailbox',
        //   label: 'pages.settings.support_mailbox',
        //   icon: 'HelpCircleIcon',
        //   divider: false
        // },
      ],
      termForm: {
        isAccept: false
      },
      driver: null
    }
  },

  computed: {
    user () {
      return this.$auth.user
    },

    onlyBroker () {
      return ['statistic_and_analysis'].includes(this.activeTab) && this.user.userType === this.USER_TYPE.NORMAL
    }
  },

  watch: {
    '$auth.loggedIn' (val) {
      if (val) {
        this.authUser = this.$auth.user
        this.isOwner = !!(this.authUser && this.user._id === this.authUser._id)
        return
      }
      this.isOwner = false
      this.authUser = null
    },

    activeTab (value, oldValue) {
      if(value === oldValue || value === this.$route.query.tab) return
      const query = {
        ...this.$route.query,
        tab: value
      }
      this.$router.replace({ query })
    }
  },

  created () {
    this.activeTab = this.$route.query.tab || 'account'
  },

  mounted () {
    this.driver = this.$guide
  },

  methods: {
    generateUrl,
    onClickChangeActiveTab (active) {
      if (!active) return
      this.activeTab = active
    },

    guide () {
      this.driver.defineSteps(steps)
      this.$nextTick(() => {
        setTimeout(() => {
          this.driver.start()
        }, 100)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
::v-deep.setting-page {
  padding: 0;
  background-color: var(--color-shade-0);
  .space {
    width: 16px;
  }
  .el-container {
    .el-tabs {
      &__item {
        color: var(--color-shade-1);
        &.is-active {
          color: var(--color-primary);
        }
      }
      &__nav-wrap {
        padding: 0 14px;
        &::after {
          background-color: transparent;
        }
      }
      .form-label {
        font-size: $--size-base;
      }
    }
    .el-aside {
      position: sticky;
      top: $--header-height;
      align-self: flex-start;
      background: var(--color-bg-header);
      height: calc(100vh - $--header-height);
      box-shadow: 0px 5px 5px 0px var(--color-shade-3);
      padding: 6px 10px;
      transition: width 0.2s ease-in-out;
      @include media(xs) {
        top: $--header-height-mobile;
        width: 64px!important;
        .setting-page__title, .underline-title {
          display: none;
        }
        .setting-page__nav {
          li {
            padding: 6px;
            .feather {
              width: 30px;
              height: 30px;
              margin: 0;
            }
            span {
              transition: opacity 0.1s ease;
              transition-delay: 0.12s;
              display: none;
              opacity: 0;
            }
          }
        }
      }
      @include media(sm-down) {
        height: calc(100vh - $--header-height-mobile);
      }
      .el-divider {
        margin: 8px 0;
      }
    }
    .el-main {
      position: relative;
      overflow: hidden;
      @include media(mobile) {
        padding: 20px 15px;
      }
      &.disabled {
        .overlay {
          flex-direction: column;
          display: flex;
          justify-content: center;
          align-items: center;
        }
      }
      .overlay {
        display: none;
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 1;
        &::before {
          background-color: rgba($--color-info, 0.4);
          backdrop-filter: blur(5px);
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          z-index: -1;
        }
      }
      .layout {
        max-width: 992px;
        margin: 0 auto;
        @include media(mobile) {
          padding: 0;
        }
      }
      .el-form {
        &-item__content {
          display: flex;
        }
        .el-alert {
          word-break: break-word;
          margin: 0 0 20px 120px;
          width: calc(100% - 120px - 84px);
        }
        @include media(xs) {
          &.el-form--label-left {
            .el-alert {
              margin: 0 0 4px;
              width: 100%;
            }
          }
        }
      }
      .stat-card {
        margin: 6px 0;
        .el-card__body {
          display: flex;
          align-items: center;
          justify-content: space-between;
          .total {
            font-weight: 500;
            font-size: 18px;
          }
          .title {
            font-size: 18px;
            font-family: sans-serif;
            font-weight: 600;
          }
        }
      }
      .anal-card {
        margin: 6px 0;
        .el-card__body {
          padding: 20px 6px 0;
        }
      }
    }
  }
  &__title {
    color: var(--color-shade-6);
    padding: 0 6px;
    font-size: 20px;
    margin-top: 10px;
    margin-bottom: 0;
  }
  &__nav {
    list-style: none;
    padding: 0;
    li {
      color: var(--color-shade-5);
      line-height: 24px;
      height: 32px;
      padding: 6px 10px;
      border-radius: $--radius-medium;
      cursor: pointer;
      user-select: none;
      margin: 4px 0;
      font-weight: 500;
      span {
        font-size: $--size-base-md;
        opacity: 1;
      }
      &:hover, &:active, &:focus {
        color: $--color-text-primary;
        background-color: var(--color-shade-3);
      }
      &.is-active {
        background-color: rgba($--color-brand, 0.9);
        .feather {
          color: var(--color-text);
        }
        span {
          color: $--color-text-primary;
        }
      }
    }
  }
}
</style>
