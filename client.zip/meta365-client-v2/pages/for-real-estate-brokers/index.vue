<template lang="pug">
.for-real-estate-customers-page.customer-page
  section.customer-page__banner(
    v-image="'/for-real-estate-customers.webp'"
  )
    h1.customer-page__title {{ $t('pages.for_real_estate_brokers.title') }}
  section.container
    el-row.flex-center-y.p-10(
      type="flex"
      :gutter="20"
    )
      el-col.py-10(:sm="24" :md="12")
        h1 {{ $t('pages.for_real_estate_brokers.what_is_decentralized_real_estate_broker') }}
        p {{ $t('pages.for_real_estate_brokers.meta365_develops') }}

    .clearfix
    h2.text-center {{ $t('pages.for_real_estate_brokers.benefit') }}
    el-row.flex-center-y.p-10(
      type="flex"
      :gutter="20"
    )
      el-col.py-10(:sm="24" :md="12")
        nuxt-img.fw(
          src="/for-real-estate-customers-4.webp"
        )
      el-col.py-10(:sm="24" :md="12")
        ol.decial
          li {{ $t('pages.for_real_estate_brokers.benefit_1') }}
          li {{ $t('pages.for_real_estate_brokers.benefit_2') }}
          li {{ $t('pages.for_real_estate_brokers.benefit_3') }}

    .clearfix

    el-row.flex-center-y.p-10(
      type="flex"
      :gutter="20"
    )
      el-col.py-10(:sm="24" :md="12")
        ol(start="4").decimal
          li {{ $t('pages.for_real_estate_brokers.benefit_4') }}
          li {{ $t('pages.for_real_estate_brokers.benefit_5') }}
          li {{ $t('pages.for_real_estate_brokers.benefit_6') }}
          li {{ $t('pages.for_real_estate_brokers.benefit_7') }}
          li {{ $t('pages.for_real_estate_brokers.benefit_8') }}
      el-col.py-10(:sm="24" :md="12")
        .text-center
          nuxt-img.w-60(
            src="/for-real-estate-customers-5.webp"
          )

      .clearfix

      el-row.flex-center-y.p-10(
        type="flex"
        :gutter="20"
      )
        el-col.py-10(:sm="24" :md="12")
          .text-center
            nuxt-img.w-60(
              src="/for-real-estate-customers-6.webp"
            )
        el-col.py-10(:sm="24" :md="12")
          ol(start="9").decimal
            li {{ $t('pages.for_real_estate_brokers.benefit_9') }}
            li {{ $t('pages.for_real_estate_brokers.benefit_10') }}
            li {{ $t('pages.for_real_estate_brokers.benefit_11') }}
            li {{ $t('pages.for_real_estate_brokers.benefit_12') }}
          el-button(
            type="primary"
            @click.native="login"
          ) {{ $t('pages.for_real_estate_brokers.register_now') }}
  Footer.mt-30
</template>

<script>
import { Swiper, SwiperSlide, directive } from 'vue-awesome-swiper'
import { MapPinIcon, MailIcon, MapIcon, PhoneCallIcon, ChevronRightIcon, ChevronLeftIcon, ChevronDownIcon } from 'vue-feather-icons'
import 'swiper/css/swiper.css'
import { generateUrl } from '@/utilities/helpers'
import SunGroup from '@/assets/images/partners/sun-group.svg?inline'
import Hub from '@/assets/images/partners/hub.svg?inline'
import NovaWorld from '@/assets/images/partners/nova-world.svg?inline'
import MshGroup from '@/assets/images/partners/msh-group.svg?inline'
import Red from '@/assets/images/partners/red.svg?inline'
import Fibo from '@/assets/images/partners/fibo.svg?inline'
import Dns from '@/assets/images/partners/dns.svg?inline'
import Utc from '@/assets/images/partners/utc.svg?inline'
import Fgi from '@/assets/images/partners/fgi.svg?inline'
import CenGroup from '@/assets/images/partners/cen-group.svg?inline'
import CenHousing from '@/assets/images/partners/cen-housing.svg?inline'
import MicHolding from '@/assets/images/partners/mic-holding.svg?inline'
import HungVuong from '@/assets/images/partners/hungvuong.svg?inline'

export default {
  name: 'ForRealEstateEnterprisesPage',

  components: {
    Swiper,
    MapIcon,
    MailIcon,
    MapPinIcon,
    SwiperSlide,
    PhoneCallIcon,
    ChevronLeftIcon,
    ChevronDownIcon,
    ChevronRightIcon,
    SunGroup,
    Hub,
    NovaWorld,
    MshGroup,
    Red,
    Fibo,
    Dns,
    Utc,
    Fgi,
    CenGroup,
    CenHousing,
    MicHolding,
    HungVuong
  },

  directives: {
    swiper: directive,
  },

  data () {
    return {
      swiperPartnersOptions: {
        grabCursor: true,
        loop: true,
        slidesPerView: 2,
        spaceBetween: 10,
        // freeMode: true,
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
          dynamicBullets: true,
        },
        navigation: {
          nextEl: '.partner-swiper-next',
          prevEl: '.partner-swiper-prev'
        },
        autoplay: {
          delay: 1000,
          disableOnInteraction: false,
        },
        breakpoints: {
          992: {
            slidesPerView: 5,
            spaceBetween: 10,
          },
          768: {
            slidesPerView: 4,
            spaceBetween: 10,
          },
          576: {
            slidesPerView: 2,
            spaceBetween: 10,
          },
          325: {
            slidesPerView: 1,
            spaceBetween: 10,
          },
        },
      },
      partners: [
        'SunGroup',
        'Hub',
        'NovaWorld',
        'MshGroup',
        'Red',
        'Fibo',
        'Dns',
        'Utc',
        'Fgi',
        'CenGroup',
        'CenHousing',
        'MicHolding',
        'HungVuong',
      ],
    }
  },

  head () {
    const description = 'META365 is a Leader in Applied Imaging Technology. Operating since 2018, META365 exploits VR360 imaging technologies, AI Artificial Intelligence, Big Data ... with the aim of building a Decentralized Real Estate Transaction Center to bring traditional Real Estate into the Metaverse Universe. As a completely new model of a real estate transaction center, the application of metaverses makes buying and selling real estate easier.'
    return {
      title: 'For Real Estate Enterprise',
      meta: [
        {
          hid: 'og:title',
          property: 'og:title',
          content: 'For Real Estate Enterprise'
        },
        {
          hid: 'og:description',
          property: 'og:description',
          content: description
        },
        {
          property: 'og:image',
          content: generateUrl('/pano.jpg')
        },
        // {
        //   hid: 'og:url',
        //   property: 'og:url',
        //   content: generateUrl(this.$route.path)
        // },
        // {
        //   hid: 'og:type',
        //   property: 'og:type',
        //   content: 'website'
        // },
        // {
        //   hid: 'og:site_name',
        //   property: 'og:site_name',
        //   content: process.env.DOMAIN
        // },
        // {
        //   hid: 'og:locale',
        //   property: 'og:locale',
        //   content: 'au'
        // },
        // {
        //   hid: 'og:image:type',
        //   property: 'og:image:type',
        //   content: 'image/jpeg'
        // },
        // {
        //   hid: 'twitter:card',
        //   property: 'twitter:card',
        //   content: article.provider_summary
        // },
        // {
        //   hid: 'twitter:site',
        //   property: 'twitter:site',
        //   content: process.env.DOMAIN
        // },
        // {
        //   hid: 'twitter:title',
        //   name: 'twitter:title',
        //   content: article.title
        // },
        // {
        //   hid: 'twitter:description',
        //   name: 'twitter:description',
        //   content: `${article.title}, ${article.source_name}`
        // },
        // {
        //   hid: 'twitter:creator',
        //   property: 'twitter:creator',
        //   content: process.env.DOMAIN
        // },
        {
          hid: 'twitter:image:src',
          property: 'twitter:image:src',
          content: './banner.jpg'
        },
        // {
        //   hid: 'twitter:domain',
        //   property: 'twitter:domain',
        //   content: process.env.DOMAIN
        // },
        {
          hid: 'twitter:image',
          name: 'twitter:image',
          content: './banner.jpg'
        },
        {
          hid: 'og:video:type',
          name: 'og:video:type',
          content: 'application/x-shockwave-flash'
        },
        {
          hid: 'og:video:width',
          name: 'og:video:width',
          content: '400'
        },
        {
          hid: 'og:video:height',
          name: 'og:video:height',
          content: '300'
        },
        {
          hid: 'og:type',
          name: 'og:type',
          content: 'article'
        },
        {
          hid: 'og:video:secure_url',
          name: 'og:video:secure_url',
          content: generateUrl('/tour.swf')
        },
        {
          hid: 'og:video',
          name: 'og:video',
          content: generateUrl('/tour.swf')
        }
        // {
        //   hid: 'twitter:url',
        //   name: 'twitter:url',
        //   content: generateUrl(this.$route.path)
        // },
        // {
        //   hid: 'og:publish_date',
        //   name: 'og:publish_date',
        //   content: article.published_date
        // },
        // {
        //   hid: 'og:author',
        //   name: 'og:author',
        //   content: article.source_name
        // }
      ]
    }
  },

  methods: {
    login () {
      this.$flows.login({
        parent: this
      })
    },
  }
}
</script>

<style lang="scss" scoped>
@import '@/assets/styles/component/customer';
.w-60 {
  margin: 0 auto;
  width: 60%;
}
</style>
