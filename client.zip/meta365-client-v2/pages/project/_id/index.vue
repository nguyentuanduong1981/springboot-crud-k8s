<template lang="pug">
.detail-project-page
  el-breadcrumb.container.d-flex(separator-class="el-icon-arrow-right")
    el-breadcrumb-item
      home-icon
    el-breadcrumb-item(:to="{ path: '/project' }") {{ $t('navigation.project') }}
    el-breadcrumb-item
      | {{ project.name }}

  el-row(:gutter="0" type="flex")
    el-col.main-info(:sm="24" :md="9")
      .hidden-md-and-up
        .wrapper(
          v-loading="iframeLoading"
          element-loading-spinner="el-icon-loading"
          element-loading-background="rgba(0, 0, 0, 0.4)"
        )
          iframe(
            class="fw tour"
            :style="{ height: 'calc(100vh - 302px)' }"
            frameborder="0"
            scrolling="no"
            allowfullscreen
            :src="isVr ? project.media : `https://maps.google.com/maps?q=${project.coordinates.latitude},${project.coordinates.longitude}&hl=es&z=14&output=embed&hl=vi-VN`"
            marginheight="0"
            marginwidth="0"
            @load="iframeLoaded()"
          )

      .main-info__body
        .d-flex.info-project
          //- .logo
          //-   nuxt-img(
          //-     src="https://hungvuongholdings.vn/wp-content/uploads/2021/06/1.png"
          //-     width="80"
          //-   )
          .flex-column
            .name {{ project.name }}
            //- .investor {{ project.investor }}
          .action
            DropdownNetworkSharing.hidden-xs-only(
              :sharing="sharing"
              :networks="networks"
            )
              el-button.more-btn.mr-4(
                size="mini"
                slot="reference"
              )
                Share2Icon.mr-4(
                  size="20"
                )
            el-dropdown(
              trigger="click"
            )
              //- :hide-on-click="false"
              span.el-dropdown-link
                el-button.more-btn(
                  size="mini"
                )
                  MoreVerticalIcon(size="20")
              el-dropdown-menu(
                slot="dropdown"
              )
                el-dropdown-item.flex-center-y.hidden-sm-and-up(@click.stop.native="onClickOpenSharePopup()")
                  Share2Icon.mr-4(size="20")
                  | {{ $t('common.share') }}
                el-dropdown-item.flex-center-y(
                   v-clipboard:copy="sharing.url"
                  v-clipboard:success="clipboardSuccess"
                )
                  CopyIcon.mr-4(size="20")
                  | {{ $t('common.copy_link') }}
                //- template
                //-   el-dropdown-item.flex-center-y
                //-     AlertTriangleIcon.mr-4(size="20")
                //-     | {{ $t('pages.detail_project.report_project') }}
        el-divider.dark.my-2
        el-tabs.v2.mt-20(
          v-model="activeTab"
          type="card"
          stretch
        )
          el-tab-pane.p-2(
            name="info"
            :label="$t('pages.detail_project.information')"
          )
            TabProjectInfo(
              :project="project"
              :favored="cloneFavored"
              @favorite="onClickFavoriteProject"
            )
          el-tab-pane.p-2(
            name="agency"
            :label="$t('pages.detail_project.agency')"
          )
            TabProjectAgency(
              v-if="project.status !== 'lock'"
              :agencies="links"
              :joined="myLink"
              :current-user-id="user ? user._id : ''"
              :domain="domain"
              @onscroll="onInfiniteScroll"
              @refresh="refresh"
              @search="handleSearch"
            )
          //- el-tab-pane.px-2(
          //-   name="evaluate"
          //-   :label="$t('pages.detail_project.evaluate')"
          //- )
          //-   el-empty(
          //-     :image-size="100"
          //-     :description="$t('common.no_reviews_yet')"
          //-     image="/quivering.png"
          //-   )
          //-     el-button(
          //-       type="primary"
          //-     ) {{ $t('common.create_review') }}

    el-col.tour(
      :sm="24"
      :md="15"
    )
      //- v-image="'/banner.png'"
      .hidden-sm-and-down.wrapper(
        v-loading="iframeLoading"
        element-loading-spinner="el-icon-loading"
        element-loading-background="rgba(0, 0, 0, 0.4)"
      )
        iframe(
          frameborder="0"
          scrolling="no"
          allowfullscreen
          :src="isVr ? project.media : `https://maps.google.com/maps?q=${project.coordinates.longitude},${project.coordinates.latitude}&hl=es&z=14&output=embed&hl=vi-VN`"
          marginheight="0"
          marginwidth="0"
          @load="iframeLoaded"
        )
      .tour__action.py-10.hidden-sm-and-down
        el-button(
          @click.native="changeIframe()"
          type="primary"
          size="small"
        )
          | {{ isVr ? $t('pages.detail_project.map') : $t('pages.detail_project.vr') }}
        //- el-button(
        //-   v-if="isVr"
        //-   @click.native="changeIframe()"
        //-   type="primary"
        //-   size="small"
        //- )
        //-   | {{ $t('pages.detail_project.fullscreen') }}
        el-button(
          type="primary"
          size="small"
          v-if="!myLink"
          @click.native="generateMyLink()"
        ) {{ $t('pages.detail_project.register_for_sale') }}

  .bottom-action(
    v-if="!scrollTop"
  )
    el-button.fw(
      icon="el-icon-message"
      type="primary"
      @click.native="onClickOpenContactUsModal()"
    )
      | {{ $t('pages.detail_project.contact_us') }}
    el-button(
      :class="{ favored: cloneFavored }"
      @click.native="onClickFavoriteProject"
    )
      heart-icon(
        size="22"
      )
  ShareSheet(
    :active="drawer"
    :sharing="sharing"
    @close="drawer = false"
  )

</template>

<script>
import { Swiper, SwiperSlide, directive } from 'vue-awesome-swiper'
import { MapPinIcon, MailIcon, MapIcon, HeartIcon, HomeIcon, MoreVerticalIcon, PhoneCallIcon, LogInIcon, CopyIcon, Share2Icon, AlertTriangleIcon } from 'vue-feather-icons'
import 'swiper/css/swiper.css'
import { generateUrl, parseImage } from '@/utilities/helpers'
import DropdownNetworkSharing from '~/lazy-components/DropdownNetworkSharing.vue'
import { cloneDeep } from 'lodash'

export default {
  name: 'DetailProject',

  components: {
    Swiper,
    MapIcon,
    MailIcon,
    HomeIcon,
    CopyIcon,
    HeartIcon,
    LogInIcon,
    Share2Icon,
    MapPinIcon,
    SwiperSlide,
    PhoneCallIcon,
    MoreVerticalIcon,
    AlertTriangleIcon,
    DropdownNetworkSharing
  },

  directives: {
    swiper: directive,
  },

  async asyncData ({ $api, error, route, params, env, $auth }) {
    let project = null
    let links = null
    let noMore = false
    let query = null
    let myLink = null
    try {
      const { data } = await $api.project.getProjectById(params.id)
      project = data
      if (!project) return error({
        statusCode: 404,
        message: 'pages.error.project_does_not_exist'
      })
      links = project.links.filter(link => link.user)
      query = {
        project: project._id,
        name: '',
        limit: 12,
        page: 1
      }
      if (links < query.limit) {
        noMore = true
      }
      if ($auth.loggedIn) {
        const res = await $api.link.checkLinkExisted(params.id)
        myLink = res.data
      }
    } catch (e) {
      const data = e.response?.data
      return error({
        statusCode: data?.statusCode,
        message: data?.message
      })
    }
    return {
      domain: env.domain,
      sharing: {
        url: generateUrl(`${route.path}`, env.domain),
        title: project.name,
        description: project.description,
        quote: 'Meta365 plans to introduce a real estate portal, where you can own and operate a portfolio of high-quality development properties in Metaverses.',
        hashtags: project.name.split(' ').join(''),
        // twitterUser: 'youyuxi'
        seo: project.seo || {}
      },
      links,
      query,
      myLink,
      project,
      noMore
    }
  },

  data () {
    return {
      activeTab: null,
      isVr: true,
      drawer: false,
      iframeLoading: false,
      swiperOptions: {
        grabCursor: true,
        loop: true,
        slidesPerView: 1,
        spaceBetween: 10,
        // freeMode: true,
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
          dynamicBullets: true,
        },
        autoplay: {
          delay: 4500,
          disableOnInteraction: false,
        },
        breakpoints: {
          1200: {
            slidesPerView: 1,
            spaceBetween: 10,
          },
          992: {
            slidesPerView: 1,
            spaceBetween: 10,
          },
          768: {
            slidesPerView: 2,
            spaceBetween: 10,
          },
          576: {
            slidesPerView: 1,
            spaceBetween: 10,
          },
          325: {
            slidesPerView: 1,
            spaceBetween: 10,
          },
        },
      },
      networks: [
        { network: 'facebook', name: 'Facebook', icon: 'facebook.svg', color: '#1877f2' },
        { network: 'messenger', name: 'Messenger', icon: 'messenger.svg', color: '#0084ff' },
        { network: 'telegram', name: 'Telegram', icon: 'telegram.svg', color: '#0088cc' },
        { network: 'twitter', name: 'Twitter', icon: 'twitter.svg', color: '#1da1f2' },
      ],
      scrollTop: true,
      pageYOffset: 9999,
      cloneFavored: false
    }
  },

  head () {
    const seo = this.sharing.seo
    const title = seo?.title || this.sharing.title
    const description = seo?.description || this.sharing.description
    return {
      title,
      description,
      meta: [
        {
          hid: 'og:title',
          property: 'og:title',
          content: title
        },
        {
          hid: 'og:description',
          property: 'og:description',
          content: description
        },
        {
          hid: 'keywords',
          property: 'keywords',
          content: seo?.keywords?.join(', ') || title
        },
        {
          property: 'og:image',
          content: parseImage(this.project?.images[0])
        },
        {
          property: 'og:image:alt',
          content: title
        },
        {
          hid: 'og:url',
          property: 'og:url',
          content: generateUrl(this.$route.path, this.domain)
        },
        {
          hid: 'og:type',
          property: 'og:type',
          content: 'website'
        },
        {
          hid: 'og:site_name',
          property: 'og:site_name',
          content: process.env.DOMAIN
        },
        {
          hid: 'og:image:type',
          property: 'og:image:type',
          content: 'image/png'
        },
        {
          hid: 'twitter:site',
          property: 'twitter:site',
          content: process.env.DOMAIN
        },
        {
          hid: 'twitter:title',
          name: 'twitter:title',
          content: title
        },
        {
          hid: 'twitter:description',
          name: 'twitter:description',
          content: description
        },
        {
          hid: 'twitter:creator',
          property: 'twitter:creator',
          content: process.env.DOMAIN
        },
        {
          hid: 'twitter:image:src',
          property: 'twitter:image:src',
          content: parseImage(this.project?.images[0])
        },
        {
          hid: 'twitter:domain',
          property: 'twitter:domain',
          content: generateUrl('', this.domain)
        },
        {
          hid: 'twitter:image',
          name: 'twitter:image',
          content: parseImage(this.project?.images[0])
        },
        {
          hid: 'og:type',
          name: 'og:type',
          content: 'article'
        },
        {
          hid: 'twitter:url',
          name: 'twitter:url',
          content: generateUrl(this.$route.path, this.domain)
        },
        {
          hid: 'og:publish_date',
          name: 'og:publish_date',
          content: this.project.createdAt
        },
        {
          hid: 'og:author',
          name: 'og:author',
          content: 'Meta365'
        }
      ]
    }
  },

  computed: {
    isInvestor () {
      return !this.$route.name === 'project'
    },

    user () {
      return this.$auth.user
    },

    disabled () {
      return this.loading || this.noMore
    },

    favored () {
      return !!this.user?.favorites?.map(favored => favored.id).includes(this.project._id)
    }
  },

  watch: {
    activeTab (value, oldValue) {
      if(value === oldValue || value === this.$route.query.tab) return
      const query = {
        ...this.$route.query,
        tab: value
      }
      this.$router.replace({ query })
    },

    pageYOffset (newVal, oldVal) {
      if (newVal <= 60) this.scrollTop = true
      else this.scrollTop = !(newVal > oldVal)
    },

    scrollTop (newVal) {
      this.menuHeight = newVal ? 130 : 100
    }
  },

  created () {
    this.activeTab = this.$route.query.tab || 'info'
    // this.project.images = this.project?.images.map(item => {
    //   return parseImage(item)
    // })
    this.cloneFavored = cloneDeep(this.favored)
  },

  mounted () {
    this.pageYOffset = document.documentElement.scrollTop
    this.$nextTick(() => {
      window.addEventListener('scroll', this.scroll)
    })
  },

  beforeDestroy () {
    window.removeEventListener('scroll', this.scroll)
  },

  methods: {
    generateUrl,

    generateMyLink () {
      if (!this.$auth.loggedIn) {
        return this.$router.replace({
          query: {
            ...this.$route.query,
            'request-login': true
          }
        })
      }
      this.$flows.confirmTerms({
        parent: this,
        terms: ''
      })
        .then((data) => {
          this.refresh()
        })
    },

    changeIframe () {
      this.isVr = !this.isVr
      this.iframeLoading = true
    },

    iframeLoaded (e) {
      if (!e) return
      this.iframeLoading = false
    },

    clipboardSuccess () {
      this.$message({
        type: 'success',
        message: this.$t('common.copied')
      })
    },

    refresh (payload) {
      this.myLink = payload
      this.query.page = 1
      this.loadAgency(true)
    },

    handleSearch (key) {
      this.query.name = key
      this.query.page = 1
      this.loadAgency(true)
    },

    loadAgency (force = false) {
      this.loading = true
      const query = cloneDeep(this.query)
      if (!this.query.name) {
        delete query.name
      }
      return this.$api.link.all(query)
        .then(({ data }) => {
          const results = data?.results
          if (results.length < this.query.limit) {
            this.noMore = true
          }
          if (force) {
            this.links = results.filter(link => link.user)
          } else {
            this.links.push(...results)
          }
        })
        .finally(() => {
          this.loading = false
        })
    },

    onClickOpenSharePopup () {
      this.drawer = true
    },

    onInfiniteScroll ($state) {
      if ((this.disabled && !this.links.length)) {
        $state.complete()
        return
      } else if (this.noMore) {
        $state.loaded()
        $state.complete()
      }
      this.query.page++
      this.loadAgency()
        .then(() => {
          if (this.noMore) {
            $state.loaded()
            $state.complete()
          } else {
            $state.loaded()
          }
        })
    },

    scroll () {
      this.pageYOffset = document.documentElement.scrollTop
    },

    onClickOpenContactUsModal () {
      this.$flows.contactUs({
        parent: this,
        project: this.project
      })
    },

    onClickFavoriteProject () {
      if (!this.$auth.loggedIn) {
        return this.$router.replace({
          query: {
            ...this.$route.query,
            'request-login': true
          }
        })
      }
      let api = null
      const data = {
        id: this.project._id,
        favoriteType: 'project'
      }
      if (this.cloneFavored) {
        api = this.$api.user.removeFavorite(data)
      } else {
        if (this.user.favorites.length >= 10) {
          return this.$notify.error({
            message: this.$t('notification.you_have_favored_the_maximum')
          })
        }
        api = this.$api.user.addFavorite(data)
      }
      return api.then(async(res) => {
        this.cloneFavored = !this.cloneFavored
        await this.$auth.setUser(res.data.user)
      })
        .catch(() => {})
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/assets/styles/project-id.scss';
::v-deep.bottom-action {
  width: 100%;
  height: 64px;
  padding: 10px;
  box-sizing: border-box;
  position: sticky;
  bottom: -1px;
  z-index: 1001;
  display: flex;
  justify-content: space-between;
  background: var(--color-shade-1);
  box-shadow: 0px 0px 8px 2px rgb(0 0 0 / 20%);
  .el-button {
    padding: 10px 14px;
    height: 44px;
    > span {
      justify-content: center;
      font-size: $--size-base-md;
      font-weight: 600;
    }
  }
}
</style>
