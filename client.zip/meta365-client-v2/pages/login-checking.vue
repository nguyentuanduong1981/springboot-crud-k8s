<template lang="pug">
div
  svg#triangle(
    width="100px"
    height="100px"
    viewBox="-3 -4 39 39"
  )
    polygon(
      stroke-width="1"
      points="16,0 32,32 0,32"
    )
</template>

<script>
import { isEmpty } from 'element-ui/lib/utils/util'
import { DEFAULT_ROUTE } from '~/utilities/constants'

export default {
  name: 'LoginCheckingPage',

  asyncData ({ $auth, redirect, query }) {
    if ($auth.loggedIn || isEmpty(query)) {
      redirect({ name: 'index' })
    }
  },

  data () {
    return {
      loading: false
    }
  },

  created () {
  },

  mounted () {
    const query = this.$route.query
    if (query.state && query.code) {
      const state = JSON.parse(JSON.stringify(this.$auth.$state))
      if (state.strategy === 'local') {
        return this.$router.replace({ name: 'index' })
      }
      this.loading = true
      this.$api.authentication.loginSocial(state.strategy, query)
        .then(async (response) => {
          return await this.$auth.setUserToken(response.data.access_token)
        })
        .then(async () => {
          await this.$auth.fetchUser()
        })
        .catch((error) => {
          const data = error?.response?.data
          this.$notify.error({
            // title: this.$t('modal.authentication.login_with_social_network'),
            message: this.$t(data.message || data.error || data.error_description)
          })
        })
        .finally(() => {
          if (this.$route.name !== DEFAULT_ROUTE) {
            this.$router.push({ name: 'index' })
          }
          this.loading = true
        })
    }
  }
}
</script>

<style lang="scss" scoped>
div {
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  height: calc(100vh - $--header-height);
  background-color: var(--color-shade-1);
  @include media(sm-down) {
    height: calc(100vh - $--header-height-mobile);
  }
}
svg {
  transform-origin: 50% 65%;
}

svg polygon {
  stroke-dasharray: 17;
  animation: dash 2.5s cubic-bezier(0.35, 0.04, 0.63, 0.95) infinite;
  fill: var(--color-shade-2);
  stroke: var(--color-shade-4);
}

@keyframes dash {
  to {
    stroke-dashoffset: 136;
  }
}

@keyframes rotate {
  100% {
    transform: rotate(360deg);
  }
}

</style>
