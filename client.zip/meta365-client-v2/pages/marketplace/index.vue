<template lang="pug">
.marketplace-page.main-page
  el-container
    el-aside.form-filter.hidden-xs-only(width='324px')
      CommonMarketPlaceFilter(
        :query="query"
        @search="updateQuery"
        @reset="handleReset"
      )

    el-main
      .filters.hidden-sm-and-up.d-flex
        el-input.fw.el-input--bottom.mr-10(
          v-model="query.name"
          :placeholder="$t('pages.marketplace.land_name')"
          @keydown.enter.native="handleSearch"
        )
          i.el-input__icon.el-icon-search(slot="prefix")
        el-button.filters-el-draws.filters__button(
          @click.native="filterBar = !filterBar"
        )
          i.el-icon-s-operation
        //- button#grid-list-button.el-button.filters__button.grid-list-button
        //-   span.icon
        //-     span.dots
        //-       i
        //-       i
        //-       i
        //-       i
        //-     span.lines
        //-       i
        //-       i
        //-       i
        //-       i

      el-drawer(
        :visible.sync="filterBar"
        :with-header="false"
        size="300px"
      )
        CommonMarketPlaceFilter(
          :query="query"
          @search="updateQuery"
          @reset="handleReset"
        )

      el-row.results(
        :gutter="20"
      )
        el-col(
          :xs="12"
          :sm="24"
          :md="12"
          :lg="8"
          v-for="item in land"
          :key="item._id"
        )
          ProjectItem.my-10(
            :project="item"
          )

        client-only
          infinite-loading(
            direction="bottom"
            force-use-infinite-wrapper
            :distance="20"
            :identifier="infiniteId"
            @infinite="onInfiniteScroll"
          )
            span(slot="no-more") {{ $t('common.no_more') }}
            span(slot="no-results")
              el-empty()
                template(#description)
                  span {{ $t('pages.marketplace.empty') }}
</template>

<script>
import { scrollTo } from '~/utilities/helpers'
import { debounce, pickBy, identity } from 'lodash'

const DEFAULT = {
  name: '',
  project: '',
  price: [1, 1000000],
  sort: '',
  status: ''
}

export default {
  name: 'MarketplacePage',

  components: {
  },

  asyncData ({ error, query }) {
    let land = null
    try {
      land = []
    } catch (e) {
      return error(e)
    }
    return {
      propsQuery: query,
      land,
    }
  },

  data () {
    return {
      filterBar: false,
      noMore: false,
      query: DEFAULT,
      pagination: {
        limit: 12,
        page: 1
      },
      infiniteId: 0,
      loading: false
    }
  },

  head () {
    return {
      title: 'Marketplace'
    }
  },

  computed: {
    disabled () {
      return this.loading || this.noMore
    },

    filter () {
      return pickBy({
        ...this.query,
        ...this.pagination
      }, identity)
    }
  },

  watch: {
    'query.name': debounce(function () {
      this.handleSearch()
    }, 200)
  },

  created () {
    this.query = {
      ...this.query,
      ...this.$route.query
    }
  },

  mounted () {
    const gridListButton = document.getElementById('grid-list-button')
    if (!gridListButton) return
    const gridListToggle = (event) => {
      let button = event.target
      if (button.tagName !== 'BUTTON') {
        button = button.closest('button')
      }
      if (!button.classList.contains('grid-list-button')) return
      button.classList.add('animation')
      button.classList.toggle('list')
      const clone = button.cloneNode(true)
      button.parentNode.replaceChild(clone, button)
      clone.addEventListener('click', gridListToggle)
    }
    gridListButton.addEventListener('click', gridListToggle)
  },

  methods: {
    updateQuery (query) {
      this.query = query
      this.handleSearch()
    },

    handleSearch () {
      this.noMore = false
      this.pagination.page = 1
      this.search(true)
        .then(() => {
          scrollTo(0, () => {
            setTimeout(() => {
              this.infiniteId ++
            }, 100)
          })
        })
    },

    handleReset () {
      this.query = DEFAULT
      this.handleSearch(true)
    },

    search (force = false) {
      this.loading = true
      if (force) {
        this.pagination.page = 1
      }
      this.$router.replace({ query: this.query }).catch(() =>({}))
      return this.$api.project.all(this.filter)
        .then(({ data }) => {
          const results = data?.results
          if (results.length < this.pagination.limit) {
            this.noMore = true
          }
          if (force) {
            this.land = results
          } else {
            this.land.push(...results)
          }
        })
        .finally(() => {
          this.loading = false
        })
    },

    onInfiniteScroll ($state) {
      if (this.land && !this.land.length) {
        $state.complete()
        return
      } else if (this.noMore) {
        $state.loaded()
        $state.complete()
        return
      }
      this.pagination.page++
      this.search()
        .then(() => {
          if (this.noMore) {
            $state.loaded()
            $state.complete()
          } else {
            $state.loaded()
          }
        })
    }
  }
}
</script>

<style lang="scss" scoped>
::v-deep.marketplace-page {
  padding: 0;
  background-color: var(--color-shade-0);
  .space {
    width: 16px;
  }
  p {
    color: var(--color-shade-1);
  }
  .el-container {
    .el-aside {
      position: sticky;
      top: $--header-height;
      align-self: flex-start;
      background: var(--color-bg-header);
      height: calc(100vh - $--header-height);
      box-shadow: 0px 5px 5px 0px var(--color-shade-3);
      @include media(sm-down) {
        top: $--header-height-mobile;
        height: calc(100vh - $--header-height-mobile);
      }
    }
    .el-main {
      overflow: hidden;
      .filters {
        .el-input {
          &__prefix {
            left: 0;
          }
          &__inner {
            padding-left: 36px;
          }
          &__icon {
            width: 36px;
          }
        }
        &__button {
          padding: 8px;
          border: 0;
          border-radius: $--radius-medium;
          background-color: var(--color-shade-1);
          outline: none;
          cursor: pointer;
          transition: 0.3s ease-in-out;
          &:hover {
            background-color: var();
          }
          &:active {
            transform: scale(0.9);
          }
          .el-icon-s-operation {
          }
          .icon {
            position: relative;
            display: block;
            width: 24px;
            height: 24px;
          }
        }
        .filters-el-draws {
          padding: 4px;
          color: var(--color-shade-1);
          .el-icon-s-operation {
            font-size: 30px;
            color: var(--color-shade-6);
          }
        }
        .grid-list-button {
          .dots {
            i {
              position: absolute;
              width: 10px;
              height: 10px;
              border-radius: 2px;
              background-color: $--color-white;
              animation-duration: 0.4s;
              animation-fill-mode: forwards;
              animation-direction: reverse;
              &:nth-child(1) {
                left: 0;
                top: 0;
              }
              &:nth-child(2) {
                left: 14px;
                top: 0;
              }
              &:nth-child(3) {
                left: 0;
                top: 14px;
              }
              &:nth-child(4) {
                left: 14px;
                top: 14px;
              }
            }
          }
          .lines {
            i {
              position: absolute;
              right: 0;
              width: 16px;
              height: 2.2px;
              border-radius: 2px;
              background-color: var(--color-shade-1);
              animation-duration: 0.4s;
              animation-fill-mode: forwards;
              animation-direction: reverse;
              transform-origin: 100% 0;
              transform: scaleX(0);
              &:nth-child(1) {
                top: 1px;
              }
              &:nth-child(2) {
                top: 8px;
              }
              &:nth-child(3) {
                top: 15px;
              }
              &:nth-child(4) {
                top: 22px;
              }
            }
          }
          &.list {
            .dots {
              i {
                animation-direction: normal;
              }
            }
            .lines {
              i {
                animation-direction: normal;
              }
            }
          }
          &.animation {
            @keyframes dotScale {
              0% {
                width: 10px;
                height: 10px;
              }
              100% {
                width: 5px;
                height: 5px;
              }
            }
            @keyframes dotMove {
              0% {
                transform: translate(0, 0);
              }
              50% {
                transform: translate(0, 7px);
              }
              100% {
                transform: translate(-14px, 7px);
              }
            }
            @keyframes lineScale1 {
              0%,
              20% {
                transform: scaleX(0);
              }
              100% {
                transform: scaleX(1);
              }
            }
            @keyframes lineScale2 {
              0%,
              50% {
                transform: scaleX(0);
              }
              100% {
                transform: scaleX(1);
              }
            }
            .dots {
              i {
                &:nth-child(1),
                &:nth-child(3) {
                  animation-name: dotScale;
                }
                &:nth-child(2),
                &:nth-child(4) {
                  animation-name: dotScale, dotMove;
                }
              }
            }
            .lines {
              i {
                &:nth-child(1),
                &:nth-child(3) {
                  animation-name: lineScale1;
                }
                &:nth-child(2),
                &:nth-child(4) {
                  animation-name: lineScale2;
                }
              }
            }
          }
        }
      }
      .results {
        min-height: 100%;
        @include media(mobile) {
          margin-top: 20px;
          .el-col {
            width: 100%;
          }
        }
        .project-item {
          &__top {
            position: relative;
            display: flex;
            .overlay {
              opacity: 0.3;
              will-change: opacity;
              transition: opacity 0.3s ease-in-out;
              position: absolute;
              top: 0;
              left: 0;
              background-color: #242429;
              height: 100%;
              width: 100%;
            }
            &:hover {
              .overlay {
                opacity: 0.7;
              }
            }
            .image {
              height: 200px;
              object-fit: cover;
            }
          }
          &__body {
            position: relative;
            &__info {
              position: absolute;
              padding: 0 10px;
              top: -80px;
              align-items: flex-start;
              .avatar {
                flex-shrink: 0;
              }
              .info {
                color: $--color-white;
                margin-left: 10px;
                .name {
                  text-transform: uppercase;
                  font-size: $--size-base;
                  font-weight: 600;
                  @include text-ellipsis(2);
                }
                .location {
                  font-weight: 400;
                  font-size: $--size-base-xs;
                }
              }
            }
          }
        }
        .infinite-status-prompt {
          color: var(--color-shade-6);
          font-size: 13px;
        }
      }
    }
    .el-drawer {
      background: var(--color-shade-1);
      overflow: hidden;
    }
    .el-aside {
      @include media(sm-only) {
        .px-16 {
          min-height: calc(100vh - $--header-height-mobile - 60px - 66px)!important;
        }
      }
    }
  }
}
</style>
