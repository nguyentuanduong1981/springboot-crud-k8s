<template lang="pug">
.terms-of-service-page
  .container(
    v-html="$t('pages.terms.content')"
  )
  //- h2.container {{ $t('footer.terms_of_services') }}
  //- el-container.container
  //-   el-main
  //-     section.section#acceptance-of-terms
  //-       li(
  //-         data-li="1"
  //-       ).title {{ $t('pages.terms.1.title') }}
  //-       ul
  //-         li.sub(
  //-           v-if="$te('pages.terms.1.1')"
  //-           data-li="1"
  //-         ) {{ $t('pages.terms.1.1') }}
  //-         li.sub(
  //-           v-if="$te('pages.terms.1.2')"
  //-           data-li="1"
  //-         ) {{ $t('pages.terms.1.2') }}
  //-         li.sub(
  //-           v-if="$te('pages.terms.1.3')"
  //-           data-li="1"
  //-         ) {{ $t('pages.terms.1.3') }}
  //-         li.sub(
  //-           v-if="$te('pages.terms.1.4')"
  //-           data-li="1"
  //-         ) {{ $t('pages.terms.1.4') }}
  //-         li.sub(
  //-           v-if="$te('pages.terms.1.5')"
  //-           data-li="1"
  //-         ) {{ $t('pages.terms.1.5') }}

  //-     section.section#use-of-the-website
  //-       li(
  //-         data-li="2"
  //-       ).title {{ $t('pages.terms.2.title') }}
  //-       ul
  //-         li.sub(
  //-           v-if="$te('pages.terms.2.1')"
  //-           data-li="2"
  //-         ) {{ $t('pages.terms.2.1') }}
  //-         li.sub(
  //-           v-if="$te('pages.terms.2.2')"
  //-           data-li="2"
  //-         ) {{ $t('pages.terms.2.2') }}
  //-         li.sub(
  //-           v-if="$te('pages.terms.2.3')"
  //-           data-li="2"
  //-         ) {{ $t('pages.terms.2.3') }}
  //-         li.sub(
  //-           v-if="$te('pages.terms.2.4')"
  //-           data-li="2"
  //-         ) {{ $t('pages.terms.2.4') }}
  //-         li.sub(
  //-           v-if="$te('pages.terms.2.5')"
  //-           data-li="2"
  //-         ) {{ $t('pages.terms.2.5') }}
  //-         li.sub(
  //-           v-if="$te('pages.terms.2.6')"
  //-           data-li="2"
  //-         ) {{ $t('pages.terms.2.6') }}

  //-   el-aside.px-10(
  //-     width="250px"
  //-   )
  //-     ol
  //-       li
  //-         a(href='#acceptance-of-terms') {{ $t('pages.terms.1.title') }}
  //-       li
  //-         a(href='#use-of-the-website') {{ $t('pages.terms.2.title') }}
  //-       li
  //-         a(href='#authentication') Authentication
  //-       li
  //-         a(href='#endpoints') Endpoints
  //-         ul
  //-           li
  //-             a(href='#endpoints--root') Root
  //-           li
  //-             a(href='#endpoints--cities-overview') Cities Overview
  //-           li
  //-             a(href='#endpoints--city-detail') City Detail
  //-           li
  //-             a(href='#endpoints--city-config') City Config
  //-           li
  //-             a(href='#endpoints--city-spots-overview') City Spots Overview
  //-           li
  //-             a(href='#endpoints--city-spot-detail') City Spot Detail
  //-           li
  //-             a(href='#endpoints--city-icons-overview') City Icons Overview
  //-           li
  //-             a(href='#endpoints--city-icon-detail') City Icon Detail
  //-       li
  //-         a(href='#links') Links
  //-       li
  //-         a(href='#expanders') Expanders
  //-       li
  //-         a(href='#filters') Filters
  Footer
</template>

<script>
export default {
  name: 'TermsOfServicePage',

  data() {
    return {
      observer: null,
    }
  },

  mounted () {
    this.observer = new IntersectionObserver(this.onElementObserved, {
      root: this.$el,
      threshold: 0.22,
    })
    // Track all sections that have an `id` applied
    document.querySelectorAll('section[id]').forEach((section) => {
      this.observer.observe(section)
    })
  },

  beforeDestroy() {
    this.observer.disconnect()
  },

  methods: {
    onElementObserved(entries) {
      entries.forEach(({ target, isIntersecting, intersectionRatio }) => {
        const id = target.getAttribute('id')
        if (intersectionRatio > 0) {
          this.$el
            .querySelector(`aside li a[href="#${id}"]`)
            .parentElement.classList.add('active')
        } else {
          this.$el
            .querySelector(`aside li a[href="#${id}"]`)
            .parentElement.classList.remove('active')
        }
      })
    },
  }
}
</script>

<style lang="scss" scoped>
h2 {
  font-size: 24px;
}
.el-main {
  padding: 20px 0;
}

li {
  line-height: 20px;
  margin-bottom: 10px;
  text-align: justify;
  &.title {
    padding-left: 0;
    font-size: 20px;
    list-style-type: none;
    &::before {
      content: attr(data-li)".""\a0\a0";
    }
  }
  &.sub {
    list-style: none;
    &::before {
      content: attr(data-li)"."counter(list-item)"\a0\a0";
    }
  }
}
</style>

<style lang="scss" scoped>
// ::v-deep.terms-of-service-page {
//   background: var(--color-shade-1);
//   .container {
//     padding-top: 16px;
//     p {
//       margin-top: 0;
//     }
//   }
// }
</style>
