<template lang="pug">
.privacy-statement-page
  .container(
    v-html="$t('pages.privacy.content')"
  )
  Footer
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
.privacy-statement-page {
  background: var(--color-shade-1);
  .container {
    padding-top: 16px;
    p {
      &:first-child {
        margin-top: 0;
      }
    }
  }
}
@import '@/assets/styles/component/stupid';
</style>
