<template lang="pug">
.setting-page.main-page
  el-container
    el-aside(
      v-if="isOwner"
      width="300px"
    )
      h2.setting-page__title {{ $t('pages.agent.manage_page') }}
      el-divider.underline-title
      ul.setting-page__nav
        component.flex-center-y.setting-page__nav__item(
          v-for="i in sideBarItems"
          :key="i.name"
          :is="i.divider ? 'el-divider' : 'li'"
          :class="{ 'is-active': i.name === activeTab }"
          @click="onClickChangeActiveTab(i.name)"
        )
          component.mr-4(
            :is="i.icon"
            size="24"
          )
          span {{ $t(i.label) }}
    el-main.p-0(
    )
      //- .overlay
      .layout
        #app-landing(
          :class="{ toggle }"
        )
          #app-landing-bg.container(
            :class="{ cropper: isChangeCover }"
          )
            .cover(
              :style="{ background: `url(${coverParse})`, backgroundSize: 'cover' }"
              @click="onClickPreviewImage(0)"
            )
            template(v-if="isOwner")
              CoverUploader(
                v-if="isChangeCover"
                ref="coverCropper"
                :loading="loadingCropper"
                :src="this.cover.src || coverParse"
                :canvas="{ minHeight: 372, minWidth: 768 , maxHeight: 372, maxWidth: 2048 }"
                :minWidth="375"
                :minHeight="372"
                @loaded="loadingCropper = false"
                @cropped="onUploadCover($event)"
                image-restriction="stencil"
                :stencil-size="{ width: 1200, height: 500 }"
              )

              label.change-cover(
                v-if="!isChangeCover"
              )
                InputFile(
                  :maximum="5"
                  @ready="loadImage($event)"
                  :accept="'image/jpg,image/jpeg,image/png'"
                )
                CameraIcon(
                  size="18"
                )
                span.ml-4 {{ $t('pages.profile.change_cover') }}

              .crop-cover(
                v-else
                :class="{ loading }"
              )
                label.re-upload.mr-4(
                  v-loading="loading"
                  element-loading-spinner="el-icon-loading"
                )
                  InputFile(
                    :maximum="5"
                    @ready="loadImage($event)"
                    :accept="'image/jpg,image/jpeg,image/png'"
                  )
                  CameraIcon(
                    size="18"
                  )
                  span.ml-4 {{ $t('common.choose_another_image') }}
                .cancel.mr-4(
                  v-loading="loading"
                  element-loading-spinner="el-icon-loading"
                  @click.stop="resetCropper()"
                )
                  XSquareIcon(
                    size="18"
                  )
                  span.ml-4 {{ $t('pages.profile.cancel_upload_cover') }}
                .save(
                  v-loading="loading"
                  element-loading-spinner="el-icon-loading"
                  @click.stop="onClickCropCover()"
                )
                  CheckSquareIcon(
                    size="18"
                  )
                  span.ml-4 {{ $t('pages.profile.save_cover') }}
      #app-content
        .container
          #app-profile-header.profile-header
            .profile-avatar(
              v-show="!isChangeCover"
            )
              nuxt-img.avatar(
                format="webp"
                :src="avatar"
                @click.native="onClickPreviewImage(1)"
              )
              template(
                v-if="isOwner"
              )
                .upload
                .background-tool
                  .top(
                    @click="onClickPreviewImage(1)"
                  )
                  .bottom.flex-center(
                    @click="onClickUploadAvatar()"
                  )
                    CameraIcon(
                      size="18"
                    )
            .flex-between.info
              div.username-and-contact
                p.username.type-title.c-text-ellipsis-0
                  el-tooltip-theme(
                    :content="agent.name"
                    placement="bottom"
                  )
                    span {{ agent.name }}
                p.short-name.m-0 @{{ agent.shortName }}
                //- el-tooltip(
                //-   :content="$t('pages.profile.message')"
                //-   placement="top-start"
                //-   :effect="$colorMode.value === 'dark' ? 'dark' : 'light'"
                //- )
              .profile-actions
                button.el-button--primary.flex-center-y.follow.active(
                  size="small"
                  type="primary"
                  @click="onClickFollow()"
                  :class="`following-${following}`"
                )
                  component(
                    :is="following ? 'UserCheckIcon' : 'RssIcon'"
                    size="24"
                  )
                  .hidden-sm-and-down.ml-4 {{ following ? $t('pages.profile.following') : $t('pages.profile.follow') }}
                button.flex-center-y.message(
                  size="small"
                  type="primary"
                  @click="onClickMessage()"
                )
                  MessageCircleIcon(
                    size="24"
                  )
                  .hidden-sm-and-down.ml-4 {{ $t('pages.agent.message') }}
                DropdownNetworkSharing(
                  :sharing="sharing"
                )
                  button.flex-center-y(
                    slot="reference"
                  )
                    Share2Icon(
                      size="24"
                    )
                  //- .hidden-sm-and-down {{ $t('pages.profile.share') }}
                //- el-dropdown(
                //-   trigger="click"
                //- )
                //-   //- :hide-on-click="false"
                //-   span.el-dropdown-link
                //-     button.more-btn
                //-       MoreVerticalIcon(size="24")
                //-   el-dropdown-menu(
                //-     slot="dropdown"
                //-   )
                //-     el-dropdown-item.flex-center-y.hidden-sm-and-up(@click.stop.native="onClickOpenSharePopup()")
                //-       Share2Icon.mr-4(size="20")
                //-       | {{ $t('pages.profile.share') }}
                //-     el-dropdown-item.flex-center-y(
                //-       v-clipboard:copy="sharing.url"
                //-       v-clipboard:success="clipboardSuccess"
                //-     )
                //-       CopyIcon.mr-4(size="20")
                //-       | {{ $t('pages.profile.copy_link') }}
                //-     template(v-if="!isOwner")
                //-       el-dropdown-item.flex-center-y
                //-         AlertTriangleIcon.mr-4(size="20")
                //-         | {{ $t('pages.profile.report') }}
                //-       el-dropdown-item.flex-center-y
                //-         UserXIcon.mr-4(size="20")
                //-         | {{ $t('pages.profile.block') }}

      .content
        .container.mt-10
          template(
            v-if="activeTab === 'members'"
          )
            .px-16
              h2 {{ $t('pages.agent.member_list') }}
              Table(
                :isOwner="isOwner"
                :isResponsiveWeb="isResponsiveWeb"
                :data="members"
              )
              Pagination(
                :isResponsiveWeb="isResponsiveWeb"
                :total="100"
              )
</template>

<script>
import {
  RssIcon,
  EyeIcon,
  HomeIcon,
  EditIcon,
  CopyIcon,
  BellIcon,
  CheckIcon,
  UsersIcon,
  LayersIcon,
  Share2Icon,
  CameraIcon,
  XSquareIcon,
  CalendarIcon,
  SettingsIcon,
  PhoneCallIcon,
  CreditCardIcon,
  TrendingUpIcon,
  CheckSquareIcon,
  MoreVerticalIcon,
  MessageCircleIcon,
} from 'vue-feather-icons'
import DropdownNetworkSharing from '~/lazy-components/DropdownNetworkSharing.vue'
import CoverUploader from '@/lazy-components/CoverUploader.vue'
import { generateUrl, parseImage } from '@/utilities/helpers'
import ResponsiveWebMixin from '~/mixins/responsive-web'
import { USER_TYPE } from '@/utilities/constants'
import steps from '@/guides/statistic-and-analytics'

export default {
  name: 'SettingsPage',

  components: {
    RssIcon,
    EyeIcon,
    BellIcon,
    HomeIcon,
    EditIcon,
    CopyIcon,
    UsersIcon,
    CheckIcon,
    CameraIcon,
    LayersIcon,
    Share2Icon,
    XSquareIcon,
    CalendarIcon,
    SettingsIcon,
    PhoneCallIcon,
    CreditCardIcon,
    TrendingUpIcon,
    CheckSquareIcon,
    MoreVerticalIcon,
    MessageCircleIcon,
    CoverUploader,
    DropdownNetworkSharing,
  },

  mixins: [ResponsiveWebMixin],

  auth: false,

  async asyncData ({ env, $api, params, error, $auth, route }) {
    let agent = null
    let isOwner = false
    const members = []
    const id = encodeURIComponent(params.id)

    try {
      const response = await $api.agent.getAgentById(id)
      agent = response.data
      if (!agent) return error({
        statusCode: 404,
        message: 'pages.error.agent_does_not_exist'
      })
      members.push(...agent.members.map(({ role, info }) => {
        return {
          role,
          ...info
        }
      }))
      if (agent.status === 'pending') {
        if (!$auth.loggedIn || !members.filter(member => member._id === $auth.user._id).length) {
          return error({
            statusCode: 404,
            message: 'pages.error.agent_does_not_exist'
          })
        }
      }
      if ($auth.loggedIn) {
        isOwner = agent.owner._id === $auth.user._id
      }
    } catch (e) {
      const data = e.response?.data
      return error({
        statusCode: data?.statusCode,
        message: data?.message
      })
    }
    return {
      domain: env.domain,
      sharing: {
        url: generateUrl(`${route.path}`, env.domain),
        title: '',
        description: '',
        quote: 'Meta365 plans to introduce a real estate portal, where you can own and operate a portfolio of high-quality development properties in Metaverses.',
        hashtags: 'meta365,vr,ar',
        // twitterUser: 'youyuxi'
      },
      members,
      agent,
      isOwner
    }
  },

  data () {
    return {
      USER_TYPE,
      activeTab: '',
      following: false,
      toggle: true,
      sideBarItems: [
        {
          name: 'home',
          label: 'pages.agent.home',
          icon: 'HomeIcon',
          divider: false
        },
        {
          name: 'members',
          label: 'pages.agent.members',
          icon: 'UsersIcon',
          divider: false
        },
        {
          name: 'messenger',
          label: 'pages.agent.messenger',
          icon: 'MessageCircleIcon',
          divider: false
        },
        {
          name: 'notifications',
          label: 'pages.agent.notifications',
          icon: 'BellIcon',
          divider: false
        },
        {
          name: 'events',
          label: 'pages.agent.events',
          icon: 'CalendarIcon',
          divider: false
        },
        {
          divider: true
        },
        {
          name: 'statistic_and_analysis',
          label: 'pages.agent.statistics_and_analysis',
          icon: 'TrendingUpIcon',
          divider: false
        },
        {
          divider: true
        },
        {
          name: 'edit_page_info',
          label: 'pages.agent.edit_page_info',
          icon: 'EditIcon',
          divider: false
        },
        {
          name: 'settings',
          label: 'pages.agent.settings',
          icon: 'SettingsIcon',
          divider: false
        },
      ],
      termForm: {
        isAccept: false
      },
      driver: null,
      isChangeCover: false,
      loading: false,
      loadingCropper: false,
      cover: ''
    }
  },

  computed: {
    user () {
      return this.$auth.user
    },

    avatar () {
      const logo = this.agent.logo
      if (!logo) return generateUrl('/winking.png', this.domain)
      return parseImage(logo)
    },

    coverParse () {
      const cover = this.agent.cover
      if (!cover) return generateUrl('/banner.png', this.domain)
      return parseImage(cover)
    }
  },

  watch: {

    activeTab (value, oldValue) {
      if(value === oldValue || value === this.$route.query.tab) return
      this.toggle = !!['home'].includes(value)
      const query = {
        ...this.$route.query,
        tab: value
      }
      this.$router.replace({ query })
    }
  },

  created () {
    this.activeTab = this.$route.query.tab || 'home'
    this.toggle = !!['home'].includes(this.activeTab)
  },

  mounted () {
    this.driver = this.$guide
  },

  methods: {
    generateUrl,
    onClickChangeActiveTab (active) {
      if (!active) return
      this.activeTab = active
    },

    onClickChangeCover () {
      this.isChangeCover = true
      this.loadingCropper = true
    },

    loadImage(payload) {
      this.cover = payload
      this.onClickChangeCover()
    },

    onClickCropCover () {
      this.$refs.coverCropper.onCrop()
    },

    onUploadCover (payload) {
      return
      const form = new FormData()
      form.append('file', payload)
      this.loading = true
      this.$api.user.updateCover(form)
        .then(async (res) => {
          this.resetCropper()
          await this.fetchProfile(res.data.user)
        })
        .catch((error) => {
          this.$notify.error({
            title: this.title,
            message: error.response.data.message || this.$t('notification.error.upload_cover_failed'),
          })
        })
        .finally(() => {
          this.loading = false
        })
    },

    clipboardSuccess () {
      this.$message({
        type: 'success',
        message: this.$t('common.copied')
      })
    },

    resetCropper () {
      this.isChangeCover = false
      this.cover = {
        src: null,
        type: 'image/png'
      }
    },

    onClickPreviewImage (index) {
      const medias = [
        {
          url: this.coverParse,
          type: 'image'
        },
        {
          url: this.avatar,
          type: 'image'
        }
      ]
      if (!medias[index] || !medias[index].url) return
      this.$preview({
        parent: this,
        index,
        medias
      })
    },

    onClickUploadAvatar () {
      if(!this.isOwner) return
      this.$flows.avatarUploader({
        parent: this,
        src: this.avatar
      })
        .then(async (res) => {
        })
    },

    onClickMessage () {
      return this.$message({
        type: 'info',
        message: this.$t('common.feature_under_development')
      })
    },

    guide () {
      this.driver.defineSteps(steps)
      this.$nextTick(() => {
        setTimeout(() => {
          this.driver.start()
        }, 100)
      })
    },

    onClickFollow () {
      if (!this.$auth.loggedIn) {
        return this.$router.replace({
          query: {
            ...this.$route.query,
            'request-login': true
          }
        })
      }
      return this.$message({
        type: 'info',
        message: this.$t('common.feature_under_development')
      })
      // this.following = !this.following
    },
  }
}
</script>

<style lang="scss" scoped>
@import '~/assets/styles/component/cover';
$color-custom-brand: #7597C7;
::v-deep.setting-page {
  padding: 0;
  background-color: var(--color-shade-0);
  .space {
    width: 16px;
  }
  .el-container {
    .el-tabs {
      &__item {
        color: var(--color-shade-1);
        &.is-active {
          color: var(--color-primary);
        }
      }
      &__nav-wrap {
        padding: 0 14px;
        &::after {
          background-color: transparent;
        }
      }
      .form-label {
        font-size: $--size-base;
      }
    }
    .el-aside {
      position: sticky;
      z-index: 1;
      top: $--header-height;
      align-self: flex-start;
      background: var(--color-bg-header);
      height: calc(100vh - $--header-height);
      box-shadow: 2px 0px 5px 0px rgba(0, 0, 0, 0.25);
      padding: 6px 10px;
      transition: width 0.2s ease-in-out;
      @include media(sm-down) {
        top: $--header-height-mobile;
        height: calc(100vh - $--header-height-mobile);
        width: 64px!important;
        .setting-page__title, .underline-title {
          display: none;
        }
        .setting-page__nav {
          li {
            padding: 6px;
            .feather {
              width: 30px;
              height: 30px;
              margin: 0;
            }
            span {
              transition: opacity 0.1s ease;
              transition-delay: 0.12s;
              display: none;
              opacity: 0;
            }
          }
        }
      }
      .el-divider {
        margin: 8px 0;
      }
    }
    .el-main {
      position: relative;
      overflow: hidden;
      &.disabled {
        .overlay {
          flex-direction: column;
          display: flex;
          justify-content: center;
          align-items: center;
        }
      }
      .overlay {
        display: none;
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 1;
        &::before {
          background-color: rgba($--color-info, 0.4);
          backdrop-filter: blur(5px);
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          z-index: -1;
        }
      }
      .layout {
        background: #74ebd5; /* fallback for old browsers */
        background: -webkit-linear-gradient(to bottom, var(--color-bg-header) 0%, #acb6e5 40%, var(--color-shade-0)); /* Chrome 10-25, Safari 5.1-6 */
        background: linear-gradient(to bottom, var(--color-bg-header) 0%, #acb6e5 40%, var(--color-shade-0)); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
        // max-width: 992px;
        margin: 0 auto;
        #app-landing {
          margin: 0 auto;
          max-width: 1200px;
          height: 90px;
          overflow: hidden;
          transition: height 0.2s ease;
          &.toggle {
            height: 372px;
            @include media(md-down) {
              height: 300px;
            }
            @include media(xs) {
              height: 200px;
            }
          }
        }

        #app-landing-bg {
          // width: 100%;
          // max-width: initial !important;
          height: 100%;
          margin-top: 0;
          position: relative;
          user-select: none;
          border-bottom-left-radius: 24px;
          .cover {
            cursor: zoom-in;
            border-bottom-left-radius: 24px;
            background-size: cover !important;
            background-position: center !important;
            height: 100%;
          }
          &.cropper {
            .cover {
              display: none;
            }
            @include media(xs) {
              padding: 0;
            }
            overflow: hidden;
            .overlay {
              position: absolute;
              top: 0;
              left: 0;
              right: 0;
              bottom: 0;
              width: 100%;
              height: 100%;
              backdrop-filter: blur(4px);
            }
          }

          .change-cover {
            background: $--color-text-secondary;
            padding: 6px 10px;
          }

          .change-cover, .crop-cover {
            cursor: pointer;
            position: absolute;
            border-radius: 10px;
            bottom: 10px;
            right: 25px;
            display: flex;
            color: rgba($--color-info, 0.8);
            @include media(xs) {
              bottom: 2px;
              padding: 4px 10px;
              span {
                margin-left: 0;
                display: none;
              }
            }
          }

          .crop-cover {
            &.loading {
              .re-upload, .cancel, .save {
                pointer-events: none;
                background-color: rgba(var(--color-shade-2), 0.8);
                .el-loading-mask {
                  border-radius: 10px;
                  background-color: var(--color-shade-3);
                  .el-loading-spinner {
                    margin-top: -10px;
                  }
                }
              }
            }
            .re-upload, .cancel, .save {
              padding: 6px 10px;
              border-radius: 10px;
              display: flex;
              color: var(--color-shade-6);
              background-color: var(--color-shade-2);
            }
          }
          .re-upload, .change-cover {
            cursor: pointer;
            input {
              position: absolute;
              visibility: hidden;
            }
          }

          &.locked {
            #app-landing-bg {
              position: fixed;
              // position: sticky;
              width: 100%;
              height: $--header-height;
              top: 0;
              left: 0;
              margin-top: 0 !important;
              .change-cover {
                display: none;
              }
              @include media(sm-down) {
                height: $--header-height-mobile;
              }
            }
          }
        }

        // CONTENT
      }
      #app-content {
        margin: 0 auto;
        max-width: 1200px;
        .container {
          margin: auto;

          // @include media(md-down) {
          // 	width: 100%;
          // }
          @include media(sm-down) {
            display: block;
          }
        }

        .profile-header {
          display: flex;
          justify-content: space-between;
          @include media(sm-down) {
            .title { margin-top: 16px; }
            .title, .subtitle { font-size: 18px; }
          }

          @include media(xs) {
            display: flex;
            flex-direction: column;
            .profile-avatar {
              text-align: center;
              .avatar {
                margin-left: 0!important;
              }
              .upload {
                left: calc(50% - 74px)!important;
              }
              .background-tool {
                left: calc(50% - 74px)!important;
              }
            }
          }

          .profile-avatar {
            position: relative;
            height: 80px;
            .upload {
              position: absolute;
              background: transparent;
              left: 16px;
              z-index: 1;
              width: 148px;
              height: 36px;
              bottom: 10px;
              backdrop-filter: blur(2px);
            }
            .avatar {
              width: 140px;
              height: 140px;
              border: 4px solid var(--color-shade-2);
              border-radius: 50%;
              margin-left: 16px;
              transform: translate(0,-50%);
              cursor: zoom-in;
              user-select: none;
            }
            .background-tool {
              position: absolute;
              background: transparent;
              left: 16px;
              bottom: 6px;
              z-index: 1;
              width: 140px;
              border: 4px solid var(--color-shade-2);
              border-top: none;
              border-bottom-left-radius: 140px;
              border-bottom-right-radius: 140px;
              height: 70px;
              display: flex;
              flex-direction: column;
              .feather {
                color: var(--color-shade-1);
              }
              .top {
                height: 70px;
                cursor: zoom-in;
              }
              .bottom {
                height: 70px;
              }
            }
          }

          .info {
            flex: 1 1;
            width: calc(100% - 164px);
            @include media(xs) {
              width: 100%;
            }
            @include media(mobile) {
              display: flex;
              flex-direction: column;
              .username-and-contact {
                padding: 0 10px;
              }
            }
            .username-and-contact {
              flex: 1;
              padding: 8px 6px 4px;
              max-width: 600px;
              min-width: 0;
              color: var(--color-shade-6);
              // @include media(sm-down) {
              //   max-width: calc(100vw - 204px);
              // }
              .username {
                margin-right: 0;
                margin-top: 0!important;
                margin-bottom: 6px;
                font-size: 26px;
                font-weight: 500;
              }
              .contact {
                color: var(--color-shade-5);
                .feather {
                  cursor: pointer;
                  &:hover {
                    color: var(--color-primary);
                  }
                }
              }
            }
          }
        }

        &.header-locked .profile-header {
          position: sticky;
          top: $--header-height;
          grid-template-columns: 80px auto auto;
          z-index: 1;
          box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
          background: var(--color-shade-1);
          @include media(sm-down) {
            top: $--header-height-mobile;
          }
          @include media(md-down) {
            width: 100%;
          }
          .avatar {
            width: 48px;
            height: 48px;
            transform: translate(0, 0);
            margin-top: 12px;
          }
          .background-tool, .upload {
            display: none;
          }
        }
        .profile-content {
          padding-top: 4px;
          grid-row-start: 2;
          @include media(sm-down) {
            grid-row-start: 3;
          }

          .content-navigation ul {
            height: 49px;
            padding: 0;
            list-style: none;
            margin: 0 16px;

            li {
              float: left;
              padding: 16px;
              cursor: pointer;

              &:hover {
                background: var(--color-shade-2);
              }
              &.active {
                color: $color-custom-brand;
                background: rgba($color-custom-brand, 0.15);
                box-shadow: 0 4px 0 $color-custom-brand inset;
              }
            }
          }
        }
        .profile-details {
          padding: 16px;
          grid-row-start: 2;
          @include media(sm-down) { grid-row-start: 2; }
          &__label {
            margin-bottom: 9px!important;
          }
          .detail-section {
            margin-bottom: 24px;
            .add-social-link {
              color: var(--color-shade-6);
              border-radius: 50%;
              padding: 6px!important;
            }
          }
        }
      }
      .profile-actions {
        min-width: 60px;
        text-align: right;
        padding: 18px 0px 16px 0;
        button, a {
          border: none;
          padding: 16px 12px;
          cursor: pointer;
          vertical-align: top;
          float: left;
          height: 40px;
          border-radius: 4px;
          transition: 0.1s ease;
          font-size: $--size-base;
          text-transform: uppercase;
          @include media(xs) {
            padding: 16px 8px;
          }
          &.more-btn {
            padding: 12px 8px;
          }
        }
        a {
          padding: 0 12px;
        }
        button.follow, button.message {
          margin-right: 8px;
          width: 130px;
          justify-content: center;
          // color: var(--color-shade-6);
          @include media(sm-down) {
            padding: 6px;
            width: 44px;
          }
          &.active {
            @include media(mobile) {
              width: 130px;
              div {
                display: block !important;
              }
            }
          }
        }
      }
      .el-form {
        &-item__content {
          display: flex;
        }
        .el-alert {
          word-break: break-word;
          margin: 0 0 20px 120px;
          width: calc(100% - 120px - 84px);
        }
        @include media(xs) {
          &.el-form--label-left {
            .el-alert {
              margin: 0 0 4px;
              width: 100%;
            }
          }
        }
      }
      .stat-card {
        margin: 6px 0;
        .el-card__body {
          display: flex;
          align-items: center;
          justify-content: space-between;
          .total {
            font-weight: 500;
            font-size: 18px;
          }
          .title {
            font-size: 18px;
            font-family: sans-serif;
            font-weight: 600;
          }
        }
      }
      .anal-card {
        margin: 6px 0;
        .el-card__body {
          padding: 20px 6px 0;
        }
      }
    }
  }
  &__title {
    color: var(--color-shade-8);
    padding: 0 6px;
    margin-bottom: 0;
  }
  &__nav {
    list-style: none;
    padding: 0;
    li {
      color: var(--color-shade-6);
      line-height: 24px;
      height: 32px;
      padding: 6px 10px;
      border-radius: $--radius-medium;
      cursor: pointer;
      user-select: none;
      margin: 4px 0;
      font-weight: 500;
      span {
        opacity: 1;
      }
      &.is-active {
        background-color: rgba($--color-text-secondary, 0.7);
        .feather {
          color: $--color-brand;
        }
        span {
          color: var(--color-shade-7);
        }
      }
      &:hover, &:active, &:focus {
        color: var(--color-shade-7);
        background-color: rgba($--color-text-secondary, 0.6);
      }
    }
  }
}
</style>
