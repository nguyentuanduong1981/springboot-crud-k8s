import { SITEMAP_EXCLUDE } from './utilities/constants'

export default {
  // Global page headers: https://go.nuxtjs.dev/config-head
  head: {
    titleTemplate: '%s | Meta365',
    title: 'Meta365',
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, height=device-height, initial-scale=1, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, viewport-fit=cover' },
      { hid: 'description', name: 'description', content: 'Meta365' },
      { hid: 'description', name: 'theme-color', content: '#f9bc15' },
      { name: 'msapplication-TileColor', content: '#282828' },
      { name: 'format-detection', content: 'telephone=no' },
      { name: 'google-site-verification', content: 'trSKiHXMAuhfmvsmNI0FxIv5yzuhWuIh1QR2DnYzZps' },
      { hid: 'apple-mobile-web-app-capable', name: 'apple-mobile-web-app-capable', content: 'yes' }
    ],
    link: [
      { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' },
      { rel: 'alternate', hreflang: 'x' },
      { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
      { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossorigin: 'crossorigin' },
      {
        rel: 'stylesheet',
        href:
          'https://fonts.googleapis.com/css2?family=Barlow:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Roboto:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap'
      }
    ],
    script: [
      { src: 'https://cdn.polyfill.io/v3/polyfill.min.js', body: true },
      // { src: 'https://sp.zalo.me/plugins/sdk.js', body: true }
    ]
  },

  // Global CSS: https://go.nuxtjs.dev/config-css
  css: [
    'element-ui/lib/theme-chalk/index.css',
    '@/assets/styles/_index.scss'
  ],

  styleResources: {
    scss: [
      '@/assets/styles/_settings.scss'
    ]
  },

  // Plugins to run before rendering page: https://go.nuxtjs.dev/config-plugins
  plugins: [
    '@/plugins/element-ui',
    { src: '@/plugins/i18n' },
    '@/plugins/flows',
    { src: '@/plugins/axios' },
    { src: '@/plugins/api' },
    { src: '@/plugins/clientOnly', mode: 'client' },
    { src: '@/plugins/workspaces', mode: 'client' },
    // { src: '@/plugins/persistedstate' },
    { src: '@/plugins/directives' },
    { src: '@/plugins/sfx', mode: 'client' },
    { src: '@/plugins/ga', mode: 'client' },
  ],

  // Auto import components: https://go.nuxtjs.dev/config-components
  components: true,

  // Modules for dev and build (recommended): https://go.nuxtjs.dev/config-modules
  buildModules: [
    // https://go.nuxtjs.dev/eslint
    '@nuxtjs/eslint-module',
    '@nuxtjs/style-resources',
    '@nuxtjs/color-mode',
    '@nuxtjs/composition-api/module',
    '@nuxtjs/svg'
    // 'nuxt-compress'
  ],

  // Modules: https://go.nuxtjs.dev/config-modules
  modules: [
    // https://go.nuxtjs.dev/axios
    '@nuxtjs/axios',
    // https://go.nuxtjs.dev/pwa
    '@nuxtjs/pwa',
    '@nuxtjs/auth-next',
    '@nuxtjs/i18n',
    '@nuxt/image',
    'vue-social-sharing/nuxt',
    '@nuxtjs/sitemap'
    // [
    //   'nuxt-compress',
    //   {
    //     gzip: {
    //       threshold: 8192
    //     },
    //     brotli: {
    //       threshold: 8192
    //     }
    //   }
    // ]
  ],

  i18n: {
    // baseUrl: `${process.env.APP_HOST}:${process.env.APP_PORT}`,
    strategy: 'no_prefix',
    // vueI18nLoader: true,
    detectBrowserLanguage: {
      useCookie: true,
      cookieKey: 'i18n_redirected',
      onlyOnRoot: true,
      alwaysRedirect: true
    },
    locales: [
      {
        code: 'vi',
        name: 'Vietnamese',
        file: 'vi/index.js',
        iso: 'vi-VN'
      },
      {
        code: 'en',
        name: 'English',
        file: 'en/index.js',
        iso: 'en-US'
      }
    ],
    lazy: true,
    defaultLocale: 'vi',
    langDir: 'locales/',
    vueI18n: {
      // fallbackLocale: 'vi'
      // messages: {
      //   en,
      //   vi
      // }
    }
  },

  auth: {
    localStorage: false,
    strategies: {
      local: {
        user: {
          property: 'data'
        },
        token: {
          property: 'data.access_token',
          maxAge: 345600,
          global: true,
        },
        endpoints: {
          login: {
            url: '/api/v1/authentication/login',
            method: 'post'
          },
          logout: false,
          user: { url: '/api/v1/user/profile', method: 'get', property: 'data' }
        }
      },
      google: {
        codeChallengeMethod: '',
        clientId: process.env.GOOGLE_CLIENT_ID || '605783579429-l7ng7ou4apm1o3b19nbjatbo69glpqfk.apps.googleusercontent.com',
        user: {
          property: 'data'
        },
        endpoints: {
          userInfo: '/api/v1/user/profile'
        },
        // redirectUri: '/login-checking?provider=google',
        token: {
          property: 'data.access_token',
          maxAge: 345600,
          global: true,
        },
        scope: ['openid', 'profile', 'email'],
        responseType: 'code',
        autoLogout: true
      },
      facebook: {
        scheme: 'oauth2',
        clientId: process.env.FACEBOOK_CLIENT_ID,
        user: {
          property: 'data'
        },
        endpoints: {
          userInfo: '/api/v1/user/profile'
        },
        // redirectUri: '/login-checking?provider=facebook',
        token: {
          property: 'data.access_token',
          maxAge: 345600,
          global: true,
        },
        scope: ['public_profile', 'email', 'user_birthday', 'user_location', 'user_gender'],
        responseType: 'code',
        autoLogout: true
      }
    },
    redirect: {
      callback: 'login-checking', // default value
      home: false, // --->override
      login: '/login-checking?request-login=true', // default value
      logout: '/' // default value
    },
    plugins: [
      '@/plugins/auth-redirect.js'
    ]
  },

  router: {
    middleware: [
      // 'maintenance'
    ],
    extendRoutes (routes, resolve) {
      routes.push({
        name: '_user-profile',
        path: '/@:username',
        component: resolve(__dirname, 'pages/user-profile')
      })
      return routes
    }
  },

  // Axios module configuration: https://go.nuxtjs.dev/config-axios
  axios: {
    proxy: true,
    credentials: true
    // https: true
  },

  proxy: {
    '/api/': { target: process.env.NODE_ENV === 'production' ? process.env.API_URL : process.env.API_URL, pathRewrite: {'^/api/': '/api/'}, secure: process.env.NODE_ENV === 'production' }
  },

  // PWA module configuration: https://go.nuxtjs.dev/pwa
  pwa: {
    manifest: {
      name: 'Meta365',
      short_name: 'Meta365',
      display: 'fullscreen',
      theme_color: '#f9bc15',
      background_color: '#000000',
      lang: 'vi'
    },
    // workbox: {
    //   cleanupOutdatedCaches: true
    // },
    meta: {
      mobileAppIOS: true,
      appleStatusBarStyle: 'black-translucent',
      nativeUI: true
    },
    icon: {
      source: '~/static/icon.png',
      // purpose: ['any', 'maskable'],
      sizes: [64, 120, 144, 152, 192, 384, 512]
    }
  },

  image: {
    providers: {
      meta365: {
        name: 'meta365',
        options: {
        },
        baseURL: 'http://localhost:3000/asset',
        modifiers: {
          effect: 'sharpen:100',
          quality: 'auto:best',
        },
        provider: require.resolve('./utilities/meta365-media-provider')
      }
    }
  },

  /*
  ** Nuxt Color Mode
  ** See https://v2.color-mode.nuxtjs.org/#configuration
  */

  colorMode: {
    fallback: 'dark', // fallback value if not system preference found
  },

  /*
   ** Sitemap module configuration
   ** See https://sitemap.nuxtjs.org/guide/configuration
   */

  sitemap: {
    hostname: process.env.DOMAIN,
    gzip: true,
    exclude: SITEMAP_EXCLUDE,
    routes: () => {
      try {
        return []
      } catch (error) {
        console.log(`dynamic routes error: ${error}`)
      }
    }
  },

  // Build Configuration: https://go.nuxtjs.dev/config-build
  build: {
    transpile: [/^element-ui/, /^libphonenumber-js/, /echarts/, /zrender/],
    // analyze: true,
    extends(config, ctx) {
      config.resolve.symlinks = false
      config.devtool = false
      if (ctx && ctx.isClient) {
        config.optimization.splitChunks.maxSize = 512000
        const { vendor } = config.entry
        const vendor2 = ['libphonenumber-js', 'element-ui', 'country-codes-list', 'lodash', 'vue-feather-icons', 'swiper', 'vue-country-flag']
        config.entry.vendor = vendor.filter(v => !vendor2.includes(v))
        config.entry.vendor2 = vendor2
        const plugin = config.plugins.find((plugin) => ~plugin.chunkNames.indexOf('vendor'))
        const old = plugin.minChunks
        plugin.minChunks = function (module, count) {
          return old(module, count) && !(/(libphonenumber-js)|(element-ui)|(country-codes-list)|(lodash)|(vue-feather-icons)|(swiper)|(vue-country-flag)/).test(module.context)
        }
        config.optimization.minimize = true
      }
      // config.module.rules.push({
      //   test: /\.(pug)$/,
      //   loader: 'pug-plain-loader',
      //   options: {
      //     basedir: path.resolve(__dirname, 'templates')
      //   }
      // })
      config.module.rules.push({
        test: /\.(ogg|mp3|wav|mpe?g)$/,
        loader: 'file-loader',
        options: {
          name: '[path][name].[ext]'
        }
      })
      // config.plugins.push(new webpack.ProvidePlugin({
      // THREE: 'three'
      // }))
    },
    filenames: {
      app: ({ isDev }) => (isDev ? '[name].js' : '[name].[contenthash].js'),
      chunk: ({ isDev }) => (isDev ? '[name].js' : '[name].[chunkhash].js'),
      css: ({ isDev }) => (isDev ? '[name].css' : '[name][contenthash].css'),
      img: ({ isDev }) => (isDev ? '[path][name].[ext]' : 'img/[hash:7].[ext]'),
      font: ({ isDev }) =>
        isDev ? '[path][name].[ext]' : 'fonts/[hash:7].[ext]',
      video: ({ isDev }) =>
        isDev ? '[path][name].[ext]' : 'videos/[hash:7].[ext]'
    }
  },
  server: {
    port: 3010,
    host: '0.0.0.0'
  },
  vue: {
    // config: {
    //   ignoredElements: ['b:if'],
    // },
  },
  env: {
    domain: process.env.DOMAIN || 'https://www.meta365.ai',
    api: process.env.API_URL || 'https://api.meta365.ai',
    ga: process.env.GOOGLE_ANALYTICS_ID || 'G-N790F7F72G'
  }
}
