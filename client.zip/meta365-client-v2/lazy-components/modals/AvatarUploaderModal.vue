<template lang="pug">
el-dialog.avatar-uploader-modal.small(
  visible
  :close-on-press-escape="false"
  :close-on-click-modal="false"
  @close="close"
  :title="title"
  :width="'457px'"
)
  .cropper
    .cropper__background(v-image="image.src")
    cropper.cropper__image(
      :key="key"
      ref="cropper"
      :src="image.src"
      :auto-zoom="true"
      :canvas="{ minHeight: 128, minWidth: 128 , maxHeight: 2048, maxWidth: 2048 }"
      :minWidth="128"
      :minHeight="128"
      :stencil-props="stencilProps"
      image-restriction="fill-area"
      :stencil-component="$options.components.CircleStencil"
      @ready="ready"
      @error="error"
    )
    .action.d-flex
      label.el-button.el-button--small.el-button--primary.cropper__btn.cropper__btn__upload(
        size="small"
      )
        InputFile(
          :maximum="5"
          :accept="accept"
          @ready="loadImage"
        )
        | {{ $t('common.change') }}
      el-button.cropper__btn(
        type="primary"
        size="small"
        :loading="loading"
        @click="onCropImage"
      ) {{ $t('common.upload') }}

    .cropper__vertical-button
</template>

<script>
import { Cropper, CircleStencil } from 'vue-advanced-cropper'
import { FILE_ACCEPT } from '~/utilities/file'
import 'vue-advanced-cropper/dist/style.css'
import 'vue-advanced-cropper/dist/theme.compact.css'

export default {
  name: 'AvatarUploaderModal',

  components: {
    Cropper,
    CircleStencil,
  },

  mixins: [
  ],

  props: {
    src: {
      type: String,
      default: ''
    },

    accept: { type: String, default: FILE_ACCEPT.IMAGES },
  },

  data() {
    return {
      loading: false,
      title: this.$t('modal.upload_avatar.title'),
      key: 0,
      currentType: 'image/png',
      image: {
        src: '',
        type: 'image/png'
      }
    }
  },

  computed: {
    stencilProps () {
      return {
        handlers: {
          eastNorth: true,
          westNorth: true,
          westSouth: true,
          eastSouth: true
        }
      }
    },
  },

  created () {
    this.image.src = this.src
  },

  methods: {
    close(data) {
      data && this.$emit('done', data)
      this.$emit('close')
    },

    zoom () {
      this.$refs.cropper.zoom(2)
    },

    move () {
      this.$refs.cropper.move(100, 100)
    },

    loadImage(payload) {
      this.image = payload
    },

    onCropImage () {
      const { canvas } = this.$refs.cropper.getResult()
      if (canvas) {
        const form = new FormData()
        const type = this.currentType.split('/').slice(-1)[0]
        canvas.toBlob(blob => {
          const avatar = new File([blob], `avatar.${type}`, { lastModified: new Date().getTime(), type: this.currentType })
          form.append('file', avatar)
          this.loading = true
          this.$api.user.updateAvatar(form)
            .then(({ data }) => {
              this.close({ data })
            })
            .catch((error) => {
              this.$notify.error({
                title: this.title,
                message: error.response.data.message || this.$t('notification.error.upload_avatar_failed'),
              })
            })
            .finally(() => {
              this.loading = false
            })
        }, type)
      }
    },

    error () {
    },

    ready () {

    },

    destroyed() {
      if (this.file.src) {
        URL.revokeObjectURL(this.file.src)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
::v-deep.avatar-uploader-modal {
  .el-dialog {
    background-image: url(~@/assets/images/login-background.png);
    background-repeat: round;
    &__header {
      // padding-top: 42px;
      // text-align: center;
      .el-dialog__title {
        font-size: 24px;
        color: $--color-text-primary;
      }
    }
    &__body {
      .cropper {
        max-height: 450px;
        position: relative;
        border-radius: $--radius-mini;

        &__background {
          position: absolute;
          z-index: 0;
          width: 100%;
          height: 100%;
          background-size: cover;
          background-position: 50%;
          filter: blur(5px);
          opacity: 0.25;
        }
        &__vertical-button {
          position: absolute;
          left: 10px;
          top: 50%;
          transform: translateY(-50%);
        }

        &__image {
          min-height: auto;
          max-height: 400px;
          width: 100%;

          .vue-square-handler {
            border-radius: 50%;
            background: var(--color-primary);
          }

          .vue-simple-line {
            border-color: var(--color-primary);
            border-style: solid;
          }

          .vue-line-wrapper {
            &--north, &--south {
              cursor: ns-resize;
            }
            &--east, &--west {
              cursor: ew-resize;
            }
          }

          .vue-circle-stencil, .vue-rectangle-stencil--movable {
            cursor: crosshair;
          }

          .vue-rectangle-stencil--movable {
            cursor: crosshair;
          }

          .vue-handler-wrapper {
            &--east-south, &--west-north {
              cursor: nwse-resize;
            }
            &--east-north, &--west-south {
              cursor: nesw-resize;
            }
          }
        }

        &__btn {
          width: calc(100% - 2em);
          margin: 1em;
          position: inherit;
          &__upload {
            input {
              position: absolute;
              visibility: hidden;
            }
          }
        }
      }
    }
  }
}
</style>
