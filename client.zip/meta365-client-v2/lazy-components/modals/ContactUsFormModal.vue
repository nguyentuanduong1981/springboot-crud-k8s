<template lang="pug">
el-dialog.registration-modal.small(
  visible
  @close="close"
  :title="`${$t('modal.contact_us.title')}`"
  :width="'486px'"
)
  el-form(
    ref="contactFormRef"
    :model="contactForm"
    :rules="rules"
    label-position="top"
  )
    el-form-item(
      prop="phoneNumber"
      :error="errors.phoneNumber"
    )
      input-phone-number(
        v-model="contactForm.phoneNumber"
        :placeholder="`${$t('field.phoneNumber')}*`"
        ref="defaultFocus"
        @updateCountryCode="updateCountryCode"
        @updatePhoneNumberWithCode="updatePhoneNumberWithCode"
      )

    el-form-item(
      prop="fullName"
      :error="errors.fullName"
    )
      el-input(
        prop-type="fullName"
        v-model="contactForm.fullName"
        :placeholder="`${$t('field.fullName')}*`"
      )

    el-form-item(
      prop="content"
    )
      el-input(
        v-model="contactForm.content"
        type="textarea"
        :maxlength="256"
        show-word-limit
        :autosize="{ minRows: 2, maxRows: 4}"
        :placeholder="$t('field.content')"
        @keyup.enter.native="submitForm()"
      )
  span.dialog-footer(slot='footer')
    el-button(
      size="small"
      @click="close()"
    ) {{ $t('common.cancel') }}
    el-button(
      :loading="loading"
      size="small"
      type="primary"
      @click="submitForm()"
    ) {{ $t('modal.contact_us.send') }}
</template>

<script>
import DefaultFocus from '~/mixins/default-focus'
import { mapState } from 'vuex'

export default {
  name: 'ContactUsFormModal',
  mixins: [DefaultFocus],

  props: {
    project: {
      type: Object,
      default: () => ({}),
      required: true
    }
  },

  data() {
    const content = this.$t('modal.contact_us.i_am_interested_in_this_project')
    return {
      loading: false,
      contactForm: {
        fullName: '',
        phoneNumber: '',
        content,
        country: ''
      },
      phoneNumberWithCode: '',
      errors: {}
    }
  },

  computed: {
    rules() {
      return {
        fullName: [
          { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.fullName') }), trigger: 'change' },
        ],
        phoneNumber: [
          { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.phoneNumber') }), trigger: 'change' },
        ],
        content: [
          { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.content') }), trigger: 'change' },
        ]
      }
    },

    ...mapState('auth', {
      user: state => state.user
    })
  },

  mounted() {
    if (this.$auth.loggedIn) {
      this.contactForm.phoneNumber = this.user.phoneNumber
      this.contactForm.fullName = this.user.fullName
    }
  },

  methods: {
    clearError () {
      this.errors = {}
      // this.$nextTick(() => {
      this.$refs.contactFormRef.clearValidate()
      // })
    },

    submitForm() {
      this.$refs.contactFormRef.validate((valid) => {
        if (!valid) return false
        this.clearError()
        this.loading = true
        this.$api.project.createContactForm({
          ...this.contactForm,
          project: this.project._id
        })
          .then(() => {
            this.$notify.success({
              // title: this.$t('modal.registration.title'),
              message: this.$t('notification.contact_form_has_been_received'),
            })
            this.close({})
          })
          .catch((error) => {
            const response = error.response
            if(response.status === 422) {
              this.errors = response.data.message.reduce((errors, errorField) => {
                errors[errorField.field] = this.$t(errorField.message)
                return errors
              }, {})
              return this.$notify.error({
                message: this.$t('notification.error.invalid_information_input'),
              })
            }
            this.$notify.error({
              // title: this.$t('modal.registration.title'),
              message: this.$t(error.response.data.message) || this.$t('notification.error.an_error_has_occurred'),
            })
          })
          .finally(() => {
            this.loading = false
          })
      })
    },

    close(data) {
      data ? this.$emit('done', data) : this.$emit('error', new Error('Contact us cancelled'))
      this.$emit('close')
    },

    updateCountryCode (code) {
      this.contactForm.country = code
    },

    updatePhoneNumberWithCode (phoneNumberWithCode) {
      this.phoneNumberWithCode = phoneNumberWithCode
    },
  }
}
</script>

<style lang="scss" scoped>
::v-deep.registration-modal {
  .el-dialog {
    &__header {
      // padding-top: 42px;
      // text-align: center;
      .el-dialog__title {
        font-size: 24px;
        color: var(--color-shade-6);
      }
    }
    &__body {
      padding-bottom: 0;
      .el-form-item {
        margin-bottom: 30px;
        &__label {
          line-height: 32px;
          padding-bottom: 0;
          color: var(--color-shade-6);
        }
      }
    }
    .trouble {
      margin-top: 25px;
      margin-bottom: 10px;
      .el-form-item__content {
        line-height: 10px;
      }
      a {
        color: var(--color-primary);
        font-size: $--size-base-xs;
        text-decoration: none;
      }
    }
  }
}
</style>
