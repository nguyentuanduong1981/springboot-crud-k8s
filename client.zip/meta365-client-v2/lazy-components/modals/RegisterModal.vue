<template lang="pug">
el-dialog.registration-modal.small(
  visible
  @close="close"
  :title="`${$t('modal.registration.title')}`"
  :width="'457px'"
)
  el-form(
    ref="formRegister"
    :model="credentials"
    :rules="rules"
    label-position="top"
  )
    el-form-item.form-item-phonenumber(
      prop="phoneNumber"
      :error="errors.phoneNumber"
    )
      input-phone-number(
        v-model="credentials.phoneNumber"
        ref="defaultFocus"
        :maxlength="9"
        :placeholder="$t('field.phoneNumber')"
        @updateCountryCode="updateCountryCode"
        @updatePhoneNumberWithCode="updatePhoneNumberWithCode"
      )

    el-form-item(
      prop="password"
      :error="errors.password"
    )
      el-input(
        prop-type="password"
        show-password
        v-model="credentials.password"
        :placeholder="$t('field.password')"
      )

    el-form-item(
      prop="confirmPassword"
    )
      el-input(
        prop-type="password"
        show-password
        v-model="credentials.confirmPassword"
        :placeholder="$t('field.confirmPassword')"
        @keyup.enter.native="submitForm()"
      )

    el-form-item
      el-button.fw.btn-register(
        size="small"
        :loading="loading"
        @click.prevent.native="submitForm()"
      ) {{ $t('modal.registration.register') }}
  div.sign-up {{ $t('modal.registration.already_have_an_account') }}?
    nuxt-link(
      to="/"
      @click.stop.native="onClickSignIn"
    ) {{ $t('modal.registration.login') }}
</template>

<script>
import DefaultFocus from '~/mixins/default-focus'

export default {
  name: 'AuthenticationModal',
  mixins: [DefaultFocus],

  data() {
    return {
      loading: false,
      phoneNumberWithCode: '',
      credentials: {
        country: '',
        phoneNumber: '',
        password: '',
        confirmPassword: ''
      },
      errors: {}
    }
  },

  computed: {
    rules() {
      const validateConfirmPassword = (_rule, value, callback) => {
        if (value !== this.credentials.password) {
          callback(new Error(this.$t('notification.error.form_is_confirmed', { field: this.$t('field.confirmPassword'), confirmField: this.$t('field.password') })))
        } else callback()
      }
      const validateStrongPassword = (_rule, value, callback) => {
        if(!(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d]{8,}$/.test(value))) {
          callback(new Error(this.$t('notification.error.form_is_strength_password')))
        } else callback()
      }
      return {
        phoneNumber: [
          { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.phoneNumber') }), trigger: 'change' },
          // { pattern: /([+84|84|0]+(3+[2-9]|5+[6|8|9]|7+[0|6|7|8|9]|8+[1-9]|9+[1-4|6-9]))+([0-9]{7})\b/, message: this.$t('notification.error.phoneNumber_is_invalid', { field: this.$t('field.phoneNumber'), pattern: 'a-z 0-9' }), trigger: ['change', 'blur'] },
        ],
        password: [
          { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.password') }), trigger: 'change' },
          { validator: validateStrongPassword, trigger: 'change' }
        ],
        confirmPassword: [
          { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.confirmPassword') }), trigger: 'change' },
          { validator: validateConfirmPassword, trigger: 'change' }
        ]
      }
    },
    strategies: () => [
      // { key: 'google', name: 'google', src: '/socials/google.svg' },
      // { key: 'facebook', name: 'facebook', src: '/socials/facebook.svg' },
      { key: 'wallet', name: 'wallet', src: '/wallets/wallet.svg' },
    ]
  },
  methods: {
    clearError () {
      this.errors = {}
      this.$nextTick(() => {
        this.$refs.formRegister.clearValidate()
      })
    },

    submitForm() {
      this.$refs.formRegister.validate((valid) => {
        if (!valid) return false
        this.clearError()
        this.loading = true
        this.$api.authentication.registration({
          phoneNumber: this.phoneNumberWithCode,
          password: this.credentials.password,
          country: this.credentials.country
        })
          .then(() => {
            this.$notify.success({
              // title: this.$t('modal.registration.title'),
              message: this.$t('notification.created_account_successfully'),
            })
            this.close({})
          })
          .catch((error) => {
            const response = error.response
            if(response.status === 422) {
              this.errors = response.data.message.reduce((errors, errorField) => {
                errors[errorField.field] = this.$t(errorField.message)
                return errors
              }, {})
              return this.$notify.error({
                message: this.$t('notification.error.invalid_information_input'),
              })
            }
            this.$notify.error({
              // title: this.$t('modal.registration.title'),
              message: this.$t(error.response.data.message) || this.$t('notification.error.account_creation_failed'),
            })
          })
          .finally(() => {
            this.loading = false
          })

      })
    },

    onClickOtherLogin (key) {
      switch(key) {
        case 'google':
        case 'facebook':
          break;
        case 'wallet': {
          this.$flows.loginWallet({
            parent: this
          })
          break;
        }
      }
    },

    onClickSignIn () {
      this.$emit('close')
      this.$flows.login({
        parent: this
      })
    },

    updateCountryCode (code) {
      this.credentials.country = code
    },

    updatePhoneNumberWithCode (phoneNumberWithCode) {
      this.phoneNumberWithCode = phoneNumberWithCode
    },

    close(data) {
      data ? this.$emit('done', data) : this.$emit('error', new Error('Registration cancelled'))
      this.$emit('close')
    }
  }
}
</script>

<style lang="scss" scoped>
::v-deep.registration-modal {
  .el-dialog {
    &__header {
      // padding-top: 42px;
      // text-align: center;
      .el-dialog__title {
        font-size: 24px;
        color: var(--color-shade-6);
      }
    }
    &__body {
      .el-form-item {
        margin-bottom: 28px;
        &__label {
          line-height: 32px;
          padding-bottom: 0;
          color: var(--color-shade-6);
        }
        .form-item-phonenumber {
          &.is-error {
            .vue-phone-number-input {
              border-color: #ff4646;

              .input-tel__input {
                &:focus {
                  border-color: transparent !important;
                }
              }

              .country-selector.has-value {
                .country-selector__input {
                  &:focus {
                    border-color: #212240 !important;
                  }
                }
              }
            }
          }
        }
      }
    }
    .trouble {
      margin-top: 25px;
      margin-bottom: 10px;
      .el-form-item__content {
        line-height: 10px;
      }
      a {
        color: var(--color-primary);
        font-size: $--size-base-xs;
        text-decoration: none;
      }
    }
    .social-login-divider {
    }
    .social {
      padding: 4px 12px;
      margin: 4px auto;
      font-size: 13px;
      strong {
        vertical-align: super;
      }
    }
    .sign-up {
      text-align: center;
      padding-top: 15px;
      font-size: $--size-base-xs;
      a {
        color: $--color-primary;
        text-decoration: none;
      }
    }
    .btn-register {
      text-transform: uppercase;
      font-size: 15px;
      font-weight: bold;
    }
  }
}
</style>
