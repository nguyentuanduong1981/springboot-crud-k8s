<template lang="pug">
el-dialog.qr-code-modal.small(
  visible
  :close-on-press-escape="false"
  :close-on-click-modal="false"
  @close="close"
  :title="`${$t(title)}`"
  :width="'457px'"
)
  client-only
    QrCodeGenerator(
      :qr="qr"
      :download="download"
    )
      el-button(type="primary" size="mini") {{ $t('pages.profile.download_qr_code') }}

</template>

<script>
export default {
  name: 'QrCodeModal',

  components: {
    QrCodeGenerator: () => import('@/lazy-components/QrCodeGenerator')
  },

  props: {
    title: {
      type: String,
      default: 'modal.qr_code_modal.title'
    },
    qr: {
      type: Object,
      default: () => ({})
    },

    download: {
      type: Object,
      default: () => ({})
    }
  },

  data() {
    return {}
  },

  methods: {
    close(data) {
      data && this.$emit('done', data)
      this.$emit('close')
    }
  },
}
</script>

<style lang="scss" scoped>
::v-deep.qr-code-modal {
  .el-dialog {
    background-image: url(~@/assets/images/login-background.png);
    background-repeat: round;
    &__header {
      // padding-top: 42px;
      // text-align: center;
      .el-dialog__title {
        font-size: 24px;
        color: $--color-text-primary;
      }
    }
    &__body {
      .copy-component {
        color: $--color-text-primary;
        background: var(--color-bg-header);
        border: 1px solid var(--color-primary);
        border-radius: 4px;
        padding: 0 8px;
        margin-bottom: 10px;
        justify-content: space-between;
        &__text {

        }
        &.copied {
          .feather {
            color: $--color-success;
          }
        }
        .feather {
          flex: 0 0 24px;
        }
      }
    }
  }
}
</style>
