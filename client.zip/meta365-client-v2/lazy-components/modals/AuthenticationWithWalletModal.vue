<template lang="pug">
el-dialog.authentication-with-wallet-modal.small(
  visible
  @close="close"
  :title="`${$t('modal.authentication.continue_with')} ${$t('modal.authentication.wallet')}`"
  :width="'457px'"
)
  el-button.social.fw(
    v-for="wallet in wallets" :key="wallet.key"
    @click.native="connect(wallet.key)"
  )
    nuxt-img.btn-social(
      :src="wallet.icon"
      width="24"
      :alt="wallet.label"
      :title="wallet.label"
    )
    strong.ml-4 {{ $t('modal.authentication.continue_with') }} {{ wallet.label }}
</template>

<script>
import { ethers } from 'ethers'
const WALLETS_SUPPORT = [
  {
    key: 'metamask',
    label: 'Metamask',
    icon: '/wallets/metamask.svg'
  }
]
export default {
  name: 'AuthenticationWithWallet',

  data () {
    return {
      wallets: WALLETS_SUPPORT
    }
  },

  methods: {
    close(data) {
      data ? this.$emit('done', data) : this.$emit('error', new Error('Authentication with Wallet cancelled'))
      this.$emit('close')
    },

    handleLogin (data) {
      const { nonce, publicAddress, chainId } = data
      const message = `I am signing my one-time nonce: ${nonce}`;
      const msg = `0x${Buffer.from(message, 'utf8').toString('hex')}`;
      return window.ethereum
        .request({
          method: 'personal_sign',
          params: [msg, publicAddress, 'Example password'],
        })
        .then((signature) => {
          const body = {
            signature,
            publicAddress,
            chainId
          }
          this.$api.authentication.loginWithWallet(body)
            .then((res) => {
              this.$auth.setStrategy('local')
              this.$auth.setUserToken(`Bearer ${res.data.access_token}`)
              this.$axios.setToken(res.data.access_token, 'Bearer')
              this.$auth.ctx.app.$axios.setToken(res.data.access_token, 'Bearer')
              this.close({})
            })
            .catch((error) => {
              console.log(error)
            })
        })
    },

    connect (key) {
      switch(key) {
        case 'metamask': {
          this.connectMetamask()
          break
        }
      }
    },

    connectMetamask () {
      if (!window.ethereum) {
        return this.$message({
          message: this.$t('notification.error.no_metamask'),
          type: 'warning'
        })
      }
      window.ethereum.enable()
        .then(() => {
          window.ethereum.request({
            method: 'eth_requestAccounts',
          })
            .then((accounts) => {
              let provider = null
              const address = accounts[0]
              if (address) {
                provider = new ethers.providers.Web3Provider(window.ethereum, 'any')
              }
              return {
                provider,
                address
              }
            })
            .then(async ({ provider, address }) => {
              const network = await provider.getNetwork()
              this.$api.authentication.getPublicAddressAvailability(address)
                .then(async ({ data }) => {
                  if (!data) {
                    const response = await this.$api.authentication.registerWithWallet({
                      publicAddress: address,
                      chainId: network.chainId
                    })
                    data = response.data
                  }
                  this.handleLogin({
                    publicAddress: address,
                    chainId: network.chainId,
                    nonce: data.nonce
                  })
                })
            })
        })
        .catch(() => {
          return this.$message({
            message: this.$t('notification.error.not_allow_metamask'),
            type: 'warning'
          })
        })
    }
  },
}
</script>

<style lang="scss" scoped>
.authentication-with-wallet-modal {
  .social {
    padding: 8px 12px;
    margin: 2px auto;
    strong {
      vertical-align: super;
    }
  }
}
</style>
