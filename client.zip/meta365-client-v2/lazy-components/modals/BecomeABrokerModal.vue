<template lang="pug">
el-dialog.request-to-become-a-broker.small(
  visible
  :close-on-press-escape="false"
  :close-on-click-modal="false"
  @close="close"
  :title="$t('navigation.become_a_broker')"
  :width="'457px'"
)
  p {{ $t('pages.settings.message_become_a_broker') }}
  el-form(
    :model="termForm"
    :rules="rules"
    ref="termForm"
    :validate-on-rule-change="false"
  )
    el-form-item(
      prop="isAccept"
    )
      el-checkbox(
        v-model="termForm.isAccept"
      ) {{ $t('common.agree_terms_of_use') }}
  span.dialog-footer(slot='footer')
    el-button(
      size="small"
      @click="close()"
    ) {{ $t('common.cancel') }}
    el-button(
      :loading="loading"
      size="small"
      type="primary"
      @click="onClickBecomeABroker"
    ) {{ $t('common.confirm') }}

</template>

<script>

export default {
  name: 'BecomeABrokerModal',

  components: {
  },

  props: {
  },

  data () {
    return {
      termForm: {
        isAccept: false
      },
      visible: true,
      loading: false,
    }
  },

  computed: {
    rules() {
      const validateAcceptTerms = (_rule, value, callback) => {
        if (!value) {
          callback(new Error(this.$t('common.message_accept_terms_of_use')))
        } else {
          callback()
        }
      }
      return {
        isAccept: [
          { validator: validateAcceptTerms, trigger: ['change', 'blur'] }
        ]
      }
    }
  },

  methods: {
    close(data) {
      data && this.$emit('done', data)
      this.$emit('close')
    },

    onClickBecomeABroker () {
      this.$refs.termForm.validate((valid) => {
        if (!valid) return false
        this.loading = true
        this.$api.user.becomeABroker()
          .then((res) => {
            this.close(res.data)
          })
          .catch((error) => {
            this.$notify.error({
              message: this.$t(error.response.data.message || 'notification.error.default'),
            })
          })
          .finally(() => {
            this.loading = false
          })

      })
    }
  },
}
</script>

<style lang="scss" scoped>
::v-deep.request-to-become-a-broker {
  .el-dialog {
    &__header {
      // padding-top: 42px;
      // text-align: center;
      .el-dialog__title {
        font-size: 24px;
        color: var(--color-shade-6);
      }
    }
    &__body {
      padding: 10px 30px;
      color: var(--color-shade-6);
      .el-input--error {
        margin-top: 2px;
        font-size: 13px;
        color: $--color-danger;
      }
    }
  }
}
</style>
