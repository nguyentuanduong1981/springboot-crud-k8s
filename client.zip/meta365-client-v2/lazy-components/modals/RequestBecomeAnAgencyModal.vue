<template lang="pug">
el-dialog.request-to-become-an-agency-modal(
  visible
  @close="close"
  :title="`${$t('modal.request_to_become_an_agency.title')}`"
  :width="'576px'"
)
  el-form(
    ref="formRequestAgency"
    :model="formAgency"
    :rules="rules"
    label-position="top"
  )
    el-form-item.form-item-phonenumber(
      prop="agentType"
      :label="$t('field.agentType')"
    )
      .flex-center-y
        el-radio.mr-10(
          v-model="formAgency.agentType"
          label="agency"
          border
        ) {{ $t('modal.request_to_become_an_agency.agency') }}
        el-radio(
          v-model="formAgency.agentType"
          label="investor"
          border
        ) {{ $t('modal.request_to_become_an_agency.investor') }}

    el-form-item.form-item-phonenumber(
      prop="phoneNumber"
      :label="$t('field.phoneNumber')"
    )
      input-phone-number(
        v-model="formAgency.phoneNumber"
        ref="defaultFocus"
        :placeholder="$t('field.phoneNumber')"
        @updateCountryCode="updateCountryCode"
        @updatePhoneNumberWithCode="updatePhoneNumberWithCode"
      )

    el-form-item(
      prop="name"
      :label="$t('field.name')"
    )
      el-input(
        v-model="formAgency.name"
        @keyup.enter.native="submitForm('formRequestAgency')"
        :placeholder="$t('field.name')"
      )

    el-form-item(
      prop="shortName"
      :label="$t('field.shortName')"
    )
      el-input(
        v-model.trim="formAgency.shortName"
        @keyup.enter.native="submitForm('formRequestAgency')"
        :placeholder="$t('field.shortName')"
      )

    el-form-item(
      prop="address"
      :label="$t('field.address')"
    )
      el-input(
        v-model="formAgency.address"
        @keyup.enter.native="submitForm('formRequestAgency')"
        :placeholder="$t('field.address')"
      )

    el-form-item(
      prop="taxCode"
      :label="$t('field.taxCode')"
    )
      el-input(
        v-model="formAgency.taxCode"
        @keyup.enter.native="submitForm('formRequestAgency')"
        :placeholder="$t('field.taxCode')"
      )

    el-form-item(
      prop="email"
      :label="$t('field.email')"
    )
      el-input(
        v-model="formAgency.email"
        @keyup.enter.native="submitForm('formRequestAgency')"
        :placeholder="$t('field.email')"
      )

    el-form-item.accept(
      prop="accept"
    )
      el-checkbox(
        v-model="formAgency.accept"
      )
        | {{ $t('field.accept') }}
    el-form-item.mt-20
      el-button.fw.btn-login(
        type="primary"
        size="small"
        :loading="loading"
        @click.native="submitForm('formRequestAgency')"
      ) {{ $t('modal.request_to_become_an_agency.submit') }}
</template>

<script>
import DefaultFocus from '~/mixins/default-focus'
import { omit } from 'lodash'

export default {
  name: 'RequestBecomeAnAgencyModal',
  mixins: [DefaultFocus],

  data() {
    return {
      loading: false,
      phoneNumberWithCode: '',
      formAgency: {
        agentType: 'agency',
        country: '',
        phoneNumber: '',
        shortName: '',
        name: '',
        address: '',
        taxCode: '',
        email: '',
        accept: false
      }
    }
  },

  computed: {
    rules() {
      return {
        phoneNumber: { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.phoneNumber') }), trigger: 'change' },
        name: { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.name') }), trigger: 'change' },
        shortName: { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.name') }), trigger: 'change' },
        email: [
          { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.email') }), trigger: 'change' },
          { type: 'email', message: this.$t('notification.error.form_is_email', { field: this.$t('field.email') }), trigger: 'change' },
        ],
        taxCode: { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.taxCode') }), trigger: 'change' },
        address: { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.address') }), trigger: 'change' },
        accept: [
          { required: true, type: 'boolean', message: this.$t('notification.error.form_is_required', { field: this.$t('field.accept') }), trigger: 'change' },
          { validator: (_rule, value, callback) => {
            if(!value) {
              callback(new Error(this.$t('notification.error.form_is_accepted', { field: this.$t('field.accept') })))
            } else callback()
          }, trigger: 'change' },
        ]
      }
    },
    strategies: () => [
      { key: 'google', name: 'google', src: '/socials/google.svg' },
      { key: 'facebook', name: 'facebook', src: '/socials/facebook.svg' },
      { key: 'zalo', name: 'zalo', src: '/socials/zalo.svg' },
      { key: 'wallet', name: 'wallet', src: '/wallets/wallet.svg' },
    ]
  },
  methods: {
    async submitForm(formName) {
      const isValid = await this.$refs[formName].validate()
      if (!isValid) {
        return false
      }

      this.loading = true
      this.$api.agent.requestBecomeAnAgency(omit(this.formAgency, ['country']))
        .then(({ data }) => {
          this.$notify.success({
            title: this.$t('modal.request_to_become_an_agency.title'),
            message: this.$t('notification.request_to_become_an_agency_successfully')
          })
          this.close(data)
        })
        .catch((error) => {
          this.$notify.error({
            title: this.$t('modal.request_to_become_an_agency.title'),
            message: this.$t(`${error.response.data.message}`)
          })
        })
        .finally(() => {
          this.loading = false
        })
    },

    updateCountryCode (code) {
      this.formAgency.country = code
    },

    updatePhoneNumberWithCode (phoneNumberWithCode) {
      this.phoneNumberWithCode = phoneNumberWithCode
    },

    close(data) {
      data ? this.$emit('done', data) : this.$emit('error', new Error('Cancel request become an agency'))
      this.$emit('close')
    },
  }
}
</script>

<style lang="scss" scoped>
::v-deep.request-to-become-an-agency-modal {
  .el-dialog {
    background-image: url(~@/assets/images/login-background.png);
    background-repeat: round;
      margin-top: 0!important;
    @include media(mobile) {
      margin-top: 0!important;
      margin-bottom: 0;
      height: 100%;
      overflow: auto;
    }
    &__header {
      // padding-top: 42px;
      // text-align: center;
      .el-dialog__title {
        font-size: 24px;
        color: $--color-text-primary;
      }
    }
    &__body {
      .el-form-item {
        margin-bottom: 18px;
        &__label {
          line-height: 32px;
          padding-bottom: 0;
          color: $--color-text-primary;
        }
        .form-item-phonenumber {
          &.is-error {
            .vue-phone-number-input {
              border-color: #ff4646;

              .input-tel__input {
                &:focus {
                  border-color: transparent !important;
                }
              }

              .country-selector.has-value {
                .country-selector__input {
                  &:focus {
                    border-color: #212240 !important;
                  }
                }
              }
            }
          }
        }
        &.accept {
          margin-top: 24px;
          .el-form-item__content {
            line-height: 30px;
          }
        }
      }
    }
    .trouble {
      margin-top: 25px;
      margin-bottom: 10px;
      .el-form-item__content {
        line-height: 10px;
      }
      a {
        color: var(--color-primary);
        font-size: $--size-base-xs;
        text-decoration: none;
      }
    }
    .social-login-divider {
    }
    .social {
      padding: 4px 12px;
      margin: 4px auto;
      strong {
        vertical-align: super;
      }
    }
    .sign-up {
      text-align: center;
      padding-top: 15px;
      font-size: $--size-base-xs;
      a {
        color: $--color-primary;
        text-decoration: none;
      }
    }
    .btn-login {
      font-weight: bold;
    }
  }
}
// @media only screen and (max-width: 768px) {
//   .authentication-modal {
//     .el-dialog {
//       width: calc(100% - 10px) !important;
//       max-width: 475px;
//       min-width: 300px;
//       .el-dialog__header {
//         padding-top: 30px;
//         padding-bottom: 15px;
//         .el-dialog__title {
//           font-size: 18px;
//         }
//       }
//       .el-dialog__body {
//         padding: 20px 15px;
//         margin-left: 0;
//         margin-right: 0;
//       }
//     }
//   }
// }
</style>
