<template lang="pug">
el-dialog.medias-modal.fw.lock-scroll(
  :visible="visible"
  center
  lock-scroll
  @close="closeModal"
  :close-on-click-modal="false"
)

  .item(v-if="item" :key="index")
    el-image(
      v-if="item.type === MEDIA_TYPES.IMAGE"
      :src="item.url"
      @click="next"
    )
      .image-slot(slot="placeholder")
        i.el-icon-loading
      .image-slot(slot="error")
        i.el-icon-picture-outline
        span {{ $t('common.image_not_found') }}

    video.video(
      ref="videoMedia"
      :id="`video-media-${item.id}`"
      v-else
      autoplay
      loop
      preload
      muted
      playsinline
      @click="next"
    )
      source(:src="item.url")
  template(v-if="medias.length > 1" slot="footer")
    .navigation
      el-button.button.el-button--highlight.previous(size="small" type="info" @click="previous")
        chevron-left-icon(size="1x")
      .index
        span.current {{ current + 1 }}
        span.divider /
        span.size {{ medias.length }}
      el-button.button.el-button--highlight.next(size="small" type="info" @click="next")
        chevron-right-icon(size="1x")
</template>

<script>
import {
  ChevronLeftIcon,
  ChevronRightIcon
} from 'vue-feather-icons'
import { MEDIA_TYPES } from '~/utilities/constants'

export default {
  components: {
    ChevronLeftIcon,
    ChevronRightIcon
  },

  props: {
    medias: {
      type: Array,
      default: () => []
    },

    index: {
      type: Number,
      default: 0
    },

    loop: {
      type: Boolean,
      default: true
    }
  },

  data () {
    return {
      current: 0,
      visible: true,
      MEDIA_TYPES
    }
  },

  computed: {
    item () {
      const item = this.medias[this.current]
      return item || null
    }
  },

  watch: {
    index: {
      immediate: true,
      handler (val) {
        this.current = val
      }
    }
  },

  mounted () {
    document.addEventListener('keydown', this.handleKeys)
    if (this.autoClose > 0) {
      setTimeout(() => {
        this.$emit('close')
      }, this.autoClose)
    }
  },

  beforeDestroy () {
    document.removeEventListener('keydown', this.handleKeys)
  },

  methods: {
    handleKeys (e) {
      switch (e.code) {
        case 'ArrowLeft': return this.previous()
        case 'ArrowRight': return this.next()
      }
    },

    closeModal () {
      this.$emit('close')
    },

    previous () {
      this.navigate(this.current - 1)
    },

    next () {
      this.navigate(this.current + 1)
      this.$nextTick(() => {
        if (this.item.type === MEDIA_TYPES.VIDEO) {
          this.$refs.videoMedia.load()
          this.$refs.videoMedia.play()
        }
      })
    },

    navigate (val) {
      let index = val
      if (this.loop) {
        if (index < 0) index = this.medias.length - 1
        if (index >= this.medias.length) index = 0
      } else {
        if (index >= this.medias.length) index = this.medias.length - 1
        if (index < 0) index = 0
      }
      this.current = index
    }
  }
}
</script>

<style lang="scss" scoped>
::v-deep.medias-modal {
  .el-dialog {
    margin-top: 0!important;
    width: fit-content;
    min-width: 0;
    max-width: 92%;
    background-color: transparent;
    height: 100vh;
    position: relative;
    display: flex;
    flex-direction: column;
    justify-content: center;
    box-shadow: none;
    &__header {
      position: inherit;
      padding: 0;
      &btn {
        width: 28px;
        height: 28px;
        background-color: var(--color-bg-header);
        top: 10px;
        right: 10px;
        font-size: 24px;
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 1;
      }
    }
    &__body {
      overflow: hidden;
      border-radius: 6px;
      font-size: 0;
      padding: 0;
    }
    &__footer {
      padding: 0;
      padding-top: 20px;
    }
  }
}
.item {
  max-width: 960px;
  .el-image {
    width: 100%;
    min-height: 100px;
    .image-slot {
      display: flex;
      flex-direction: column;
      justify-content: flex-end;
      align-items: center;
      width: 100%;
      height: revert;
      color: var(--color-shade-1);
      min-height: 100px;
      i {
        font-size: 38px;
      }
      span {
        font-size: $--size-base;
      }
    }
  }
  img {
    max-height: 90vh;
    max-width: 100%;
    cursor: pointer;
  }

  .video {
    width: 100%;
  }
}
.navigation {
  display: flex;
  justify-content: center;
  align-items: center;
  .button {
    font-size: 18px;
    color: $--color-text-primary;
    padding: 6px 8px;
  }
  .index {
    font-size: $--size-base-xs;
    padding: 0 2em;
    color: $--color-text-primary;
    // .current, .size {
    //   min-width: 10px;
    // }
    .divider {
      padding: 0 1em;
      color: rgba($--color-text-primary, .5);
    }
  }
}
</style>
