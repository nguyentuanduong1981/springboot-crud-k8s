<template lang="pug">
el-dialog.authentication-modal.small(
  visible
  @close="close"
  :title="`${$t('modal.authentication.title')}`"
  :width="'534px'"
)
  el-form(
    ref="formLogin"
    :model="credentials"
    :rules="rules"
    @submit.prevent.native="() => ({})"
    label-position="top"
  )
    el-form-item.form-item-phonenumber(
      prop="phoneNumber"
    )
      input-phone-number(
        v-model="credentials.phoneNumber"
        ref="defaultFocus"
        :placeholder="$t('field.phoneNumber')"
        @updateCountryCode="updateCountryCode"
        @updatePhoneNumberWithCode="updatePhoneNumberWithCode"
      )

    el-form-item(
      prop="password"
    )
      el-input(
        prop-type="password"
        show-password
        v-model="credentials.password"
        @keyup.enter.native="submitForm()"
        :placeholder="$t('field.password')"
      )
    el-form-item.trouble
      nuxt-link(to="/") {{ $t('modal.authentication.trouble_logging_in') }}
    el-form-item
      el-button.fw.btn-login(
        type="primary"
        size="small"
        :loading="loading"
        @click.native.prevent="submitForm()"
      ) {{ $t('modal.authentication.log_in') }}
  .text-center.mb-16.login-with {{ $t('modal.authentication.continue_with') }}
  .text-center
    span.social-provider(
      size="small"
      :span="24"
      :key="s.key"
      v-for="s in strategies"
      @click="onClickOtherLogin(s.key)"
    )
      nuxt-img.btn-social(
        :src="s.src"
        width="24"
        :alt="`${$t('modal.authentication.continue_with')} ${s.name}`"
        :title="`${$t('modal.authentication.continue_with')} ${s.name}`"
      )
    .clearfix
    el-button.mt-8.wallet-provider(
      size="small"
      :span="24"
      round
      @click.native="onClickOtherLogin('wallet')"
    )
      //- nuxt-img.btn-wallet(
      //-   src="/wallets/wallet.svg"
      //-   width="24"
      //-   :alt="$t('modal.authentication.continue_with', { strategy : $t(`modal.authentication.wallet`) })"
      //-   :title="$t('modal.authentication.continue_with', { strategy : $t(`modal.authentication.wallet`) })"
      //- )
      span.ml-4 {{ $t('modal.authentication.continue_with') }} {{ $t(`modal.authentication.wallet`) }}
  div.sign-up {{ $t('modal.authentication.new_account') }}?
    nuxt-link(to="/" @click.stop.native="onClickSignup")  {{ $t('modal.authentication.sign_up') }}
</template>

<script>
import DefaultFocus from '~/mixins/default-focus'

export default {
  name: 'AuthenticationModal',
  mixins: [DefaultFocus],

  data() {
    return {
      loading: false,
      phoneNumberWithCode: '',
      credentials: {
        country: '',
        phoneNumber: '',
        password: ''
      }
    }
  },

  computed: {
    rules() {
      return {
        phoneNumber: { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.phoneNumber') }), trigger: 'change' },
        password: { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.password') }), trigger: 'change' }
      }
    },
    strategies: () => [
      { key: 'google', name: 'google', src: '/socials/google.svg' },
      { key: 'facebook', name: 'facebook', src: '/socials/facebook.svg' },
      // { key: 'zalo', name: 'zalo', src: '/socials/zalo.svg' },
    ]
  },
  methods: {
    submitForm() {
      this.$refs.formLogin.validate((valid) => {
        if (!valid) return false

        this.loading = true
        this.$auth.loginWith('local', {
          data: {
            password: this.credentials.password,
            phoneNumber: this.phoneNumberWithCode
          }
        })
          .then(() => {
            // this.$notify.success({
            //   title: this.$t('modal.authentication.title'),
            //   message: this.$t('server_error.account.account_does_not_exist')
            // })
            this.close({})
          })
          .catch((error) => {
            this.$notify.error({
              // title: this.$t('modal.authentication.title'),
              message: this.$t(error.response.data.message)
            })
          })
          .finally(() => {
            this.loading = false
          })
      })
    },

    onClickOtherLogin (key) {
      switch(key) {
        case 'google':
        case 'facebook':
        case 'zalo':
          this.$auth.loginWith(key)
            .then((res) => {
              console.log(res)
            })
            .catch(error => {
              this.$notify.error({
                message: this.$t(`${error.message || error.error_description || ''}`),
              })
            })
          break;
        case 'wallet': {
          this.$flows.loginWallet({
            parent: this
          })
            .then((res) => {
              this.close({})
            })
          break;
        }
      }
    },

    onClickSignup () {
      this.$emit('close')
      this.$flows.register({
        parent: this
      })
    },

    updateCountryCode (code) {
      this.credentials.country = code
    },

    updatePhoneNumberWithCode (phoneNumberWithCode) {
      this.phoneNumberWithCode = phoneNumberWithCode
    },

    close(data) {
      data ? this.$emit('done', data) : this.$emit('error', new Error('Authentication with Wallet cancelled'))
      this.$emit('close')
    },
  }
}
</script>

<style lang="scss" scoped>
::v-deep.authentication-modal {
  .el-dialog {
    &__header {
      // padding-top: 42px;
      // text-align: center;
      .el-dialog__title {
        font-size: 24px;
        color: var(--color-shade-6);
      }
    }
    &__body {
      .el-form-item {
        margin-bottom: 28px;
        &__label {
          line-height: 32px;
          padding-bottom: 0;
          color: var(--color-shade-6);
        }
        .el-input__inner {
          // height: 48px;
        }
        .form-item-phonenumber {
          &.is-error {
            .vue-phone-number-input {
              border-color: #ff4646;

              .input-tel__input {
                &:focus {
                  border-color: transparent !important;
                }
              }

              .country-selector.has-value {
                .country-selector__input {
                  &:focus {
                    border-color: #212240 !important;
                  }
                }
              }
            }
          }
        }
      }
    }
    .trouble {
      margin-top: 25px;
      margin-bottom: 10px;
      .el-form-item__content {
        line-height: 10px;
      }
      a {
        color: var(--color-primary-5);
        font-size: $--size-base-sm;
        text-decoration: none;
      }
    }
    .social-login-divider {
    }
    .social-provider {
      padding: 4px 12px;
      margin: 6px auto;
      font-size: 13px;
      .btn-social {
        cursor: pointer;
      }
      span {
        vertical-align: super;
      }
    }
    .wallet-provider {
      > span {
        display: flex;
        align-items: center;
      }
    }
    .login-with {
      color: var(--color-shade-6);
    }
    .sign-up {
      text-align: center;
      padding-top: 15px;
      font-size: $--size-base-sm;
      color: var(--color-shade-4);
      a {
        color: $--color-primary;
        text-decoration: none;
      }
    }
    .btn-login {
      text-transform: uppercase;
      font-size: 15px;
      font-weight: bold;
    }
  }
}
// @media only screen and (max-width: 768px) {
//   .authentication-modal {
//     .el-dialog {
//       width: calc(100% - 10px) !important;
//       max-width: 475px;
//       min-width: 300px;
//       .el-dialog__header {
//         padding-top: 30px;
//         padding-bottom: 15px;
//         .el-dialog__title {
//           font-size: 18px;
//         }
//       }
//       .el-dialog__body {
//         padding: 20px 15px;
//         margin-left: 0;
//         margin-right: 0;
//       }
//     }
//   }
// }
</style>