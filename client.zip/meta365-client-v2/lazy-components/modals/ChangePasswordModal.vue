<template lang="pug">
el-dialog.registration-modal.small(
  visible
  @close="close"
  :title="`${$t('modal.change_password.title')}`"
  :width="'486px'"
)
  el-form(
    ref="passwordFormRef"
    :model="passwordForm"
    :rules="rules"
    label-position="top"
  )
    el-form-item(
      prop="oldPassword"
      :error="errors.oldPassword"
    )
      el-input(
        prop-type="oldPassword"
        show-password
        v-model="passwordForm.oldPassword"
        :placeholder="$t('field.oldPassword')"
      )

    el-form-item(
      prop="newPassword"
      :error="errors.newPassword"
    )
      el-input(
        prop-type="password"
        show-password
        v-model="passwordForm.newPassword"
        :placeholder="$t('field.newPassword')"
      )

    el-form-item(
      prop="confirmPassword"
    )
      el-input(
        prop-type="password"
        show-password
        v-model="passwordForm.confirmPassword"
        :placeholder="$t('field.confirmPassword')"
        @keyup.enter.native="submitForm()"
      )
  span.dialog-footer(slot='footer')
    el-button(
      size="small"
      @click="close()"
    ) {{ $t('common.cancel') }}
    el-button(
      :loading="loading"
      size="small"
      type="primary"
      @click="submitForm()"
    ) {{ $t('common.change') }}
</template>

<script>
import DefaultFocus from '~/mixins/default-focus'

export default {
  name: 'ChangePasswordModal',
  mixins: [DefaultFocus],

  data() {
    return {
      loading: false,
      passwordForm: {
        oldPassword: '',
        newPassword: '',
        confirmPassword: ''
      },
      errors: {}
    }
  },

  computed: {
    rules() {
      const validateConfirmPassword = (_rule, value, callback) => {
        if (value !== this.passwordForm.newPassword) {
          callback(new Error(this.$t('notification.error.form_is_confirmed', { field: this.$t('field.confirmPassword'), confirmField: this.$t('field.newPassword') })))
        } else callback()
      }
      const validateStrongPassword = (_rule, value, callback) => {
        if(!(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d]{8,}$/.test(value))) {
          callback(new Error(this.$t('notification.error.form_is_strength_password')))
        } else callback()
      }
      return {
        oldPassword: [
          { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.oldPassword') }), trigger: 'change' },
        ],
        newPassword: [
          { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.newPassword') }), trigger: 'change' },
          { validator: validateStrongPassword, trigger: 'change' }
        ],
        confirmPassword: [
          { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.confirmPassword') }), trigger: 'change' },
          { validator: validateConfirmPassword, trigger: 'change' }
        ]
      }
    }
  },
  methods: {
    clearError () {
      this.errors = {}
      this.$nextTick(() => {
        this.$refs.passwordFormRef.clearValidate()
      })
    },

    submitForm() {
      this.$refs.passwordFormRef.validate((valid) => {
        if (!valid) return false
        this.clearError()
        this.loading = true
        this.$api.user.changePassword({
          oldPassword: this.passwordForm.oldPassword,
          newPassword: this.passwordForm.newPassword,
        })
          .then(() => {
            this.$notify.success({
              // title: this.$t('modal.registration.title'),
              message: this.$t('notification.changed_password_successfully'),
            })
            this.close({})
          })
          .catch((error) => {
            const response = error.response
            if(response.status === 422) {
              this.errors = response.data.message.reduce((errors, errorField) => {
                errors[errorField.field] = this.$t(errorField.message)
                return errors
              }, {})
              return this.$notify.error({
                message: this.$t('notification.error.invalid_information_input'),
              })
            }
            this.$notify.error({
              // title: this.$t('modal.registration.title'),
              message: this.$t(error.response.data.message) || this.$t('notification.error.changed_password_failed'),
            })
          })
          .finally(() => {
            this.loading = false
          })

      })
    },

    close(data) {
      data ? this.$emit('done', data) : this.$emit('error', new Error('Registration cancelled'))
      this.$emit('close')
    }
  }
}
</script>

<style lang="scss" scoped>
::v-deep.registration-modal {
  .el-dialog {
    &__header {
      // padding-top: 42px;
      // text-align: center;
      .el-dialog__title {
        font-size: 24px;
        color: var(--color-shade-6);
      }
    }
    &__body {
      padding-bottom: 0;
      .el-form-item {
        margin-bottom: 30px;
        &__label {
          line-height: 32px;
          padding-bottom: 0;
          color: var(--color-shade-6);
        }
      }
    }
    .trouble {
      margin-top: 25px;
      margin-bottom: 10px;
      .el-form-item__content {
        line-height: 10px;
      }
      a {
        color: var(--color-primary);
        font-size: $--size-base-xs;
        text-decoration: none;
      }
    }
  }
}
</style>
