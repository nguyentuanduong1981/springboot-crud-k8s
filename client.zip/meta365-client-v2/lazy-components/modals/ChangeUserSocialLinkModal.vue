<template lang="pug">
el-dialog.change-user-social-link.small(
  visible
  :close-on-press-escape="false"
  :close-on-click-modal="false"
  @close="close"
  :title="`${title}`"
  :width="'457px'"
)
  el-form(
    :model="socialForm"
    :rules="rules"
    ref="socialForm"
    :validate-on-rule-change="false"
  )
    el-form-item(
      prop="value"
    )
      el-input(
        :placeholder="$t('pages.profile.your_link', { type })"
        v-model.trim="socialForm.value"
        @keyup.enter.native="handleAddSocialLink()"
      )
        el-select.select-social-link(
          v-model="type"
          placeholder=""
          slot="prepend"
          popper-class="social-list-dropdown mini"
        )
          template.d-flex(v-if="type" #prefix)
            img(
              :src="`/socials/${type}.svg`"
              width="20"
            )
          el-option(
            v-for="i in accepts"
            :value="i"
            :key="i"
            :label="i"
          )
            .flex-center-y
              img(
                :src="`/socials/${i}.svg`"
                width="20"
              )
        el-button(
          slot="append"
          icon="el-icon-plus"
          @click.native="handleAddSocialLink()"
        )
  .social.mt-20.d-block
    el-tag.social__item(
      v-for="i in socialLinks"
      :key="i.key"
      closable
      :effect="$colorMode.value === 'dark' ? 'dark' : 'light'"
      type="success"
      @close="handleRemoveSocialLink(i)"
    )
      .wrap
        .link
          .wrap-img
            img(
              :src="`/socials/${i.key}.svg`"
              width="20"
            )
          a.c-text-ellipsis-0(
            :href="i.value"
            target="_blank"
          ) {{ i.value }}
        //- .edit
        //-   Edit2Icon(
        //-     size="16"
        //-   )

  .action.mt-20
    el-button.fw(
      :disabled="!isChange"
      type="primary"
      @click.native="onClickSaveSocialLink()"
    ) {{ $t('common.save') }}
</template>

<script>
import { cloneDeep, sortBy } from 'lodash'
import { Edit2Icon } from 'vue-feather-icons'

export default {
  name: 'ChangeUserSocialLinkModal',

  components: {
    Edit2Icon,
    QrCodeGenerator: () => import('@/lazy-components/QrCodeGenerator')
  },

  props: {
    socials: {
      type: Array,
      default: () => ([])
    }
  },

  data () {
    return {
      title: this.$t('modal.change_social_link.title'),
      type: '',
      socialForm: {
        value: '',
      },
      error: null,
      loading: false,
      socialLinks: [],
      defaultAccepts: ['website', 'facebook', 'zalo', 'twitter', 'medium', 'linkedin', 'telegram']
    }
  },

  computed: {
    accepts () {
      const exclude = this.socialLinks.map(item => item.key)
      return this.defaultAccepts.filter(n => !exclude.includes(n))
    },

    rules() {
      return {
        value: [
          { required: true, message: this.$t('notification.error.form_is_required', { field: this.$t('field.link') }), trigger: 'change' },
          {
            validator: (_rule, value, callback) => {
              if (/^(https:\/\/)[\w.-]+(?:\.[\w.-]+)+[\w\-._~:/?#[\]@!$&'()*+,;=.]+$/.test(value)) {
                return callback()
              }
              return callback(new Error(this.$t('notification.error.form_is_url', { field: this.$t('field.link') })))
            },
            trigger: ['blur', 'change']
          },
          {
            validator: (_rule, value, callback) => {
              if (this.socialLinks.filter(link => link.value === value).length) {
                return callback(new Error(this.$t('notification.error.form_is_unique', { field: this.$t('field.link') })))
              }
              return callback()
            },
            trigger: ['blur', 'change']
          },
        ],
      }
    },

    isChange () {
      return JSON.stringify(sortBy(this.socials, ['key'])) !== JSON.stringify(sortBy(this.socialLinks, ['key']))
    }
  },

  created () {
    this.socialLinks = cloneDeep(this.socials)
  },

  methods: {
    close(data) {
      data && this.$emit('done', data)
      this.$emit('close')
    },

    handleAddSocialLink () {
      if (!this.type || !this.defaultAccepts.includes(this.type)) return
      const form = this.$refs.socialForm
      form.validate((valid) => {
        if (!valid) return false
        this.socialLinks.push({
          key: cloneDeep(this.type),
          value: cloneDeep(this.socialForm.value)
        })
        this.type = ''
        form.resetFields()
        form.clearValidate()
      })
    },

    handleRemoveSocialLink (tag) {
      this.socialLinks.splice(this.socialLinks.indexOf(tag), 1)
    },

    onClickSaveSocialLink () {
      this.loading = true
      this.$api.user.updateSocialLink(this.socialLinks)
        .then(({ data }) => {
          this.$notify.success({
            // title: this.$t('modal.change_social_link.title'),
            message: this.$t(!this.socialLinks.length ? 'notification.deleted_social_link_successfully' : 'notification.changed_social_link_successfully'),
          })
          this.close({ data })
        })
        .catch((error) => {
          this.$notify.error({
            // title: this.$t('modal.change_social_link.title'),
            message: error.response.data.message || this.$t('notification.error.change_social_link_failed'),
          })
        })
        .finally(() => {
          this.loading = false
        })
    }
  },
}
</script>

<style lang="scss" scoped>
::v-deep.change-user-social-link {
  .el-dialog {
    &__header {
      // padding-top: 42px;
      // text-align: center;
      .el-dialog__title {
        font-size: 24px;
        color: var(--color-shade-6);
      }
    }
    &__body {
      .el-input-group {
        &__prepend {
          width: 10px;
          padding: 0 16px;
          height: 38px;
          .select-social-link {
            .el-input {
              &__prefix {
                left: 10px;
                display: flex;
                align-items: center;
              }
              &__inner {
                visibility: hidden;
              }
            }
          }
        }
        &__append {
          .el-button {
            padding: 10px 18px;
          }
        }
      }
      .el-input--error {
        margin-top: 2px;
        font-size: 13px;
        color: $--color-danger;
      }
      .social {
        &__item {
          display: flex;
          // color: var(--color-shade-0) !important;
          width: 100%;
          height: 36px;
          justify-content: space-between;
          align-items: center;
          margin: 4px 0;
          padding: 2px 10px;
          &:hover {
            .edit {
              display: flex;
              align-items: center;
            }
          }
          .wrap {
            padding-right: 4px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: calc(100% - 20px);
          }
          .link {
            width: calc(100% - 26px);
            display: flex;
            align-items: center;
          }
          .edit {
            display: none;
          }
          a {
            font-size: 13px;
          }
          .el-icon-close {
            top: 0;
            font-size: 16px;
          }
          .wrap-img {
            display: flex;
            align-items: center;
            width: 24px;
            margin-right: 4px;
          }
        }
      }
    }
  }
}
</style>

<style lang="scss">
.social-list-dropdown {
  &.mini {
    width: 50px;
  }
  .el-select-dropdown__item {
    padding: 0 10px;
    display: flex;
    align-items: center;
    &:hover, &:focus {
      background-color: $--color-warning!important;
    }
    &.selected {
      background-color: $--color-warning!important;
    }
  }
}
</style>
