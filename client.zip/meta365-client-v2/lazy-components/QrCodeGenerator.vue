<template lang="pug">
  #qr.text-center
    slot(
      name="header"
      v-if="$slots.header"
    )
    template(v-else)
      .flex-center-y.copy-component(
        v-if="config.value"
        :class="{ copied }"
        v-clipboard:copy="config.value"
        v-clipboard:success="clipboardSuccess"
      )
        p.copy-component__text.c-text-ellipsis-0 {{ config.value }}
        CopyIcon(size="22")
    vue-qr(
      logo-src="/logo.png"
      :dot-scale="0.48"
      logo-background-color="#263c6bcc"
      :bg-src="config.imagePath"
      :logo-margin="8"
      background-color="#263c6bcc"
      :logo-scale="0.12"
      :margin="16"
      background-dimming="#263c6bbc"
      :text="config.value"
      :size="size"
      :components="configComponents"
      :callback="qrCodeGenerated"
    )
    a(
      @click="onClickDownloadQrCode"
    )
      slot(v-if="$slots.default")
      p(v-else) {{ $t('common.download') }}

</template>

<script>
import { CopyIcon } from 'vue-feather-icons'

export default {
  name: 'QrCodeGenerator',

  components: {
    CopyIcon
  },

  props: {
    qr: {
      type: Object,
      default: () => ({

      })
    },

    autoGenerateQR: {
      type: Boolean,
      default: false
    },

    download: {
      type: Object,
      default: () => {
        return {
          visible: false
        }
      }
    }
  },

  data () {
    return {
      qrImage: null,
      size: 300,
      copied: false,
      configComponents: {
        data: {
          scale: 1,
        },
        timing: {
          scale: 0.5,
          protectors: false,
        },
        alignment: {
          scale: 0.48,
          protectors: false,
        },
        cornerAlignment: {
          scale: 0.48,
          protectors: true,
        },
      }
    }
  },

  computed: {
    config () {
      return {
        size: this.size,
        ...this.qr
      }
    }
  },

  mounted () {
    const qr = document.getElementById('qr')
    if (qr) {
      this.size = qr.offsetWidth - 20
    }
  },

  methods: {
    qrCodeGenerated (data) {
      this.qrImage = data
    },

    onClickDownloadQrCode (e) {
      if (e.target.tagName !== 'A') {
        e = e.target.closest('a')
      }
      const { filename = 'download.png' } = this.download
      e.href = this.qrImage
      e.download = filename
    },

    clipboardSuccess () {
      this.copied = true
      this.$message({
        type: 'success',
        message: this.$t('common.copied')
      })
      setTimeout(() => {
        this.copied = false
      }, 1000)
    },
  },
}
</script>

<style lang="scss" scoped>
#qr {
  img {
    width: 100%;
  }
  a {
    margin-top: 10px;
    display: inline-block;
  }
}
</style>
