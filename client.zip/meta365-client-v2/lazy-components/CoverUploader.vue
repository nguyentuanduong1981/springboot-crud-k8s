<template lang="pug">
.cropper()
  cropper.cropper__image(
    :key="key"
    ref="cropper"
    :default-position="defaultPosition"
    :default-boundaries="boundaries"
    :stencil-props="stencilProps"
    v-bind="$attrs"
    @change="updateSize"
    @ready="ready"
    @error="error"
  )
  .cropper__button.flex-column
    .zoom.flex-column
      ZoomInIcon(
        size="18"
        @click.stop="zoom(1.5)"
      )
      ZoomOutIcon(
        size="18"
        @click.stop="zoom(0.75)"
      )
    .direction
      ArrowUpIcon(
        size="18"
        @click.stop="move('top')"
      )
      ArrowDownIcon(
        size="18"
        @click.stop="move('bottom')"
      )
      ArrowRightIcon(
        size="18"
        @click.stop="move('right')"
      )
      ArrowLeftIcon(
        size="18"
        @click.stop="move('left')"
      )
</template>

<script>
import { Cropper } from 'vue-advanced-cropper'
import 'vue-advanced-cropper/dist/style.css'
import { ArrowUpIcon, ArrowDownIcon, ArrowLeftIcon, ArrowRightIcon, ZoomInIcon, ZoomOutIcon } from 'vue-feather-icons'

export default {
  components: {
    Cropper,
    ZoomInIcon,
    ArrowUpIcon,
    ZoomOutIcon,
    ArrowDownIcon,
    ArrowLeftIcon,
    ArrowRightIcon,
  },

  props: {
    loading: {
      type: Boolean,
      default: false
    }
  },

  data() {
    return {
      size: {
        width: null,
        height: null,
      },
      currentType: 'image/png',
      position: {
        top: 0,
        left: 0
      },
      key: 0
    }
  },

  computed: {
    stencilProps () {
      return {
        handlers: {},
        movable: false,
        resizable: false,
      }
    },
  },

  methods: {
    boundaries({ cropper }) {
      return {
        width: cropper.clientWidth,
        height: cropper.clientHeight,
      }
    },

    defaultPosition() {
      return {
        left: 0,
        top: 0,
      }
    },

    defaultSize({ imageSize, visibleArea }) {
      return {
        width: (visibleArea || imageSize).width - 50,
        height: (visibleArea || imageSize).height - 100,
      }
    },

    updateSize({ coordinates, image, visibleArea, canvas }) {
      this.size.width = Math.round(coordinates.width)
      this.size.height = Math.round(coordinates.height)
      this.position.top = Math.round(coordinates.top)
      this.position.left = Math.round(coordinates.left)
    },

    zoom(factor) {
      this.$refs.cropper.zoom(factor)
    },

    error() {},

    ready() {
      this.$emit('loaded')
    },

    onCrop () {
      const { canvas } = this.$refs.cropper.getResult()
      if (canvas) {
        const type = this.currentType.split('/').slice(-1)[0]
        canvas.toBlob(blob => {
          const cover = new File([blob], `cover.${type}`, { lastModified: new Date().getTime(), type: this.currentType })
          this.$emit('cropped', cover)
        }, type)
      }
    },

    move(direction) {
      if (direction === 'left') {
        this.$refs.cropper.move(-this.size.width / 4)
      } else if (direction === 'right') {
        this.$refs.cropper.move(this.size.width / 4)
      } else if (direction === 'top') {
        this.$refs.cropper.move(0, -this.size.height / 8)
      } else if (direction === 'bottom') {
        this.$refs.cropper.move(0, this.size.height / 8)
      }
    },
  },
}
</script>

<style lang="scss" scoped>
::v-deep.cropper {
  position: relative;
  min-height: 120px;
  &__image {
    transition: all 0.3s;
    .vue-rectangle-stencil {
      cursor: all-scroll;
      transform: inherit !important;
    }
  }
  &__button {
    position: absolute;
    right: 10px;
    top: 30px;
    border-radius: $--radius-medium;
    background: var(--color-bg-header);
    padding: 4px;
    @include media(xs) {
      top: 8px;
      left: 10px;
      right: initial;
    }
    .direction, .zoom {
      position: relative;
      .feather {
        color: var(-text-color);
      }
    }
    .zoom {
      align-items: center;
      height: 54px;
      .feather {
        margin: 2px 0;
      }
    }
    .direction {
      width: 64px;
      height: 64px;
      .feather {
        position: absolute;
      }
      .feather-arrow-up {
        top: 0;
        left: calc(50% - 9px);
      }
      .feather-arrow-down {
        bottom: 0;
        left: calc(50% - 9px);
      }
      .feather-arrow-right {
        top: calc(50% - 9px);
        right: 0;
      }
      .feather-arrow-left {
        top: calc(50% - 9px);
        left: 0;
      }
    }
  }
}
</style>
