<template lang="pug">
el-dropdown(trigger="click")
  slot(name="reference")
  el-dropdown-menu.social-share-dropdown(
    v-if="zalo"
    slot='dropdown'
  )
    client-only
      el-dropdown-item(
        data-hover="#ffffff"
      )
        .custom-share
          .zalo-share-button(
            :data-href="sharing.url"
            data-oaid="579745863508352884"
            data-layout="icon-text"
            data-color="blue"
            :data-customize="true"
          )
            .flex-start-x.el-link.el-link--primary
              img.mr-4(
                width="24"
                src="/socials/zalo.svg"
              )
              span {{ $t('pages.profile.share_to') }} Zalo
    el-dropdown-item(
      v-for="network in networks"
      :key="network.network"
      :data-hover="network.color"
    )
      share-network(
        :style="{ 'text-decoration': 'none' }"
        :network="network.network"
        :url="sharing.url"
        :title="sharing.title"
        :description="sharing.description"
        :quote="sharing.quote"
        :hashtags="sharing.hashtags"
        :twitter-user="sharing.twitterUser"
        @close="closeSharePopup"
      )
        .flex-start-x.el-link.el-link--primary
          img.mr-4(
            width="24"
            :src="`/socials/${network.icon}`"
          )
          span {{ $t('pages.profile.share_to') }} {{ network.name }}
</template>

<script>
const NETWORKS = [
  { network: 'email', name: 'Email', icon: 'gmail.svg', color: '#333333' },
  { network: 'facebook', name: 'Facebook', icon: 'facebook.svg', color: '#1877f2' },
  { network: 'linkedin', name: 'LinkedIn', icon: 'linkedin.svg', color: '#007bb5' },
  { network: 'messenger', name: 'Messenger', icon: 'messenger.svg', color: '#0084ff' },
  { network: 'sms', name: 'SMS', icon: 'sms.svg', color: '#333333' },
  { network: 'telegram', name: 'Telegram', icon: 'telegram.svg', color: '#0088cc' },
  { network: 'twitter', name: 'Twitter', icon: 'twitter.svg', color: '#1da1f2' },
]
export default {
  name: 'DropDownNetworkSharing',

  props: {
    networks: {
      type: Array,
      default: () => (NETWORKS)
    },

    zalo: {
      type: Boolean,
      default: true
    },

    sharing: {
      type: Object,
      default: () => ({})
    }
  },

  // mounted () {
  //   const script = document.createElement('script')
  //   script.setAttribute('type', 'text/javascript')
  //   script.setAttribute('src', 'https://sp.zalo.me/plugins/sdk.js')
  //   document.body.appendChild(script)
  // },

  // destroyed() {
  //   const script = document.getElementsByTagName('script')
  //   console.log(script)
  // },

  methods: {
    closeSharePopup(network) {
    },
  }
}
</script>

<style lang="scss" scoped>

</style>
