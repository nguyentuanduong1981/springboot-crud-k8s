import Vue from 'vue'
import { has } from 'lodash'
import MediasModal from '~/lazy-components/modals/MediasModal'
// import MediaPreviewModal from '~/components/modals/MediaPreviewModal'

export default ({ app, store, router }, inject) => {
  const Dialogs = {
    get container () {
      const container = document.getElementById('global-dialogs')
      return container || document.body
    },

    open ({ parent, component, props = {}, events = {} } = {}) {
      return new Promise((resolve, reject) => {
        const InstanceClass = Vue.extend(component)
        let instance = new InstanceClass({
          store,
          router,
          propsData: props,
          parent,
          filters: parent.$options.filters
        })

        if (this.existInstance(instance, component)) {
          return resolve(true)
        }

        instance.$on('done', resolve)
        instance.$on('error', reject)
        Object
          .keys(events)
          .forEach(name => {
            instance.$on(name, events[name])
          })
        instance.$on('close', () => {
          instance.$destroy()
          instance.$el.remove()
          instance = null
        })
        instance.$mount()

        // identify for workspace
        instance.$el.setAttribute('modal-id', btoa(component))

        this.container.appendChild(instance.$el)
      })
    },

    flush () {
      this.container.innerHTML = ''
    },

    existInstance (instance, component) {
      const singleton = has(instance.$options, 'singleton') && instance.$options.singleton

      if (!singleton) {
        return false
      }

      const modalId = btoa(component)
      return !!this.container.querySelector(`[modal-id=${modalId}]`)
    }
  }

  inject('dialogs', Dialogs)

  inject('preview', ({ parent, index, medias = [] }) => {
    return Dialogs.open({
      parent,
      component: MediasModal,
      props: {
        medias,
        index
      }
    })
  })

  // inject('media', ({ parent, currentIndex = 0, records = [] }) => {
  //   return Dialogs.open({
  //     parent,
  //     component: MediaPreviewModal,
  //     props: {
  //       records,
  //       currentIndex
  //     }
  //   })
  // })
}
