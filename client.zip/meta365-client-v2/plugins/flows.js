import AuthenticationModal from '~/lazy-components/modals/AuthenticationModal'
import AuthenticationWithWalletModal from '~/lazy-components/modals/AuthenticationWithWalletModal'
import RegisterModal from '~/lazy-components/modals/RegisterModal'
import QrCodeModal from '~/lazy-components/modals/QrCodeModal'
import ChangeUserSocialLinkModal from '~/lazy-components/modals/ChangeUserSocialLinkModal'
import AvatarUploaderModal from '~/lazy-components/modals/AvatarUploaderModal'
import RegisterForSaleModal from '~/lazy-components/modals/RegisterForSaleModal'
import RequestBecomeAnAgencyModal from '~/lazy-components/modals/RequestBecomeAnAgencyModal'
import ConfirmTermsModal from '~/lazy-components/modals/ConfirmTermsModal'
import BecomeABrokerModal from '~/lazy-components/modals/BecomeABrokerModal'
import ChangePasswordModal from '~/lazy-components/modals/ChangePasswordModal'
import ContactUsFormModalVue from '~/lazy-components/modals/ContactUsFormModal'
// import LoginMethod from '~/lazy-components/modals/LoginMethod'
// import CreateGuideItemModal from '~/lazy-components/modals/CreateGuideItemModal'

export default ({ app }, inject) => {
  const flows = {}

  flows.login = ({ parent }) => {
    return app.$dialogs.open({
      parent,
      component: AuthenticationModal
    })
  }

  flows.loginWallet = ({ parent }) => {
    return app.$dialogs.open({
      parent,
      component: AuthenticationWithWalletModal
    })
  }

  flows.register = ({ parent }) => {
    return app.$dialogs.open({
      parent,
      component: RegisterModal
    })
  }

  flows.confirmTerms = ({ parent, terms }) => {
    return app.$dialogs.open({
      parent,
      props: {
        terms
      },
      component: ConfirmTermsModal
    })
  }

  flows.becomeABroker = ({ parent, terms }) => {
    return app.$dialogs.open({
      parent,
      props: {
        terms
      },
      component: BecomeABrokerModal
    })
  }

  flows.social = ({ parent, socials }) => {
    return app.$dialogs.open({
      parent,
      component: ChangeUserSocialLinkModal,
      props: {
        socials
      }
    })
  }

  flows.avatarUploader = ({ parent, src }) => {
    return app.$dialogs.open({
      parent,
      component: AvatarUploaderModal,
      props: {
        src
      }
    })
  }

  flows.qrCode = ({ parent, qr, download }) => {
    return app.$dialogs.open({
      parent,
      component: QrCodeModal,
      props: {
        download,
        qr
      }
    })
  }

  flows.confirmRegisterForSale = ({ parent, terms }) => {
    return app.$dialogs.open({
      parent,
      component: RegisterForSaleModal,
      props: {
        terms
      }
    })
  }

  flows.becomeAnAgency = ({ parent }) => {
    return app.$dialogs.open({
      parent,
      component: RequestBecomeAnAgencyModal
    })
  }

  flows.changePassword = ({ parent }) => {
    return app.$dialogs.open({
      parent,
      component: ChangePasswordModal
    })
  }

  flows.contactUs = ({ parent, project }) => {
    return app.$dialogs.open({
      parent,
      component: ContactUsFormModalVue,
      props: {
        project
      }
    })
  }

  inject('flows', flows)

}
