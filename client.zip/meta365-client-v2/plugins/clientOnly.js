import Vue from 'vue'
// import VueVideoPlayer from 'vue-video-player'
import VuePlyr from 'vue-plyr/dist/vue-plyr.ssr.js'
// import 'video.js/dist/video-js.css'
import 'vue-plyr/dist/vue-plyr.css'
import VueQr from 'vue-qr'
import Driver from 'driver.js' // import driver.js
import 'driver.js/dist/driver.min.css' // import driver.js css

Vue.use(VueQr)

// Vue.use(VueVideoPlayer)
Vue.use(VuePlyr, {
  plyr: {
    autoplay: 1,
    playsinline: 1
  }
})

export default async (_context, inject) => {
  inject('guide', new Driver())

  const workbox = await window.$workbox

  if (!workbox) {
    console.debug("Workbox couldn't be loaded.")
    return
  }

  workbox.addEventListener('installed', (event) => {
    if (!event.isUpdate) {
      console.debug('The PWA is on the latest version.')
      return
    }

    console.debug('There is an update for the PWA, reloading...')
    window.location.reload()
  })
}
