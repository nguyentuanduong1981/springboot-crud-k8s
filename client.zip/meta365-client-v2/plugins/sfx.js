// const open = require('@/assets/sounds/open-chest.mp3').default;

class Beeper {
  actions = {}
  player = {}

  constructor (actions = []) {
    this.actions = actions
    this.player = new Audio()
  }

  add (action, file) {
    this.actions[action] = file
  }

  emit (action, loop = false) {
    if (!this.actions[action]) throw new Error('SFX action not found')
    this.play(this.actions[action], loop)
  }

  play (file, loop = false) {
    this.player.src = file
    this.player.volume = 0.5
    this.player.loop = loop
    this.player.play()
  }

  pause () {
    this.player.pause()
  }
}

export default (_, inject) => {
  inject('sfx', new Beeper({
    // all notifications
    // open,
  }))
}
