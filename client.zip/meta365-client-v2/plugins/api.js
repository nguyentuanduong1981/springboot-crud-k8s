import appRequest from '~/requests/app-request'
import authenticationRequest from '@/requests/authentication-request'
import userRequest from '@/requests/user-request'
import provincesRequest from '@/requests/provinces-request'
import projectRequest from '~/requests/project-request'
import linkRequest from '~/requests/link-request'
import agencyRequest from '~/requests/agency-request'

const requestList = [
  appRequest,
  userRequest,
  linkRequest,
  agencyRequest,
  projectRequest,
  provincesRequest,
  authenticationRequest
]

export default ({ store, $axios }, inject) => {

  let api = {}

  requestList.forEach(RequestClass => {
    const instance = new RequestClass(store, $axios)
    const alias = instance.alias()

    if (!alias) {
      throw new Error(`Invalid request class name ${RequestClass}`)
    }

    const obj = {}
    obj[alias] = instance
    api = { ...api, ...obj }
  })

  inject('api', api)
}