import https from 'https'

const onHandleErrorClientSide = (error, { redirect, store, app }) => {
  if (!error.response) {
    return
  }

  const response = error.response

  if (response.status === 503) {
    store.commit('system/turnOnMaintenanceMode')
    return redirect('/server-maintenance')
  }

  if (process.server) {
    return
  }

  if (response.status === 401) {

    return window.$nuxt.$emit('SessionTerminated')
  }

}

export default function ({ $axios, app, redirect, store, isDev }) {
  $axios.onResponse((res) => {})

  const agent = new https.Agent({
    rejectUnauthorized: false
  })

  $axios.onRequest((request) => {
    // if (!request.headers.Authorization) {
    //   app.$auth.logout()
    // }
    if (isDev) {
      request.httpsAgent = agent;
    }
  })

  $axios.onError(error => {
    onHandleErrorClientSide(error, { redirect, store, app })
  })
}
