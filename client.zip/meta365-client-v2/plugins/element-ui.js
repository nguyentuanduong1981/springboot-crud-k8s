import Vue from 'vue'
import Element from 'element-ui'
import locale from 'element-ui/lib/locale/lang/en'
import InfiniteLoading from 'vue-infinite-loading'

Vue.use(InfiniteLoading, {
  props: {
    spinner: 'spiral'
  },
  system: {
    throttleLimit: 50
  },
  slots: {
    noMore: ''
  }
})
Vue.use(Element, { locale })
