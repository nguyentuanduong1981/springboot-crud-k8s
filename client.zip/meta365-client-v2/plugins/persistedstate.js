import createPersistedState from 'vuex-persistedstate'
import * as Cookies from 'js-cookie'
import cookie from 'cookie'
import { version, name } from '@/package.json'

export default ({ store, req }) => {
  createPersistedState({
    key: `${name}-${version}`,
    paths: ['auth', 'app'],
    storage: {
      getItem: (key) => {
        if (process.server) {
          let headerCookie = req.headers.cookie;
          if (typeof headerCookie !== 'string') {
            headerCookie = ''
          }
          const parsedCookies = cookie.parse(headerCookie)
          return parsedCookies[key]
        } else {
          return Cookies.get(key)
        }
      },
      // Please see https://github.com/js-cookie/js-cookie#json, on how to handle JSON.
      setItem: (key, value) =>
        Cookies.set(key, value, { expires: 1, secure: false }),
      removeItem: key => Cookies.remove(key)
    }
  })(store)
}
