// import { Message } from 'element-ui'
import locale from 'element-ui/lib/locale'

export default function ({ app }) {
  // beforeLanguageSwitch called right before setting a new locale
  app.i18n.beforeLanguageSwitch = (_oldLocale, _newLocale) => {
    // some code
  }
  // onLanguageSwitched called right after a new locale has been set
  app.i18n.onLanguageSwitched = (oldLocale, newLocale) => {
    if (process.server) return
    locale.use(newLocale)
    // console.log(app.i18n)
    // return
    // Message.success(app.i18n.t('notification.changed_language_successfully'))
  }
}
